package net.spring.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.RegisterUser;

@Controller
public class CrudController {

	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value="/fetch")
	public ModelAndView listRegisterUsers(ModelAndView model) throws IOException{
		List<RegisterUser> listusers = userDao.userList();
		model.addObject("listUser",listusers);
		model.setViewName("admindashboard");
		
		return model;
	}
}

package net.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import net.spring.dao.UserDao;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

@Service
@Scope("prototype")
public class UserServiceImpl implements UserService {

	@Autowired
	public UserDao userDao;

	public int register(RegisterUser user) {
		return userDao.register(user);
	}

	public RegisterUser loginThreeRoles(LoginUser login) {
		return userDao.loginThreeRoles(login);
	}
	
	public List<RegisterUser> userList(){
		return userDao.userList();
	}
	
	

  





}
package net.spring.service;

import java.util.List;

import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

public interface UserService {

	int register(RegisterUser user);

	RegisterUser loginThreeRoles(LoginUser login);

	List<RegisterUser> userList();
}
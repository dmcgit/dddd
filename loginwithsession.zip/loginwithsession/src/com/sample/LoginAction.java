package com.sample;

import java.util.Map;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

public class LoginAction implements SessionAware {

	// A simple implementation of the Map interface to handle a collection of HTTP
	// session attributes.
	private SessionMap<String, Object> session;
	private String username;
	private String password;

	public String execute() {
		return "success";
	}

	public String getRestricted() {
		return "success";
	}

	public String checkLogin() {
		if (username.equals("admin") && password.equals("admin")) {
			session.put("username", username);
			return "success";
		}
		return "input";
	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session = (SessionMap<String, Object>) session;
	}

	public String logout() {
		session.invalidate();
		return "success";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}

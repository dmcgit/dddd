package net.spring.dao;

import java.util.List;

import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

public interface UserDao {
	int register(RegisterUser user);

	RegisterUser loginThreeRoles(LoginUser login);

	 List<RegisterUser> studentList();
	 
	 List<RegisterUser> lecturerList();
}

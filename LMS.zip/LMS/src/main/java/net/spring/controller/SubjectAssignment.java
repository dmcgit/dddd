package net.spring.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.Assignmt;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
public class SubjectAssignment {

	@Autowired
	UserDao userDao;

	@Autowired
	UserService userService;

	@RequestMapping(value = "/assgnmt", method = RequestMethod.GET)
	public ModelAndView assgnmtAddition(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("assgnmt");

		mav.addObject("assignmt", new Assignmt());
		return mav;
	}

	@RequestMapping(value = "/viewassignmt/{username}")
	public ModelAndView studentcrud(@RequestParam(required = false, name = "sub_year") String sub_year,@PathVariable String username, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("viewassgnmts");
		RegisterUser user = userDao.getStudentByUsername(username);
		sub_year =user.getYear();
		System.out.println("year: "+sub_year);
		List<Assignmt> listassignmt = userDao.assignmtList(sub_year);
		mav.addObject("listAssignmt", listassignmt);
		return mav;
	}

	@RequestMapping(value = "/lecturerprofile", method = RequestMethod.POST)
	public ModelAndView addassgnmts(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("assignmt") Assignmt user, @ModelAttribute("user") RegisterUser user1) throws IOException {
		String image = this.getBase64String(user.getAssignmt().getBytes());

		user.setAssgnmt(image);
		userDao.addassgnmt(user);

		return new ModelAndView("assgnmttable");
	}

	public String getBase64String(byte[] fileByteArray) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("data:application/pdf;base64,");
			sb.append(StringUtils.newStringUtf8(Base64.encodeBase64(fileByteArray, false)));
			return sb.toString();
		} catch (Exception e) {
			return "error = " + e;
		}
	}

}

package net.spring.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.spring.dao.UserDao;
import net.spring.model.Assignmt;
import net.spring.model.RegisterUser;
import net.spring.model.Submission;
import net.spring.service.UserService;

@Controller
public class SubjectAssignment {

	@Autowired
	UserDao userDao;

	@Autowired
	UserService userService;

	@RequestMapping(value = "/assgnmt", method = RequestMethod.GET)
	public ModelAndView assgnmtAddition(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("assgnmt");

		mav.addObject("assignmt", new Assignmt());
		return mav;
	}
	
	@RequestMapping(value = "/submisn/{assgnmt_id}", method = RequestMethod.GET)
	public ModelAndView submission(@PathVariable String assgnmt_id,HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("addsubmission");
		Assignmt assignmt = userDao.assignmtById(assgnmt_id);
		mav.addObject("assignmt",assignmt);
		mav.addObject("submisn", new Submission());
		return mav;
	}
	

	@RequestMapping(value = "/submisn/studentprofile/{username}", method = RequestMethod.POST)
	public String addsubmission(@PathVariable String username,HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("submisn") Submission user, @ModelAttribute("user") RegisterUser user1) throws IOException {
		String submisnpdf = this.getBase64String(user.getSubmisn().getBytes());

		user.setSubmsn(submisnpdf);
		userDao.addsubmisn(user);

		return "redirect:/studentprofile/" + username;
	}
	
	@RequestMapping(value = "/lecturerprofile/{username}", method = RequestMethod.POST)
	public String addassgnmts(@PathVariable String username,HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("assignmt") Assignmt user, @ModelAttribute("user") RegisterUser user1) throws IOException {
		String assgnmtpdf = this.getBase64String(user.getAssignmt().getBytes());

		user.setAssgnmt(assgnmtpdf);
		userDao.addassgnmt(user);

		return "redirect:/viewassignmtlist/" + username;
	}
	
	@RequestMapping(value = "/viewassignmtlist/{username}")
	public ModelAndView viewassignmtlist(@RequestParam(required = false, name = "lec_id") String lec_id,
			@PathVariable String username, HttpServletResponse response)throws IOException {
		ModelAndView mav = new ModelAndView("assgnmttable");
		RegisterUser user = userDao.getLecturerByUsername(username);
		lec_id = user.getUsername();
		List<Assignmt> listassignmtpersub = userDao.assignmtListpersub(lec_id);
		mav.addObject("listAssignmtPerSub", listassignmtpersub);
		return mav;
	}
	

	@RequestMapping(value = "/viewassignmt/{username}")
	public ModelAndView studentcrud(@RequestParam(required = false, name = "sub_year") String sub_year,
			@PathVariable String username, HttpServletResponse response)throws IOException {
		ModelAndView mav = new ModelAndView("viewassgnmts");
		RegisterUser user = userDao.getStudentByUsername(username);
		sub_year = user.getYear();
		List<Assignmt> listassignmt = userDao.assignmtList(sub_year);
		mav.addObject("listAssignmt", listassignmt);
		return mav;
	}
	
	@RequestMapping(value = "/viewassignmt/download", method = RequestMethod.POST)
	public @ResponseBody String studentpdf(@RequestParam("id") String id,HttpServletResponse response) throws JRException, IOException {
		String pdfString = "";
		try {
			Assignmt assignmt = userDao.assignmtById(id);
			pdfString = assignmt.getAssgnmt();
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}
		return pdfString;
	}
	
	@RequestMapping(value = "/viewsubmisn/download", method = RequestMethod.POST)
	public @ResponseBody String submisnpdf(@RequestParam("sid") String sid,@RequestParam("aid") String aid,HttpServletResponse response) throws JRException, IOException {
		String pdfString = "";
		try {
			Submission submission = userDao.submisnById(sid,aid);
			pdfString = submission.getSubmsn();
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}
		return pdfString;
	}
	
	
	
	public String getBase64String(byte[] fileByteArray) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("data:application/pdf;base64,");
			sb.append(StringUtils.newStringUtf8(Base64.encodeBase64(fileByteArray, false)));
			return sb.toString();
		} catch (Exception e) {
			return "error = " + e;
		}
	}

}

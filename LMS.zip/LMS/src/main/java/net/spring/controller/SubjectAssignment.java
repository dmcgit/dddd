package net.spring.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.spring.dao.UserDao;
import net.spring.model.Assignmt;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
public class SubjectAssignment {

	@Autowired
	UserDao userDao;

	@Autowired
	UserService userService;

	@RequestMapping(value = "/assgnmt", method = RequestMethod.GET)
	public ModelAndView assgnmtAddition(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("assgnmt");

		mav.addObject("assignmt", new Assignmt());
		return mav;
	}

	@RequestMapping(value = "/lecturerprofile", method = RequestMethod.POST)
	public ModelAndView addassgnmts(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("assignmt") Assignmt user, @ModelAttribute("user") RegisterUser user1) throws IOException {
		String image = this.getBase64String(user.getAssignmt().getBytes());

		user.setAssgnmt(image);
		userDao.addassgnmt(user);

		return new ModelAndView("assgnmttable");
	}

	@RequestMapping(value = "/viewassignmt/{username}")
	public ModelAndView studentcrud(@RequestParam(required = false, name = "sub_year") String sub_year,
			@PathVariable String username, HttpServletResponse response)
			throws IOException {
		ModelAndView mav = new ModelAndView("viewassgnmts");
		RegisterUser user = userDao.getStudentByUsername(username);
		sub_year = user.getYear();
		List<Assignmt> listassignmt = userDao.assignmtList(sub_year);
//		final File dwldsPath = new File(Environment.getExternalStoragePublicDirectory(Environment.C:\Users\maheshi_c\Desktop\New folder + "/");
//		
//		String pdfAsBytes = Base64.decode(this.getBase64String(user1.getAssignmt().getBytes());
//		FileOutputStream os;
//		os = new FileOutputStream(dwldsPath, false);
//		os.write(pdfAsBytes);
//		os.flush();
//		os.close();
//		user1.setAssgnmt(pdfAsBytes);
		//String assgnmt = this.getBase64String(user1.getAssignmt().getBytes());
		//byte[] decoder = Base64.getDecoder().decode(assgnmt);
		mav.addObject("listAssignmt", listassignmt);
		return mav;
	}
	
	@RequestMapping(value = "/viewassignmt/download", method = RequestMethod.POST)
	public Assignmt studentpdf(@RequestParam("id") String id,HttpServletResponse response) throws JRException, IOException {
		Assignmt assignmt = null;
		try {
			System.out.println("id  "+ id);
			assignmt = userDao.assignmtById(id);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}
		return assignmt;
	}
	
	public String getBase64String(byte[] fileByteArray) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("data:application/pdf;base64,");
			sb.append(StringUtils.newStringUtf8(Base64.encodeBase64(fileByteArray, false)));
			return sb.toString();
		} catch (Exception e) {
			return "error = " + e;
		}
	}

}

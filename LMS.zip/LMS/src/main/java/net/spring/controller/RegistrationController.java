package net.spring.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
public class RegistrationController {
	@Autowired
	public UserService userService;

	@Autowired
	public UserDao userDao;

	@RequestMapping(value = "/registerStudent", method = RequestMethod.GET)
	public ModelAndView RegisterStudent(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("registerStudent");

		mav.addObject("user", new RegisterUser());

		return mav;
	}

	@RequestMapping(value = "/registerLecturer", method = RequestMethod.GET)
	public ModelAndView RegisterLecturer(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("registerLecturer");

		mav.addObject("user", new RegisterUser());

		return mav;
	}

	@RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	public ModelAndView addUser1(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("user") RegisterUser user) throws IOException {
		String image = this.getBase64String(user.getImg().getBytes());

		user.setEncodeimg(image);
		userService.register(user);

		return new ModelAndView("admindashboard");
	}

	public String getBase64String(byte[] imageByteArray) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("data:image/jpg;base64,");
			sb.append(StringUtils.newStringUtf8(Base64.encodeBase64(imageByteArray, false)));
			return sb.toString();
		} catch (Exception e) {
			return "error = " + e;
		}
	}

}

package net.spring.model;

import java.io.File;
import java.sql.Date;

import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Bean;
import org.springframework.web.multipart.MultipartFile;

public class RegisterUser {

	@NotNull
	private String username;
	private String fname;
	private String lname;
	@NotNull
	private String email;
	@NotNull
	private String password;

	private String year;

	@NotNull
	private Date birthday;
	private String contact;
	private String encodeimg;
	private MultipartFile img;
	private String gender;
	@NotNull
	private String role_id;
	private String sub_code;
	private String sub_name;

	public String getSub_code() {
		return sub_code;
	}

	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}

	public String getSub_name() {
		return sub_name;
	}

	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}

	public String getSub_year() {
		return sub_year;
	}

	public void setSub_year(String sub_year) {
		this.sub_year = sub_year;
	}

	public String getLec_id() {
		return lec_id;
	}

	public void setLec_id(String lec_id) {
		this.lec_id = lec_id;
	}

	private String sub_year;
	private String lec_id;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		System.out.println("username: " + username);
		this.username = username;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		System.out.println("fname: " + fname);
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		System.out.println("lname: " + lname);
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		System.out.println("email: " + email);
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("password: " + password);
		this.password = password;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		System.out.println("year: " + year);
		this.year = year;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		System.out.println("birthday: " + birthday);
		this.birthday = birthday;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		System.out.println("contact: " + contact);
		this.contact = contact;
	}

	public String getEncodeimg() {
		return encodeimg;
	}

	public void setEncodeimg(String encodeimg) {
		System.out.println("encode image: " + encodeimg);
		this.encodeimg = encodeimg;
	}

	public MultipartFile getImg() {
		return img;
	}

	public void setImg(MultipartFile img) {
		System.out.println(" image: " + img);
		this.img = img;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		System.out.println("gender: " + gender);
		this.gender = gender;
	}

	public String getRole_id() {
		return role_id;
	}

	public void setRole_id(String role_id) {
		System.out.println("role_id: " + role_id);
		this.role_id = role_id;
	}

}

package net.spring.model;

import org.springframework.web.multipart.MultipartFile;

public class Submission {
	
	private String submsn;
	private MultipartFile submisn; 
	private String submisn_id;
	private String st_id;
	private String sub_code;
	private String assgnmt_id;
	
	public String getSubmsn() {
		return submsn;
	}
	public void setSubmsn(String submsn) {
		this.submsn = submsn;
	}
	public MultipartFile getSubmisn() {
		return submisn;
	}
	public void setSubmisn(MultipartFile submisn) {
		this.submisn = submisn;
	}
	public String getSubmisn_id() {
		return submisn_id;
	}
	public void setSubmisn_id(String submisn_id) {
		this.submisn_id = submisn_id;
	}
	public String getSt_id() {
		return st_id;
	}
	public void setSt_id(String st_id) {
		this.st_id = st_id;
	}
	public String getSub_code() {
		return sub_code;
	}
	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}
	public String getAssgnmt_id() {
		return assgnmt_id;
	}
	public void setAssgnmt_id(String assgnmt_id) {
		this.assgnmt_id = assgnmt_id;
	}
	
}

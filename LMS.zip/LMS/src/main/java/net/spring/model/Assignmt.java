package net.spring.model;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

public class Assignmt {

	
	private String assgnmt;
	private MultipartFile assignmt;
	private String assgnmt_id;
	private Date deadline;
	private String sub_code;
	
	public MultipartFile getAssignmt() {
		return assignmt;
	}
	public void setAssignmt(MultipartFile assignmt) {
		this.assignmt = assignmt;
	}
	
	public String getAssgnmt() {
		System.out.println("assignmt: "+assgnmt);
		return assgnmt;
	}
	public void setAssgnmt(String assgnmt) {
		this.assgnmt = assgnmt;
	}
	public String getAssgnmt_id() {
		System.out.println("id: "+assgnmt_id);
		return assgnmt_id;
	}
	public void setAssgnmt_id(String assgnmt_id) {
		this.assgnmt_id = assgnmt_id;
	}
	public Date getDeadline() {
		System.out.println("deadline: "+deadline);
		return deadline;
	}
	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}
	public String getSub_code() {
		System.out.println("subcode: "+sub_code);
		return sub_code;
	}
	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}
}

package net.spring.model;

import javax.validation.constraints.NotNull;

public class LoginUser {
	
	@NotNull
	private String username;
	@NotNull
	private String password;
	
	public String getUsername() {
		System.out.println(username);
		return username;
	}
	public void setUsername(String username) {
		System.out.println(username);
		this.username = username;
	}
	public String getPassword() {
		System.out.println(password);
		return password;
	}
	public void setPassword(String password) {
		System.out.println(password);
		this.password = password;
	}
	
	
}

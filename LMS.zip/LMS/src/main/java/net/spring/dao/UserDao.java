package net.spring.dao;

import java.util.List;

import net.spring.model.Assignmt;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

public interface UserDao {
	int register(RegisterUser user);

	RegisterUser loginThreeRoles(LoginUser login);

	 List<RegisterUser> studentList();
	 
	 List<RegisterUser> lecturerList();

	int editstudent(RegisterUser user);
	int editlecturer(RegisterUser user);
	int deletestudent(String username);
	int deletelecturer(String username);

	RegisterUser getStudentByUsername(String username);
	RegisterUser getLecturerByUsername(String username);
	List<RegisterUser> studentsubject(String year, String sub_name);

	List<RegisterUser> subjectlist(String username, String year);
	int addassgnmt(Assignmt user);

}

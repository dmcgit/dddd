package net.spring.model;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

public class Assignmt {

	
	private String assgnmt;
	private MultipartFile assignmt;
	private String assgnmt_id;
	private Date deadline;
	private String sub_code;
	private String lec_id;
	private String sub_year;
	
	
	public String getSub_year() {
		return sub_year;
	}
	public void setSub_year(String sub_year) {
		System.out.println("year: "+sub_year);
		this.sub_year = sub_year;
	}
	public String getLec_id() {
		return lec_id;
	}
	public void setLec_id(String lec_id) {
		this.lec_id = lec_id;
	}
	public MultipartFile getAssignmt() {
		System.out.println("assignmt: "+assignmt);
		return assignmt;
	}
	public void setAssignmt(MultipartFile assignmt) {
		System.out.println("assignmt: "+assignmt);
		this.assignmt = assignmt;
	}
	
	public String getAssgnmt() {
		System.out.println("assignmt: "+assgnmt);
		return assgnmt;
	}
	public void setAssgnmt(String assgnmt) {
		System.out.println("assignmt: "+assgnmt);
		this.assgnmt = assgnmt;
	}
	public String getAssgnmt_id() {
		System.out.println("id: "+assgnmt_id);
		return assgnmt_id;
	}
	public void setAssgnmt_id(String assgnmt_id) {
		this.assgnmt_id = assgnmt_id;
	}
	public Date getDeadline() {
		System.out.println("deadline: "+deadline);
		return deadline;
	}
	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}
	public String getSub_code() {
		System.out.println("subcode: "+sub_code);
		return sub_code;
	}
	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}
}

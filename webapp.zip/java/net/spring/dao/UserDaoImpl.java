package net.spring.dao;

import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

@Repository
@Scope("prototype")
public class UserDaoImpl implements UserDao {

	@Autowired
	DataSource database;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

// User registration
	public int register(RegisterUser user) {
		String register = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(register,
				new Object[] { user.getUsername(), user.getFname(), user.getLname(), user.getEmail(),
						SHA1(user.getPassword()), user.getYear(), user.getBirthday(), user.getContact(), user.getImg(),
						user.getGender(), user.getRole_id() });
	}

// #Admin, #Lecturer, #Student login
	public RegisterUser loginThreeRoles(LoginUser loginuser) {
		String login = "SELECT * FROM users WHERE username='" + loginuser.getUsername() + "' AND password='"
				+ SHA1(loginuser.getPassword()) + "'";

		List<RegisterUser> users = jdbcTemplate.query(login, new UserMapper());

		return users.size() > 0 ? users.get(0) : null;
	}

// Retrieve students' details from users table
	@Override
	public List<RegisterUser> studentList() {
		List<RegisterUser> list = jdbcTemplate.query("SELECT * FROM users WHERE role_id='1'",
				new RowMapper<RegisterUser>() {

					@Override
					public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
						RegisterUser user = new RegisterUser();

						user.setUsername(rs.getString("username"));
						user.setFname(rs.getString("fname"));
						user.setLname(rs.getString("lname"));
						user.setEmail(rs.getString("email"));
						user.setYear(rs.getString("year"));
						user.setBirthday(rs.getDate("birthday"));
						user.setContact(rs.getString("contact"));
						user.setGender(rs.getString("gender"));
						user.setRole_id(rs.getString("role_id"));
						return user;
					}

				});
		return list;
	}

//Join users and subjects table and retrieve data related to lecturer
	@Override
	public List<RegisterUser> lecturerList() {
		List<RegisterUser> list = jdbcTemplate.query(
				"SELECT users.username,users.fname,users.lname,users.email,subjects.sub_name,subjects.sub_code FROM users INNER JOIN subjects ON users.username=subjects.lec_id WHERE users.role_id='2'",
				new RowMapper<RegisterUser>() {

					@Override
					public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
						RegisterUser user = new RegisterUser();

						user.setUsername(rs.getString("username"));
						user.setFname(rs.getString("fname"));
						user.setLname(rs.getString("lname"));
						user.setEmail(rs.getString("email"));
						user.setSub_code(rs.getString("sub_code"));
						user.setSub_name(rs.getString("sub_name"));
						return user;

					}

				});
		return list;
	}

//Update Student
	public int editstudent(RegisterUser user) {
		String edit = "UPDATE users SET fname ='" + user.getFname() + "', lname='" + user.getLname() + "' , email= '"
				+ user.getEmail() + "', password='" + user.getPassword() + "', year='" + user.getYear()
				+ "', birthday='" + user.getBirthday() + "', contact ='" + user.getContact() + "',img='" + user.getImg()
				+ "', gender='" + user.getGender() + "', role_id='" + user.getRole_id() + "' WHERE username = '"
				+ user.getUsername() + "'";
		int i = jdbcTemplate.update(edit);
		System.out.println("------1-------");
		return i;
	}


//Delete Student
	public int deletestudent(String username) {
		String delete = "DELETE FROM users where username='" + username + "'";
		return jdbcTemplate.update(delete);
	}
	
//Delete Lecturer
	public int deletelecturer(String username) {
		String delete = "DELETE from users where username='"+username+"'";
	    return jdbcTemplate.update(delete);
	}

// Select Student according to username
	public RegisterUser getStudentByUsername(String username) {
		String sql = "SELECT * FROM users WHERE username=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { username },
				new BeanPropertyRowMapper<RegisterUser>(RegisterUser.class));
	}

	class UserMapper implements RowMapper<RegisterUser> {

		public RegisterUser mapRow(ResultSet rs, int arg1) throws SQLException {
			RegisterUser user = new RegisterUser();

			user.setUsername(rs.getString("username"));
			user.setPassword(SHA1(rs.getString("password")));
			user.setRole_id(rs.getString("role_id"));
			user.setFname(rs.getString("fname"));
			user.setLname(rs.getString("lname"));
			user.setEmail(rs.getString("email"));
			user.setGender(rs.getString("gender"));
			user.setYear(rs.getString("year"));
			user.setBirthday(rs.getDate("birthday"));
			user.setContact(rs.getString("contact"));
			user.setImg(rs.getString("img"));
			user.setRole_id(rs.getString("role_id"));

			return user;
		}
	}

	public static String SHA1(String password) {
		try {
			MessageDigest mDigest = MessageDigest.getInstance("SHA1");
			byte[] result = mDigest.digest(password.getBytes());
			StringBuffer sb = new StringBuffer();

			for (int i = 0; i < result.length; i++) {
				sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
			}
			return sb.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}

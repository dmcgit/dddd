package net.spring.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
public class LecturerCRUD {

	@Autowired
	UserService userService;
	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value="/lecturer")
	public ModelAndView lecturercrud(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("lecturer");
		List<RegisterUser> listlecturer = userDao.lecturerList();
		mav.addObject("listLecturer", listlecturer);
		return mav;
	}
	
	@RequestMapping(value="/student")
	public ModelAndView studentcrud(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("student");
		List<RegisterUser> liststudent= userDao.studentList();
		mav.addObject("listStudent",liststudent);
		return mav;
	}
	
	  @RequestMapping(value="/editstudent/{username}")    
	    public ModelAndView edit(@PathVariable String username, Model m){   
		  ModelAndView mav = new ModelAndView("editstudent");
	        RegisterUser registerUser=userDao.getStudentByUsername(username);    
	        m.addAttribute("command",registerUser);  
	        return mav;
	    }  
	  
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@ModelAttribute("registerStudent") RegisterUser registerUser){    
	        userDao.editstudent(registerUser);
	        return "redirect:/student";    
	    } 

	    @RequestMapping(value="/deletestudent/{username}",method = RequestMethod.GET)    
	    public String deletestudent(@PathVariable String username){    
	        userDao.deletestudent(username);    
	        return "redirect:/student";    
	    } 
	    
	    @RequestMapping(value="/deletelecturer/{username}",method = RequestMethod.GET)    
	    public String deletelecturer(@PathVariable String username){    
	        userDao.deletelecturer(username);    
	        return "redirect:/lecturer";    
	    }    



	
}

package net.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
@Scope("request")
public class LoginController {

	@Autowired
	UserService userService;

	@Autowired
	private UserDao userDao;

	// User login
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showLogin(@ModelAttribute("login") LoginUser login, BindingResult result) {
		return new ModelAndView("login", "login", new LoginUser());
	}

	// When login to the system, redirect according to the role
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") LoginUser login) {

		RegisterUser user = userService.loginThreeRoles(login);

		// As a student
		if (null != user && user.getRole_id().equals("1")) {
			HttpSession oldSession = request.getSession(false);
			if (oldSession != null) {
				oldSession.invalidate();
			}
			HttpSession session = request.getSession(true);
			session.setMaxInactiveInterval(1 * 60);
			String sessionId = session.getId();
			ModelAndView mav = new ModelAndView("studentdashboard");
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("username", user.getUsername());
			session.setAttribute("fname", user.getFname());
			session.setAttribute("lname", user.getLname());
			session.setAttribute("email", user.getEmail());
			session.setAttribute("year", user.getYear());
			session.setAttribute("birthday", user.getBirthday());
			session.setAttribute("contact", user.getContact());
			session.setAttribute("role_id", user.getRole_id());
			session.setAttribute("image", user.getEncodeimg());
			session.setAttribute("gender", user.getGender());
			session.setAttribute("password", user.getPassword());
			return mav;

			// As a lecturer
		} else if (null != user && user.getRole_id().equals("2")) {
			HttpSession oldSession = request.getSession(false);
			if (oldSession != null) {
				oldSession.invalidate();
			}
			HttpSession session = request.getSession(true);
			String sessionId = session.getId();
			session.setMaxInactiveInterval(1 * 60);
			ModelAndView mav = new ModelAndView("lecturerdashboard");
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("sub_code", user.getSub_code());
			session.setAttribute("username", user.getUsername());
			session.setAttribute("fname", user.getFname());
			session.setAttribute("lname", user.getLname());
			session.setAttribute("email", user.getEmail());
			session.setAttribute("role_id", user.getRole_id());
			return mav;

			// As an admin
		} else if (null != user && user.getRole_id().equals("3")) {
			HttpSession oldSession = request.getSession(false);
			if (oldSession != null) {
				oldSession.invalidate();
			}
			HttpSession session = request.getSession(true);
			session.setMaxInactiveInterval(1 * 60);
			String sessionId = session.getId();
			ModelAndView mav = new ModelAndView("admindashboard");
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("email", user.getEmail());
			session.setAttribute("role_id", user.getRole_id());
			List<RegisterUser> liststudent = userDao.studentList();
			List<RegisterUser> listlecturer = userDao.lecturerList();
			session.setAttribute("listStudent", liststudent);
			session.setAttribute("listLecturer", listlecturer);
			return mav;

			// For invalid users
		} else {
			ModelAndView mav = new ModelAndView("login");
			mav.addObject("message", "Username or Password is wrong!!");
			return mav;
		}

	}

	// User Logout
	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:login";
	}

	@ModelAttribute
	public void getLoginbean(Model map) {
		map.addAttribute("login", new LoginUser());
	}

}

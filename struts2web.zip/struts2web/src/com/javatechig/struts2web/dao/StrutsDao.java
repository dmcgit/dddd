package com.javatechig.struts2web.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StrutsDao {

	// Create database connection
	public static Connection getConnection() throws Exception {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost/strutslogin", "root", "");

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// Login user
	public static boolean login(String username, String password) throws SQLException, Exception {
		boolean i = false;
		try {
			String sql = "SELECT * FROM newusers WHERE username =? AND password = ?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			i = rs.next();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return i;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// Add new user
	public int newuser(String username, String firstname, String lastname, Date birthday, String gender,
			String password) throws SQLException, Exception {
		int i = 0;
		try {

			String sql = "INSERT INTO newusers VALUES (?,?,?,?,?,?)";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, firstname);
			ps.setString(3, lastname);
			ps.setDate(4, birthday);
			ps.setString(5, gender);
			ps.setString(6, password);
			i = ps.executeUpdate();
			System.out.println("sql: "+sql);
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("iii: "+i);
			return i;
			
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// View all users
	public ResultSet viewall() throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM newusers";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// Get user by id
	public ResultSet getUserById(int id) throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT username, firstname,lastname,birthday,gender,password FROM newusers WHERE id = ?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			return rs;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// Update user
	public int updateuser(String username, String firstname, String lastname, Date birthday, String gender,
			String password) throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;
		try {
			String sql = "UPDATE newusers SET username = ?, firstname = ?, lastname = ?, birthday = ?, gender = ?, password = ?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, firstname);
			ps.setString(3, lastname);
			ps.setDate(4, birthday);
			ps.setString(5, gender);
			ps.setString(6, password);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// Delete user
	public int deleteUser(int id) throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;

		try {
			String sql = "DELETE FROM newusers WHERE id = ?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			i = ps.executeUpdate();
			return i;

		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

}

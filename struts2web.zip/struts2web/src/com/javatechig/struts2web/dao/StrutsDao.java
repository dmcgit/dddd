package com.javatechig.struts2web.dao;

public class StrutsDao {

}

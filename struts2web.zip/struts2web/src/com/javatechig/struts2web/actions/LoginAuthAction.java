package com.javatechig.struts2web.actions;

import java.sql.SQLException;
import java.util.Map;

import org.apache.struts2.dispatcher.SessionMap;

import com.javatechig.struts2web.bean.UserBean;
import com.javatechig.struts2web.dao.StrutsDao;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAuthAction extends ActionSupport {
	    private static final long serialVersionUID = 1L;
	    private String username;
	    private String password;

	    private Boolean error;
	    SessionMap<String,String> sessionmap; 

	    StrutsDao dao = new StrutsDao();
	    UserBean bean;
	    
	    public String execute() throws SQLException, Exception {
	        if (StrutsDao.login(username, password)) {
	        	addActionMessage("You are valid user!");
	            error = false;
	        }
	        else if(username.equals("") && password.equals("")) {
	            addActionError("Please enter username and password..!");
	            error = true;
	        } else if(username.equals("")){
	        	 addActionError("Please enter username..!");
		         error = true;
	        }
	        else if(password.equals("")){
	        	 addActionError("Please enter password..!");
		         error = true;
	        }
	        else if(!StrutsDao.login(username, password)) {
	            addActionError("Invalid username or password..!");
	            error = true;
	        }

	        if (error) {
	            return ERROR;
	        } else {
	            return SUCCESS;
	        }

	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
			System.out.println("userId: " + username);
	        this.username = username;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	    	System.out.println("Password: "+password);
	        this.password = password;
	    }
	    
	    public void setSession(Map map) {  
	        sessionmap=(SessionMap)map;  
	        sessionmap.put("login","true");  
	    }  
	      
	    public String logout(){  
	        sessionmap.invalidate();  
	        return "success";  
	    }  
	      
	}


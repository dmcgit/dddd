package com.javatechig.struts2web.actions;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAuthAction extends ActionSupport {
	    private static final long serialVersionUID = 1L;
	    private String userId;
	    private String password;

	    private Boolean error;

	    public String execute() {
	        if (userId.equals("")) {
	            addActionError("Please Enter user id..!");
	            error = true;
	        }
	        else if(password.equals("")) {
	            addActionError("Please Enter password..!");
	            error = true;
	        }
	        else if(!userId.equalsIgnoreCase(password)) {
	            addActionError("Invalid userid or password..!");
	            error = true;
	        } else{
	        	addActionMessage("You are valid user!");
	            error = false;
	        }

	        if (error) {
	            return ERROR;
	        } else {
	            return SUCCESS;
	        }

	    }

	    public String getUserId() {
	        return userId;
	    }

	    public void setUserId(String userId) {
	    	System.out.println("userId: "+userId);
	        this.userId = userId;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	    	System.out.println("Password: "+password);
	        this.password = password;
	    }
	}


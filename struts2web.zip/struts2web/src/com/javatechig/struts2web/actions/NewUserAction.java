package com.javatechig.struts2web.actions;

import java.sql.Date;

import com.javatechig.struts2web.dao.StrutsDao;
import com.opensymphony.xwork2.ActionSupport;

public class NewUserAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String firstname;
	private String lastname;
	private String username;
	private String gender;
	private String password;
	private Date birthday;

	private String msg = "";

	StrutsDao newUser = null;

	int i = 0;

	@Override
	public String execute() {
		newUser = new StrutsDao();

		try {
			i = newUser.newuser(username, firstname, lastname, birthday, gender, password);
			if (i > 0) {
				msg = "Successfully Registered";
				System.out.println("success");
			} else {
				msg = "Registration Fail, Try Again.";
				System.out.println("Fail");
			}
			return "REGISTER";
		} catch (Exception e) {
			e.printStackTrace();

			System.out.println("Fail1111111");
			return "REGISTER";
		}
		
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		System.out.println("Firstname: "+firstname);
		this.firstname = firstname;
	}

	public String getLastname() {
		System.out.println("GLastname: "+lastname);
		return lastname;
	}

	public void setLastname(String lastname) {
		System.out.println("Lastname: "+lastname);
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		System.out.println("username: "+username);
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		System.out.println("Gender: "+gender);
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("Password: "+password);
		this.password = password;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		System.out.println("Birthday: "+birthday);
		this.birthday = birthday;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

}

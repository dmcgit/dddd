package net.spring.dao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;

@Repository
@Scope("prototype")
public class UserDaoImpl implements UserDao {

	@Autowired
	DataSource database;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

// User registration
	public int register(RegisterUser user) {
		String register = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(register,
				new Object[] { user.getUsername(), user.getFname(), user.getLname(), user.getEmail(),
						SHA1(user.getPassword()), user.getYear(), user.getBirthday(), user.getContact(),
						user.getEncodeimg(), user.getGender(), user.getRole_id() });
	}

// #Admin, #Lecturer, #Student login
	public RegisterUser loginThreeRoles(LoginUser loginuser) {
		String login = "SELECT * FROM users WHERE username='" + loginuser.getUsername() + "' AND password='"
				+ SHA1(loginuser.getPassword()) + "'";

		List<RegisterUser> users = jdbcTemplate.query(login, new UserMapper());

		return users.size() > 0 ? users.get(0) : null;
	}

// Retrieve students' details from users table
	@Override
	public List<RegisterUser> studentList() {
		List<RegisterUser> list = jdbcTemplate.query("SELECT * FROM users WHERE role_id='1'",
				new RowMapper<RegisterUser>() {

					@Override
					public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
						RegisterUser user = new RegisterUser();

						user.setUsername(rs.getString("username"));
						user.setFname(rs.getString("fname"));
						user.setLname(rs.getString("lname"));
						user.setEmail(rs.getString("email"));
						user.setYear(rs.getString("year"));
						user.setBirthday(rs.getDate("birthday"));
						user.setContact(rs.getString("contact"));
						user.setGender(rs.getString("gender"));
						user.setRole_id(rs.getString("role_id"));
						return user;
					}

				});
		return list;
	}

//Join users and subjects table and retrieve data related to lecturer
	@Override
	public List<RegisterUser> lecturerList() {
		List<RegisterUser> list = jdbcTemplate.query(
				"SELECT users.username,users.fname,users.lname,users.email,subjects.sub_name,subjects.sub_code FROM users INNER JOIN subjects ON users.username=subjects.lec_id WHERE users.role_id='2'",
				new RowMapper<RegisterUser>() {

					@Override
					public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
						RegisterUser user = new RegisterUser();

						user.setUsername(rs.getString("username"));
						user.setFname(rs.getString("fname"));
						user.setLname(rs.getString("lname"));
						user.setEmail(rs.getString("email"));
						user.setSub_code(rs.getString("sub_code"));
						user.setSub_name(rs.getString("sub_name"));
						return user;

					}

				});
		return list;
	}

	// select student according to subject
	@Override
	public List<RegisterUser> studentsubject(String year, String sub_name) {

		String sql = "SELECT users.username,users.fname,users.lname,users.email,users.birthday,users.gender,users.contact,users.year,subjects.sub_name,subjects.sub_code FROM users,subjects WHERE users.year='"
				+ year + "' AND subjects.sub_name='" + sub_name + "'";
		List<RegisterUser> list = jdbcTemplate.query(sql, new RowMapper<RegisterUser>() {

			@Override
			public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegisterUser user = new RegisterUser();

				user.setUsername(rs.getString("username"));
				user.setYear(rs.getString("year"));
				user.setBirthday(rs.getDate("birthday"));
				user.setContact(rs.getString("contact"));
				user.setGender(rs.getString("gender"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setEmail(rs.getString("email"));
				user.setSub_code(rs.getString("sub_code"));
				user.setSub_name(rs.getString("sub_name"));
				return user;

			}

		});
		System.out.println("sql: " + sql);
		return list;
	}

//select subjects according to year
	@Override
	public List<RegisterUser> subjectlist(String username, String year) {
		String sql = "SELECT subjects.lec_id, subjects.sub_name, subjects.sub_code FROM users,subjects WHERE users.username = '"
				+ username + "' AND subjects.sub_year='" + year + "'";
		
		List<RegisterUser> list = jdbcTemplate.query(sql, new RowMapper<RegisterUser>() {

			@Override
			public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegisterUser user = new RegisterUser();

				
				user.setSub_code(rs.getString("sub_code"));
				user.setSub_name(rs.getString("sub_name"));
				user.setLec_id(rs.getString("lec_id"));
				return user;

			}

		});
		System.out.println("sql: "+sql);
		return list;
	}

//Update Student
	public int editstudent(RegisterUser user) {
		String edit = "UPDATE users SET fname ='" + user.getFname() + "', lname='" + user.getLname() + "' , email= '"
				+ user.getEmail() + "', password='" + user.getPassword() + "', year='" + user.getYear()
				+ "', birthday='" + user.getBirthday() + "', contact ='" + user.getContact() + "',img='"
				+ user.getEncodeimg() + "', gender='" + user.getGender() + "', role_id='" + user.getRole_id()
				+ "' WHERE username = '" + user.getUsername() + "'";
		int i = jdbcTemplate.update(edit);
		System.out.println("------1-------");
		return i;
	}

//Update Lecturer
	public int editlecturer(RegisterUser user) {
		String edit = "UPDATE users,subjects SET users.fname ='" + user.getFname() + "', users.lname='"
				+ user.getLname() + "' , users.email= '" + user.getEmail() + "', users.password='" + user.getPassword()
				+ "',subjects.sub_code='" + user.getSub_code() + "',subjects.sub_name='" + user.getSub_name()
				+ "' WHERE users.username = subjects.lec_id AND users.username = '" + user.getUsername() + "'";
		int i = jdbcTemplate.update(edit);
		System.out.println("------1-------: " + edit);
		return i;
	}

//Delete Student
	public int deletestudent(String username) {
		String delete = "DELETE FROM users where username='" + username + "'";
		return jdbcTemplate.update(delete);
	}

//Delete Lecturer
	public int deletelecturer(String username) {
		String delete = "DELETE from users where username='" + username + "'";
		return jdbcTemplate.update(delete);
	}

// Select Student according to username
	public RegisterUser getStudentByUsername(String username) {
		String sql = "SELECT * FROM users WHERE username=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { username }, new RowMapper<RegisterUser>() {
			@Override
			public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegisterUser user = new RegisterUser();
				user.setUsername(rs.getString("username"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setEmail(rs.getString("email"));
				user.setYear(rs.getString("year"));
				user.setBirthday(rs.getDate("birthday"));
				user.setContact(rs.getString("contact"));
				user.setGender(rs.getString("gender"));
				user.setRole_id(rs.getString("role_id"));
				user.setPassword(rs.getString("password"));
				user.setEncodeimg(rs.getString("img"));
				return user;
			}
		});

	}

//select student according to subject

//Select Lecturer according to username
	public RegisterUser getLecturerByUsername(String username) {
		String sql = "SELECT users.username,users.fname,users.lname,users.role_id, users.password, users.email,subjects.sub_year,subjects.sub_code,subjects.sub_name FROM users INNER JOIN subjects ON users.username=subjects.lec_id WHERE users.username=?";

		return jdbcTemplate.queryForObject(sql, new Object[] { username },
				new BeanPropertyRowMapper<RegisterUser>(RegisterUser.class));
	}

	class UserMapper implements RowMapper<RegisterUser> {

		public RegisterUser mapRow(ResultSet rs, int arg1) throws SQLException {
			RegisterUser user = new RegisterUser();

			user.setUsername(rs.getString("username"));
			user.setPassword(SHA1(rs.getString("password")));
			user.setRole_id(rs.getString("role_id"));
			user.setFname(rs.getString("fname"));
			user.setLname(rs.getString("lname"));
			user.setEmail(rs.getString("email"));
			user.setGender(rs.getString("gender"));
			user.setYear(rs.getString("year"));
			user.setBirthday(rs.getDate("birthday"));
			user.setContact(rs.getString("contact"));
			user.setEncodeimg(rs.getString("img"));
			user.setRole_id(rs.getString("role_id"));

			return user;
		}
	}

	public static String SHA1(String password) {
		try {
			MessageDigest mDigest = MessageDigest.getInstance("SHA1");
			byte[] result = mDigest.digest(password.getBytes());
			StringBuffer sb = new StringBuffer();

			for (int i = 0; i < result.length; i++) {
				sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
			}
			return sb.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public int studentprof(RegisterUser user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RegisterUser studentprof(LoginUser user) {
		// TODO Auto-generated method stub
		return null;
	}

}

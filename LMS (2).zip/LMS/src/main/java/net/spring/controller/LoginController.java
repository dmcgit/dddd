package net.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
@Scope("request")
public class LoginController {

	@Autowired
	UserService userService;

	@Autowired
	private UserDao userDao;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showLogin(@ModelAttribute("login") LoginUser login, BindingResult result) {
		return new ModelAndView("login", "login", new LoginUser());
	}

	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") LoginUser login) {
		RegisterUser user = userService.loginThreeRoles(login);
		if (null != user && user.getRole_id().equals("1")) {
			ModelAndView mav = new ModelAndView("studentdashboard");
			mav.addObject("username", user.getUsername());
			mav.addObject("fname", user.getFname());
			mav.addObject("lname", user.getLname());
			mav.addObject("email", user.getEmail());
			mav.addObject("year", user.getYear());
			mav.addObject("birthday", user.getBirthday());
			mav.addObject("contact", user.getContact());
			mav.addObject("role_id", user.getRole_id());
			mav.addObject("image", user.getEncodeimg());
			mav.addObject("gender", user.getGender());
			mav.addObject("password", user.getPassword());
			return mav;
		} else if (null != user && user.getRole_id().equals("2")) {
			ModelAndView mav = new ModelAndView("lecturerdashboard");
			mav.addObject("fname", user.getFname());
			mav.addObject("lname", user.getLname());
			mav.addObject("username", user.getUsername());
			mav.addObject("email", user.getEmail());
			mav.addObject("role_id", user.getRole_id());
			return mav;
		} else if (null != user && user.getRole_id().equals("3")) {
			ModelAndView mav = new ModelAndView("admindashboard");
			mav.addObject("email", user.getEmail());
			List<RegisterUser> liststudent = userDao.studentList();
			List<RegisterUser> listlecturer = userDao.lecturerList();
			mav.addObject("listStudent", liststudent);
			mav.addObject("listLecturer", listlecturer);
			return mav;
		} else {
			ModelAndView mav = new ModelAndView("login");
			mav.addObject("message", "Username or Password is wrong!!");
			return mav;
		}

	}


	@ModelAttribute
	public void getLoginbean(Model map) {
		map.addAttribute("login", new LoginUser());
	}

}

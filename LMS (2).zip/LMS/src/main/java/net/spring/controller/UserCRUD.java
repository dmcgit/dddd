package net.spring.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.spring.dao.UserDao;
import net.spring.model.LoginUser;
import net.spring.model.RegisterUser;
import net.spring.service.UserService;

@Controller
public class UserCRUD {

	@Autowired
	UserService userService;
	@Autowired
	private UserDao userDao;

	@RequestMapping(value = "/lecturer")
	public ModelAndView lecturercrud(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("lecturer");
		List<RegisterUser> listlecturer = userDao.lecturerList();
		mav.addObject("listLecturer", listlecturer);
		return mav;
	}

	@RequestMapping(value = "/student")
	public ModelAndView studentcrud(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("student");
		List<RegisterUser> liststudent = userDao.studentList();
		mav.addObject("listStudent", liststudent);
		return mav;
	}

	@RequestMapping(value = "/editstudent/{username}")
	public ModelAndView editstudent(@PathVariable String username, Model m) throws IOException {
		ModelAndView mav = new ModelAndView("editstudent");
		RegisterUser registerUser = userDao.getStudentByUsername(username);
//		String image = this.getBase64String(registerUser.getImg().getBytes());
//
//		registerUser.setEncodeimg(image);
		mav.addObject("registerUser", registerUser);
		return mav;
	}

	public String getBase64String(byte[] imageByteArray) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("data:image/jpg;base64,");
			sb.append(StringUtils.newStringUtf8(Base64.encodeBase64(imageByteArray, false)));
			return sb.toString();
		} catch (Exception e) {
			return "error = " + e;
		}
	}

	@RequestMapping(value = "/updatestudent/updatesave", method = RequestMethod.POST)
	public String updatesavestudent(@ModelAttribute("registerStudent") RegisterUser registerUser) {
		userDao.editstudent(registerUser);
		String username = registerUser.getUsername();
		return "redirect:/studentprofile/" + username;
	}

	@RequestMapping(value = "/updatelecturer/updatesave", method = RequestMethod.POST)
	public String updatesavelecturer(@ModelAttribute("registerLecturer") RegisterUser registerUser) {
		userDao.editlecturer(registerUser);
		String username = registerUser.getUsername();
		return "redirect:/lecturerprofile/" + username;

	}

	@RequestMapping(value = "/editlecturer/{username}")
	public ModelAndView editlecturer(@PathVariable String username, Model m) {
		ModelAndView mav = new ModelAndView("editlecturer");
		RegisterUser registerUser = userDao.getLecturerByUsername(username);
		mav.addObject("registerUser", registerUser);
		return mav;
	}

	@RequestMapping(value = "/updatestudent/{username}")
	public ModelAndView updatestudent(@PathVariable String username, Model m) {
		ModelAndView mav = new ModelAndView("updatestudent");
		RegisterUser registerUser = userDao.getStudentByUsername(username);
		mav.addObject("registerUser", registerUser);
		return mav;
	}

	@RequestMapping(value = "/updatelecturer/{username}")
	public ModelAndView updatelecturer(@PathVariable String username, Model m) {
		ModelAndView mav = new ModelAndView("updatelecturer");
		RegisterUser registerUser = userDao.getLecturerByUsername(username);
		mav.addObject("registerUser", registerUser);
		return mav;
	}

	@RequestMapping(value = "/editstudent/editsave", method = RequestMethod.POST)
	public String editsavestudent(@ModelAttribute("registerStudent") RegisterUser registerUser) {
		userDao.editstudent(registerUser);
		return "redirect:/student";
	}

	@RequestMapping(value = "/editlecturer/editsave", method = RequestMethod.POST)
	public String editsavelecturer(@ModelAttribute("registerLecturer") RegisterUser registerUser) {
		userDao.editlecturer(registerUser);
		return "redirect:/lecturer";
	}

	@RequestMapping(value = "/deletestudent/{username}", method = RequestMethod.GET)
	public String deletestudent(@PathVariable String username) {
		userDao.deletestudent(username);
		return "redirect:/student";
	}

	@RequestMapping(value = "/deletelecturer/{username}", method = RequestMethod.GET)
	public String deletelecturer(@PathVariable String username) {
		userDao.deletelecturer(username);
		return "redirect:/lecturer";
	}

	@RequestMapping(value = "/studentprofile/{username}")
	public ModelAndView studentprof(@PathVariable String username, Model m) {
		ModelAndView mav = new ModelAndView("studentprofile");

		RegisterUser user = userDao.getStudentByUsername(username);
		mav.addObject("username", user.getUsername());
		mav.addObject("fname", user.getFname());
		mav.addObject("lname", user.getLname());
		mav.addObject("email", user.getEmail());
		mav.addObject("year", user.getYear());
		mav.addObject("birthday", user.getBirthday());
		mav.addObject("contact", user.getContact());
		mav.addObject("role_id", user.getRole_id());
		mav.addObject("image", user.getEncodeimg());
		mav.addObject("gender", user.getGender());
		mav.addObject("password", user.getPassword());
		m.addAttribute("command", user);
		return mav;
	}

	@RequestMapping(value = "/lecturerprofile/{username}")
	public ModelAndView lecturerprof(@PathVariable String username, Model m) {
		ModelAndView mav = new ModelAndView("lecturerprofile");
		RegisterUser user = userDao.getLecturerByUsername(username);
		mav.addObject("username", user.getUsername());
		mav.addObject("fname", user.getFname());
		mav.addObject("lname", user.getLname());
		mav.addObject("email", user.getEmail());
		mav.addObject("role_id", user.getRole_id());
		mav.addObject("sub_name", user.getSub_name());
		mav.addObject("sub_code", user.getSub_code());
		mav.addObject("password", user.getPassword());
		m.addAttribute("command", user);
		return mav;
	}

	@RequestMapping(value = "/downloadstudentspdf", method = RequestMethod.GET)
	public void studentsdetailspdf(HttpServletResponse response) throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/studentlist.jasper");
			List<RegisterUser> registerStudent = userDao.studentList();
			Map<String, Object> map = new HashMap<String, Object>();
			JRBeanCollectionDataSource datasource = new JRBeanCollectionDataSource(registerStudent);
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, datasource);
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=studentsdetails.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}

	@RequestMapping(value = "/downloadlecturerspdf", method = RequestMethod.GET)
	public void lecturersdetailspdf(HttpServletResponse response) throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/lecturerlist.jasper");
			List<RegisterUser> registerLecturer = userDao.lecturerList();
			JRBeanCollectionDataSource datasource = new JRBeanCollectionDataSource(registerLecturer);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("registerlecturer", registerLecturer);
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, datasource);
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=lecturersdetails.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}
	
	@RequestMapping(value = "/downloadsubjectspdf/{username}", method = RequestMethod.GET)
	public void subjectsdetailspdf(@PathVariable String username,HttpServletResponse response) throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/subjectlist.jasper");
			RegisterUser user = userDao.getStudentByUsername(username);
			String year = user.getYear();
			List<RegisterUser> Subjects = userDao.subjectlist(username, year);
			JRBeanCollectionDataSource datasource = new JRBeanCollectionDataSource(Subjects);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("subjects", Subjects);
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, datasource);
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=subjectsdetails.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}

	@RequestMapping(value = "/downloadstudentsubpdf/{username}", method = RequestMethod.GET)
	public void lecturerssubdetailspdf(@PathVariable String username, HttpServletResponse response)
			throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/studentsublist.jasper");
			RegisterUser user = userDao.getLecturerByUsername(username);
			String year = user.getSub_year();
			String sub_name = user.getSub_name();
			List<RegisterUser> studentsList = userDao.studentsubject(year, sub_name);
			JRBeanCollectionDataSource datasource = new JRBeanCollectionDataSource(studentsList);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("studentslist", studentsList);
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, datasource);
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=studentsubdetails.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}

	@RequestMapping(value = "/studentpdf/{username}", method = RequestMethod.GET)
	public void studentpdf(@PathVariable String username, HttpServletResponse response)
			throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/student.jasper");
			RegisterUser registerStudent = userDao.getStudentByUsername(username);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("username", registerStudent.getUsername());
			map.put("fname", registerStudent.getFname());
			map.put("lname", registerStudent.getLname());
			map.put("email", registerStudent.getEmail());
			map.put("year", registerStudent.getYear());
			map.put("birthday", registerStudent.getBirthday());
			map.put("gender", registerStudent.getGender());
			map.put("contact", registerStudent.getContact());
			map.put("role_id", registerStudent.getRole_id());
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, new JREmptyDataSource());
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=student.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}

	@RequestMapping(value = "/lecturerpdf/{username}", method = RequestMethod.GET)
	public void lecturerpdf(@PathVariable String username, HttpServletResponse response)
			throws JRException, IOException {
		try {
			InputStream jasperStream = this.getClass().getResourceAsStream("/reports/lecturer.jasper");
			RegisterUser registerLecturer = userDao.getLecturerByUsername(username);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("username", registerLecturer.getUsername());
			map.put("fname", registerLecturer.getFname());
			map.put("lname", registerLecturer.getLname());
			map.put("email", registerLecturer.getEmail());
			map.put("sub_name", registerLecturer.getSub_name());
			map.put("sub_code", registerLecturer.getSub_code());
			map.put("role_id", registerLecturer.getRole_id());
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, new JREmptyDataSource());
			/* response.setContentType("application/pdf"); */
			response.setContentType("application/x-download");
			response.setHeader("Content-disposition", "inline; filename=lecturer.pdf");
			final OutputStream outStream = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
		} catch (Exception e) {
			System.out.println("Exception " + e);
		}

	}

	@RequestMapping(value = "/subject/{username}")
	public ModelAndView studentsubject(@RequestParam(required = false, name = "year") String year,
			@RequestParam(required = false, name = "sub_name") String sub_name, @PathVariable String username,
			HttpServletResponse response) {
		RegisterUser user = userDao.getLecturerByUsername(username);
		year = user.getSub_year();
		sub_name = user.getSub_name();
		ModelAndView mav = new ModelAndView("subjects");
		List<RegisterUser> liststudent = userDao.studentsubject(year, sub_name);
		mav.addObject("studentList", liststudent);
		return mav;
	}

	@RequestMapping(value = "/subjectlist/{username}")
	public ModelAndView subjectlist(@RequestParam(required = false, name = "year") String year, @PathVariable String username, HttpServletResponse response) {
		RegisterUser user = userDao.getStudentByUsername(username);
		year = user.getYear();
		ModelAndView mav = new ModelAndView("subjectlist");
		List<RegisterUser> subjectList = userDao.subjectlist(username, year);
		mav.addObject("subjectList", subjectList);
		return mav;
	}

}

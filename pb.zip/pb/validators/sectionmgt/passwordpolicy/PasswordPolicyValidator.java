package com.epic.pb.validators.sectionmgt.passwordpolicy;

import com.epic.pb.mapping.passwordpolicy.PasswordPolicy;
import com.epic.pb.util.validation.Validation;
import com.epic.pb.util.varlist.CommonVarList;
import com.epic.pb.util.varlist.MessageVarList;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.lang.reflect.Field;
import java.util.SortedMap;
import java.util.TreeMap;

@Component
public class PasswordPolicyValidator implements Validator {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonVarList commonVarList;

    @Autowired
    Validation validation;

    @Override
    public boolean supports(Class<?> aClass) {
        return PasswordPolicy.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        try {
            SortedMap<String, Field> allFields = new TreeMap<>();
            //get fields from dto
            for (Field field : o.getClass().getDeclaredFields()) {
                allFields.put(field.getName(), field);
            }

            if (o.getClass().equals(PasswordPolicy.class)) {
                Field[] requiredFields = this.getRequiredFields(allFields, (PasswordPolicy) o);
                //validate fields
                for (Field field : requiredFields) {
                    field.setAccessible(true);
                    String fieldName = field.getName();

                    if (fieldName.equals("passwordPolicyId")) {
                        //validate the null and empty in passwordparam
                        String passwordparam = String.valueOf(((PasswordPolicy) o).getPasswordPolicyId());
                        if (validation.isEmptyFieldValue(passwordparam)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORDPOLICYID, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORDPOLICYID);
                        }

                    } else if (fieldName.equals("minimumLength")) {
                        //validate the null and empty in userroletype
                        String userroletype = String.valueOf(((PasswordPolicy) o).getMinimumLength());
                        if (validation.isEmptyFieldValue(userroletype)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LENGTH, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LENGTH);
                        }
                    } else if (fieldName.equals("maximumLength")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMaximumLength());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MAXIMUM_LENGTH, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MAXIMUM_LENGTH);
                        }
                    } else if (fieldName.equals("minimumSpecialCharacters")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMinimumSpecialCharacters());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_SPECIAL_CHARACTERS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_SPECIAL_CHARACTERS);
                        }
                    } else if (fieldName.equals("minimumUpperCaseCharacters")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMinimumUpperCaseCharacters());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_UPPERCASE_CHARACTERS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_UPPERCASE_CHARACTERS);
                        }
                    } else if (fieldName.equals("minimumNumericalCharacters")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMinimumNumericalCharacters());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_NUMERICAL_CHARACTERS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_NUMERICAL_CHARACTERS);
                        }
                    } else if (fieldName.equals("minimumLowerCaseCharacters")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMinimumLowerCaseCharacters());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LOWERCASE_CHARACTERS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LOWERCASE_CHARACTERS);
                        }
                    } else if (fieldName.equals("noOfInvalidLoginAttempt")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getNoOfInvalidLoginAttempt());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_INVALID_LOGIN_ATTEMPTS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_INVALID_LOGIN_ATTEMPTS);
                        }
                    } else if (fieldName.equals("repeatCharactersAllow")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getRepeatCharactersAllow());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_REPEAT_CHARACTER_ALLOW, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_REPEAT_CHARACTER_ALLOW);
                        }
                    } else if (fieldName.equals("initialPasswordExpiryStatus")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getInitialPasswordExpiryStatus());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_STATUS, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_STATUS);
                        }
                    } else if (fieldName.equals("passwordExpiryPeriod")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getPasswordExpiryPeriod());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_PERIOD, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_PERIOD);
                        }
                    } else if (fieldName.equals("noOfHistoryPassword")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getNoOfHistoryPassword());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_NO_OF_HISTORY_PASSWORD, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_NO_OF_HISTORY_PASSWORD);
                        }
                    } else if (fieldName.equals("minimumPasswordChangePeriod")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getMinimumPasswordChangePeriod());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MIN_PASSWORD_CHANGE_PERIOD, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_MIN_PASSWORD_CHANGE_PERIOD);
                        }
                    } else if (fieldName.equals("idleAccountExpiryPeriod")) {
                        //validate the null and empty in value
                        String value = String.valueOf(((PasswordPolicy) o).getIdleAccountExpiryPeriod());
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_IDLE_ACCOUNT_EXPIRY_PERIOD, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_IDLE_ACCOUNT_EXPIRY_PERIOD);
                        }
                    } else if (fieldName.equals("description")) {
                        //validate the null and empty in value
                        String value = ((PasswordPolicy) o).getDescription();
                        if (validation.isEmptyFieldValue(value)) {
                            errors.rejectValue(fieldName, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_DESCRIPTION, MessageVarList.PASSWORD_POLICY_MGT_EMPTY_DESCRIPTION);
                        }
                    }
                }
            } else {
                errors.reject(commonVarList.COMMON_VALIDATION_INVALID_BEANTYPE);
            }
        } catch (Exception ex) {
            logger.error("Exception : ", ex);
            errors.reject(commonVarList.COMMON_VALIDATION_FAIL_CODE);
        }
    }

    private Field[] getRequiredFields(SortedMap<String, Field> allFields, PasswordPolicy o) {
        return new Field[]{
                allFields.get("passwordPolicyId"),
                allFields.get("minimumLength"),
                allFields.get("maximumLength"),
                allFields.get("minimumSpecialCharacters"),
                allFields.get("minimumUpperCaseCharacters"),
                allFields.get("minimumNumericalCharacters"),
                allFields.get("minimumLowerCaseCharacters"),
                allFields.get("noOfInvalidLoginAttempt"),
                allFields.get("repeatCharactersAllow"),
                allFields.get("initialPasswordExpiryStatus"),
                allFields.get("passwordExpiryPeriod"),
                allFields.get("noOfHistoryPassword"),
                allFields.get("minimumPasswordChangePeriod"),
                allFields.get("idleAccountExpiryPeriod"),
                allFields.get("description")
        };
    }
}

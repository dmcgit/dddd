package com.epic.pb.bean.sectionmanagement.passwordpolicy;

/*
        User: suren_v
        Date: 2/1/2021
        Time: 10:54 AM
 */

import com.epic.pb.util.common.DataTablesRequest;

public class PasswordPolicyInputBean extends DataTablesRequest {
    private String passwordPolicyId;
    private String minimumLength;
    private String maximumLength;
    private String minimumSpecialCharacters;
    private String minimumUpperCaseCharacters;
    private String minimumNumericalCharacters;
    private String minimumLowerCaseCharacters;
    private String noOfInvalidLoginAttempt;
    private String repeatCharactersAllow;
    private String initialPasswordExpiryStatus;
    private String passwordExpiryPeriod;
    private String noOfHistoryPassword;
    private String minimumPasswordChangePeriod;
    private String idleAccountExpiryPeriod;
    private String description;
    private String lastUpdatedUser;

    /*-------for access control-----------*/
    private boolean vadd;
    private boolean vupdate;
    private boolean vdelete;
    private boolean vconfirm;
    private boolean vreject;
    private boolean vdualauth;
    /*-------for access control-----------*/

    public PasswordPolicyInputBean() {
    }

    public PasswordPolicyInputBean(String passwordPolicyId, String minimumLength, String maximumLength, String minimumSpecialCharacters, String minimumUpperCaseCharacters, String minimumNumericalCharacters, String minimumLowerCaseCharacters, String noOfInvalidLoginAttempt, String repeatCharactersAllow, String initialPasswordExpiryStatus, String passwordExpiryPeriod, String noOfHistoryPassword, String minimumPasswordChangePeriod, String idleAccountExpiryPeriod, String description, String lastUpdatedUser) {
        this.passwordPolicyId = passwordPolicyId;
        this.minimumLength = minimumLength;
        this.maximumLength = maximumLength;
        this.minimumSpecialCharacters = minimumSpecialCharacters;
        this.minimumUpperCaseCharacters = minimumUpperCaseCharacters;
        this.minimumNumericalCharacters = minimumNumericalCharacters;
        this.minimumLowerCaseCharacters = minimumLowerCaseCharacters;
        this.noOfInvalidLoginAttempt = noOfInvalidLoginAttempt;
        this.repeatCharactersAllow = repeatCharactersAllow;
        this.initialPasswordExpiryStatus = initialPasswordExpiryStatus;
        this.passwordExpiryPeriod = passwordExpiryPeriod;
        this.noOfHistoryPassword = noOfHistoryPassword;
        this.minimumPasswordChangePeriod = minimumPasswordChangePeriod;
        this.idleAccountExpiryPeriod = idleAccountExpiryPeriod;
        this.description = description;
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public String getPasswordPolicyId() {
        return passwordPolicyId;
    }

    public void setPasswordPolicyId(String passwordPolicyId) {
        this.passwordPolicyId = passwordPolicyId;
    }

    public String getMinimumLength() {
        return minimumLength;
    }

    public void setMinimumLength(String minimumLength) {
        this.minimumLength = minimumLength;
    }

    public String getMaximumLength() {
        return maximumLength;
    }

    public void setMaximumLength(String maximumLength) {
        this.maximumLength = maximumLength;
    }

    public String getMinimumSpecialCharacters() {
        return minimumSpecialCharacters;
    }

    public void setMinimumSpecialCharacters(String minimumSpecialCharacters) {
        this.minimumSpecialCharacters = minimumSpecialCharacters;
    }

    public String getMinimumUpperCaseCharacters() {
        return minimumUpperCaseCharacters;
    }

    public void setMinimumUpperCaseCharacters(String minimumUpperCaseCharacters) {
        this.minimumUpperCaseCharacters = minimumUpperCaseCharacters;
    }

    public String getMinimumNumericalCharacters() {
        return minimumNumericalCharacters;
    }

    public void setMinimumNumericalCharacters(String minimumNumericalCharacters) {
        this.minimumNumericalCharacters = minimumNumericalCharacters;
    }

    public String getMinimumLowerCaseCharacters() {
        return minimumLowerCaseCharacters;
    }

    public void setMinimumLowerCaseCharacters(String minimumLowerCaseCharacters) {
        this.minimumLowerCaseCharacters = minimumLowerCaseCharacters;
    }

    public String getNoOfInvalidLoginAttempt() {
        return noOfInvalidLoginAttempt;
    }

    public void setNoOfInvalidLoginAttempt(String noOfInvalidLoginAttempt) {
        this.noOfInvalidLoginAttempt = noOfInvalidLoginAttempt;
    }

    public String getRepeatCharactersAllow() {
        return repeatCharactersAllow;
    }

    public void setRepeatCharactersAllow(String repeatCharactersAllow) {
        this.repeatCharactersAllow = repeatCharactersAllow;
    }

    public String getInitialPasswordExpiryStatus() {
        return initialPasswordExpiryStatus;
    }

    public void setInitialPasswordExpiryStatus(String initialPasswordExpiryStatus) {
        this.initialPasswordExpiryStatus = initialPasswordExpiryStatus;
    }

    public String getPasswordExpiryPeriod() {
        return passwordExpiryPeriod;
    }

    public void setPasswordExpiryPeriod(String passwordExpiryPeriod) {
        this.passwordExpiryPeriod = passwordExpiryPeriod;
    }

    public String getNoOfHistoryPassword() {
        return noOfHistoryPassword;
    }

    public void setNoOfHistoryPassword(String noOfHistoryPassword) {
        this.noOfHistoryPassword = noOfHistoryPassword;
    }

    public String getMinimumPasswordChangePeriod() {
        return minimumPasswordChangePeriod;
    }

    public void setMinimumPasswordChangePeriod(String minimumPasswordChangePeriod) {
        this.minimumPasswordChangePeriod = minimumPasswordChangePeriod;
    }

    public String getIdleAccountExpiryPeriod() {
        return idleAccountExpiryPeriod;
    }

    public void setIdleAccountExpiryPeriod(String idleAccountExpiryPeriod) {
        this.idleAccountExpiryPeriod = idleAccountExpiryPeriod;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public boolean isVadd() {
        return vadd;
    }

    public void setVadd(boolean vadd) {
        this.vadd = vadd;
    }

    public boolean isVupdate() {
        return vupdate;
    }

    public void setVupdate(boolean vupdate) {
        this.vupdate = vupdate;
    }

    public boolean isVdelete() {
        return vdelete;
    }

    public void setVdelete(boolean vdelete) {
        this.vdelete = vdelete;
    }

    public boolean isVconfirm() {
        return vconfirm;
    }

    public void setVconfirm(boolean vconfirm) {
        this.vconfirm = vconfirm;
    }

    public boolean isVreject() {
        return vreject;
    }

    public void setVreject(boolean vreject) {
        this.vreject = vreject;
    }

    public boolean isVdualauth() {
        return vdualauth;
    }

    public void setVdualauth(boolean vdualauth) {
        this.vdualauth = vdualauth;
    }
}

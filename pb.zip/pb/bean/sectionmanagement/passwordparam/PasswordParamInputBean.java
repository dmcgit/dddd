package com.epic.pb.bean.sectionmanagement.passwordparam;

import com.epic.pb.bean.common.CommonPasswordParamBean;
import com.epic.pb.bean.usermanagement.userrole.UserRoleBean;
import com.epic.pb.bean.usermanagement.userroletype.UserRoleTypeBean;
import com.epic.pb.util.common.DataTablesRequest;

import java.util.List;

/*
        User: suren_v
        Date: 2/1/2021
        Time: 10:54 AM
 */

public class PasswordParamInputBean extends DataTablesRequest {
    private String passwordparam;
    private String userroletype;
    private String value;
    private String createdtime;

    /*-------for access control-----------*/
    private boolean vadd;
    private boolean vupdate;
    private boolean vdelete;
    private boolean vconfirm;
    private boolean vreject;
    private boolean vdualauth;
    /*-------for access control-----------*/

    private List<UserRoleTypeBean> userRoleTypeBeanList;
    private List<CommonPasswordParamBean> passwordParamBeanList;

    public String getPasswordparam() {
        return passwordparam;
    }

    public void setPasswordparam(String passwordparam) {
        this.passwordparam = passwordparam;
    }

    public String getUserroletype() {
        return userroletype;
    }

    public void setUserroletype(String userroletype) {
        this.userroletype = userroletype;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCreatedtime() {
        return createdtime;
    }

    public void setCreatedtime(String createdtime) {
        this.createdtime = createdtime;
    }

    public List<UserRoleTypeBean> getUserRoleTypeBeanList() {
        return userRoleTypeBeanList;
    }

    public void setUserRoleTypeBeanList(List<UserRoleTypeBean> userRoleTypeBeanList) {
        this.userRoleTypeBeanList = userRoleTypeBeanList;
    }

    public List<CommonPasswordParamBean> getPasswordParamBeanList() {
        return passwordParamBeanList;
    }

    public void setPasswordParamBeanList(List<CommonPasswordParamBean> passwordParamBeanList) {
        this.passwordParamBeanList = passwordParamBeanList;
    }

    public boolean isVadd() {
        return vadd;
    }

    public void setVadd(boolean vadd) {
        this.vadd = vadd;
    }

    public boolean isVupdate() {
        return vupdate;
    }

    public void setVupdate(boolean vupdate) {
        this.vupdate = vupdate;
    }

    public boolean isVdelete() {
        return vdelete;
    }

    public void setVdelete(boolean vdelete) {
        this.vdelete = vdelete;
    }

    public boolean isVconfirm() {
        return vconfirm;
    }

    public void setVconfirm(boolean vconfirm) {
        this.vconfirm = vconfirm;
    }

    public boolean isVreject() {
        return vreject;
    }

    public void setVreject(boolean vreject) {
        this.vreject = vreject;
    }

    public boolean isVdualauth() {
        return vdualauth;
    }

    public void setVdualauth(boolean vdualauth) {
        this.vdualauth = vdualauth;
    }
}

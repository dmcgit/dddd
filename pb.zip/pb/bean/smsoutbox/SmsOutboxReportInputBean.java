package com.epic.pb.bean.smsoutbox;

import com.epic.pb.mapping.department.Department;
import com.epic.pb.mapping.smschannel.SmsChannel;
import com.epic.pb.mapping.telco.Telco;
import com.epic.pb.util.common.DataTablesRequest;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class SmsOutboxReportInputBean extends DataTablesRequest {
    private String fromDate;
    private String toDate;
    private String telco;
    private String department;
    private String channel;
    /*-------for access control-----------*/
    private boolean vdownload;
    /*-------for access control-----------*/
    private List<Telco> telcoList;
    private List<Department> departmentList;
    private List<SmsChannel> smsChannelList;
}

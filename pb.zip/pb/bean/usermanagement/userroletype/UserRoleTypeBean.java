package com.epic.pb.bean.usermanagement.userroletype;

public class UserRoleTypeBean {
    private String userroletypecode;
    private String description;

    public String getUserroletypecode() {
        return userroletypecode;
    }

    public void setUserroletypecode(String userroletypecode) {
        this.userroletypecode = userroletypecode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

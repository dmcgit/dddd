package com.epic.pb.bean.usermgt.task;

import com.epic.pb.bean.common.Status;
import com.epic.pb.util.common.DataTablesRequest;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class TaskInputBean extends DataTablesRequest {
    private String taskCode;
    private String description;
    private String status;
    private String createdTime;

    /*-------for access control-----------*/
    private boolean vadd;
    private boolean vupdate;
    private boolean vdelete;
    private boolean vconfirm;
    private boolean vreject;
    private boolean vdualauth;
    /*-------for access control-----------*/

    private List<Status> statusList;
    private List<Status> statusActList;

}

package com.epic.pb.bean.usermgt.systemuser;

import com.epic.pb.bean.common.Status;
import com.epic.pb.mapping.usermgt.UserRole;
import com.epic.pb.util.common.DataTablesRequest;
import lombok.*;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class SystemUserInputBean extends DataTablesRequest {
    private String userTask;
    private String userName;
    private String fullName;
    private String email;
    private String userRoleCode;
    private Date expiryDate;
    private String status;
    private String mobileNumber;
    private int initialLoginStatus;
    private int ad;
    private String password;
    private String confirmPassword;
    private Date createdTime;
    private Date lastUpdatedTime;
    private String lastUpdatedUser;

    /*-------for access control-----------*/
    private boolean vadd;
    private boolean vupdate;
    private boolean vdelete;
    private boolean vconfirm;
    private boolean vreject;
    private boolean vdualauth;
    /*-------for access control-----------*/

    private List<Status> statusList;
    private List<Status> statusActList;
    private List<UserRole> userRoleList;
}

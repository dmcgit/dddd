package com.epic.pb.repository.usermgt.section;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.section.SectionInputBean;
import com.epic.pb.bean.usermgt.userrole.UserRoleInputBean;
import com.epic.pb.mapper.usermgt.page.PageDataMapper;
import com.epic.pb.mapper.usermgt.section.SectionDataMapper;
import com.epic.pb.mapper.usermgt.userrole.UserRoleDualMapper;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.util.varlist.CommonVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Scope("prototype")
public class SectionRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM WEB_SECTION WS LEFT OUTER JOIN STATUS S ON S.STATUSCODE=WS.STATUS WHERE ";
    private final String SQL_INSERT_TASK = "INSERT INTO WEB_SECTION (SECTIONCODE,DESCRIPTION,SORTKEY,STATUS,CREATEDTIME,LASTUPDATEDTIME,LASTUPDATEDUSER) VALUES (?,?,?,?,?,?,?) ";
    private final String SQL_UPDATE_TASK = "UPDATE WEB_SECTION SET DESCRIPTION=?,STATUS=?,LASTUPDATEDUSER=?,LASTUPDATEDTIME=? WHERE SECTIONCODE=?";
    private final String SQL_FIND_TASK = "SELECT WS.SECTIONCODE,WS.DESCRIPTION,WS.STATUS,WS.CREATEDTIME,WS.LASTUPDATEDTIME,WS.LASTUPDATEDUSER FROM WEB_SECTION WS WHERE WS.SECTIONCODE = ? ";
    private final String SQL_DELETE_TASK = "DELETE FROM WEB_SECTION WHERE SECTIONCODE=?";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";


    @Transactional(readOnly = true)
    public long getDataCount(SectionInputBean inputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();

        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(inputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<SectionInputBean> getSectionSearchResults(SectionInputBean inputBean) throws Exception {
        List<SectionInputBean> sectionList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClause(inputBean, dynamicClause);

            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by WS.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by WS.CREATEDTIME " + inputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT WS.SECTIONCODE, WS.DESCRIPTION, WS.SORTKEY, WS.STATUS, S.DESCRIPTION AS STATUSDES, WS.CREATEDTIME, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_SECTION WS LEFT OUTER JOIN STATUS S ON S.STATUSCODE=WS.STATUS "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            sectionList = jdbcTemplate.query(sql, new SectionDataMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return sectionList;
    }

    private void setDynamicClause(SectionInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getSectionCode() != null && !inputBean.getSectionCode().isEmpty()) {
            dynamicClause.append("and WS.SECTIONCODE like '%").append(inputBean.getSectionCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and WS.DESCRIPTION like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and WS.STATUS = '").append(inputBean.getStatus()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(SectionInputBean inputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(inputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getSectionSearchResultsDual(SectionInputBean inputBean) throws Exception {
        List<TempAuthRecBean> sectionDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(inputBean, dynamicClause);
            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + inputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID, D.KEY1, D.KEY2, D.KEY3, S.DESCRIPTION KEY4, T.DESCRIPTION TASK, D.CREATEDTIME, D.LASTUPDATEDTIME, D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=D.KEY4 "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            sectionDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, new UserRoleDualMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }

        return sectionDualList;
    }

    private void setDynamicClauseDual(SectionInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getSectionCode() != null && !inputBean.getSectionCode().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(inputBean.getSectionCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY2 like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and D.KEY4 = '").append(inputBean.getStatus()).append("'");
        }
    }

    public List<TempAuthRecBean> getSectionSearchResultsDual(UserRoleInputBean inputBean) throws Exception {
        List<TempAuthRecBean> sectionDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(inputBean, dynamicClause);
            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + inputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID, D.KEY1, D.KEY2, D.KEY3, S.DESCRIPTION KEY4, T.DESCRIPTION TASK, D.CREATEDTIME, D.LASTUPDATEDTIME, D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=D.KEY4 "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            pageDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, new UserRoleDualMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }

        return pageDualList;
    }

    private void setDynamicClauseDual(UserRoleInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getUserroleCode() != null && !inputBean.getUserroleCode().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(inputBean.getUserroleCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY2 like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getUserroleType() != null && !inputBean.getUserroleType().isEmpty()) {
            dynamicClause.append("and D.KEY3 = '").append(inputBean.getUserroleType()).append("'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and D.KEY4 = '").append(inputBean.getStatus()).append("'");
        }
    }

}

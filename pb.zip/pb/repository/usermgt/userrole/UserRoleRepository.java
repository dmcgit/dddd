package com.epic.pb.repository.usermgt.userrole;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.userrole.UserRoleInputBean;
import com.epic.pb.mapper.usermgt.userrole.UserRoleDataMapper;
import com.epic.pb.mapper.usermgt.userrole.UserRoleDualMapper;
import com.epic.pb.mapper.usermgt.userrole.UserRoleMapper;
import com.epic.pb.mapping.usermgt.Page;
import com.epic.pb.mapping.usermgt.Section;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.mapping.usermgt.UserRole;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
@Scope("prototype")
public class UserRoleRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM USERROLE U LEFT OUTER JOIN STATUS S ON S.STATUSCODE=U.STATUS WHERE ";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";
    private final String SQL_INSERT_USERROLE = "INSERT INTO USERROLE (USERROLECODE, DESCRIPTION, USERROLETYPE, STATUS, CREATEDTIME, LASTUPDATEDTIME, LASTUPDATEDUSER) values (?,?,?,?,?,?,?) ";
    private final String SQL_FIND_USERROLE = "SELECT U.USERROLECODE, U.DESCRIPTION, U.USERROLETYPE, U.STATUS, U.CREATEDTIME, U.LASTUPDATEDTIME, U.LASTUPDATEDUSER FROM USERROLE U WHERE U.USERROLECODE = ? ";
    private final String SQL_UPDATE_USERROLE = "UPDATE USERROLE SET DESCRIPTION=?, USERROLETYPE=?, STATUS=?, LASTUPDATEDUSER=?, LASTUPDATEDTIME=? WHERE USERROLECODE=?";
    private final String SQL_DELETE_USERROLE = "DELETE FROM USERROLE WHERE USERROLECODE=?";
    private final String SQL_GET_ALL_SECTION_LIST = "SELECT SECTIONCODE, DESCRIPTION FROM WEB_SECTION ";
    private final String SQL_GET_ASSIGNED_PAGE_LIST = "SELECT P.PAGECODE PAGECODE, P.DESCRIPTION DESCRIPTION FROM WEB_SECTIONPAGE SP INNER JOIN WEB_PAGE P ON P.PAGECODE=SP.PAGE WHERE SP.USERROLE=? AND SP.SECTION=?";
    private final String SQL_GET_ALL_PAGE_LIST = "SELECT PAGECODE, DESCRIPTION FROM WEB_PAGE ";
    private final String SQL_GET_ASSIGNED_PAGE_LIST_FOR_USERROLE = "SELECT P.PAGECODE PAGECODE, P.DESCRIPTION DESCRIPTION FROM WEB_SECTIONPAGE SP INNER JOIN WEB_PAGE P ON P.PAGECODE=SP.PAGE WHERE SP.USERROLE=?";
    private final String SQL_UNASSIGNED_PAGE_TASK = "DELETE FROM WEB_PAGETASK  WHERE USERROLE=:USERROLE AND PAGE IN (:PAGES) ";
    private final String SQL_UNASSIGNED_PAGE = "DELETE FROM WEB_SECTIONPAGE WHERE USERROLE=:USERROLE AND PAGE IN (:PAGES) ";
    private final String SQL_ASSIGNED_PAGE = "INSERT INTO WEB_SECTIONPAGE (USERROLE, SECTION, PAGE, LASTUPDATEDUSER) VALUES (?,?,?,?) ";


    //private final String SQL_GET_UNASSIGNED_PAGE_LIST = "SELECT WP.PAGECODE, WP.DESCRIPTION FROM WEB_PAGE WP FULL OUTER JOIN WEB_SECTIONPAGE WSP ON WSP.PAGE=WP.PAGECODE WHERE WP.STATUS=? AND (WSP.USERROLE!=? OR WSP.USERROLE IS NULL)";


    private final String SQL_GET_ASSIGNED_SECTION_LIST = "SELECT DISTINCT S.SECTIONCODE SECTIONCODE, S.DESCRIPTION DESCRIPTION FROM WEB_SECTION S INNER JOIN WEB_SECTIONPAGE SP ON SP.SECTION=S.SECTIONCODE WHERE SP.USERROLE=? ";
    private final String SQL_GET_ASSIGNED_TASK_LIST = "SELECT T.TASKCODE TASKCODE, T.DESCRIPTION DESCRIPTION FROM WEB_TASK T INNER JOIN WEB_PAGETASK PT ON PT.TASK=T.TASKCODE WHERE PT.USERROLE=? AND PT.PAGE=? ";
    private final String SQL_GET_ALL_PAGE_TASK_LIST = "SELECT T.TASKCODE TASKCODE, T.DESCRIPTION DESCRIPTION FROM WEB_TASK T INNER JOIN WEB_PAGETASK_TEMPLATE PTT ON PTT.TASK=T.TASKCODE WHERE PTT.PAGE=? ";
    private final String SQL_UNASSIGNED_TASK = "DELETE FROM WEB_PAGETASK  WHERE USERROLE=:USERROLE AND PAGE=:PAGE AND TASK IN (:TASKS) ";
    private final String SQL_ASSIGNED_TASK = "INSERT INTO WEB_PAGETASK (USERROLE, PAGE, TASK, LASTUPDATEDUSER) VALUES (?,?,?,?) ";

    @Transactional(readOnly = true)
    public long getDataCount(UserRoleInputBean inputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();

        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(inputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<UserRoleInputBean> getUserRoleSearchResults(UserRoleInputBean inputBean) throws Exception {
        List<UserRoleInputBean> userRoleList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClause(inputBean, dynamicClause);

            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by U.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by U.CREATEDTIME " + inputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT U.USERROLECODE, U.DESCRIPTION, UT.DESCRIPTION AS USERROLETYPEDESC, U.STATUS, S.DESCRIPTION AS STATUSDES, U.CREATEDTIME, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM USERROLE U "
                    + "LEFT OUTER JOIN USERROLETYPE UT ON UT.USERROLETYPECODE=U.USERROLETYPE "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=U.STATUS "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            userRoleList = jdbcTemplate.query(sql, new UserRoleDataMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return userRoleList;
    }


    private void setDynamicClause(UserRoleInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getUserroleCode() != null && !inputBean.getUserroleCode().isEmpty()) {
            dynamicClause.append("and U.USERROLECODE like '%").append(inputBean.getUserroleCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and U.DESCRIPTION like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getUserroleType() != null && !inputBean.getUserroleType().isEmpty()) {
            dynamicClause.append("and U.USERROLETYPE = '").append(inputBean.getUserroleType()).append("'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and U.STATUS = '").append(inputBean.getStatus()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(UserRoleInputBean inputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(inputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getUserRoleSearchResultsDual(UserRoleInputBean inputBean) throws Exception {
        List<TempAuthRecBean> pageDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(inputBean, dynamicClause);
            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + inputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID, D.KEY1, D.KEY2, D.KEY3, S.DESCRIPTION KEY4, T.DESCRIPTION TASK, D.CREATEDTIME, D.LASTUPDATEDTIME, D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=D.KEY4 "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            pageDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, new UserRoleDualMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }

        return pageDualList;
    }

    private void setDynamicClauseDual(UserRoleInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getUserroleCode() != null && !inputBean.getUserroleCode().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(inputBean.getUserroleCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY2 like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getUserroleType() != null && !inputBean.getUserroleType().isEmpty()) {
            dynamicClause.append("and D.KEY3 = '").append(inputBean.getUserroleType()).append("'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and D.KEY4 = '").append(inputBean.getStatus()).append("'");
        }
    }

    @Transactional
    public String insertUserRole(UserRole userRole) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_INSERT_USERROLE,
                    new Object[]{
                            userRole.getUserroleCode(),
                            userRole.getDescription(),
                            userRole.getUserroleType(),
                            userRole.getStatus(),
                            userRole.getCreatedTime(),
                            userRole.getLastUpdatedTime(),
                            userRole.getLastUpdatedUser()
                    });

            if (value != 1) {
                message = MessageVarList.USERROLE_MGT_ERROR_ADD;
            }
        } catch (DuplicateKeyException ex) {
            throw ex;
        } catch (NumberFormatException | DataAccessException ex) {
            throw ex;
        }
        return message;
    }

    @Transactional(readOnly = true)
    public UserRole getUserRole(String userroleCode) throws Exception {
        UserRole userRole = null;
        try {
            userRole = jdbcTemplate.queryForObject(SQL_FIND_USERROLE, new Object[]{userroleCode}, new UserRoleMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return userRole;
    }

    @Transactional
    public String updateUserRole(UserRole userRole) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_UPDATE_USERROLE,
                    new Object[]{
                            userRole.getDescription(),
                            userRole.getUserroleType(),
                            userRole.getStatus(),
                            userRole.getLastUpdatedUser(),
                            userRole.getLastUpdatedTime(),
                            userRole.getUserroleCode()
                    });
            if (value != 1) {
                message = MessageVarList.USERROLE_MGT_ERROR_UPDATE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String deleteUserRole(String userroleCode) throws Exception {
        String message = "";
        int count = 0;
        try {
            count = jdbcTemplate.update(SQL_DELETE_USERROLE, new Object[]{userroleCode});
            if (count < 0) {
                message = MessageVarList.USERROLE_MGT_ERROR_DELETE;
            }
        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }

    @Transactional(readOnly = true)
    public List<Section> getAllSection() throws Exception {
        List<Section> sectionList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ALL_SECTION_LIST);
            sectionList = typeList.stream().map((record) -> {
                Section section = new Section();
                section.setSectionCode(record.get("SECTIONCODE").toString());
                section.setDescription(record.get("DESCRIPTION").toString());
                return section;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            sectionList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return sectionList;
    }

    @Transactional(readOnly = true)
    public List<Page> getAssignedPages(String userroleCode, String sectionCode) throws Exception {
        List<Page> assignedPageList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_PAGE_LIST, new Object[]{userroleCode, sectionCode});
            assignedPageList = typeList.stream().map((record) -> {
                Page page = new Page();
                page.setPageCode(record.get("PAGECODE").toString());
                page.setDescription(record.get("DESCRIPTION").toString());
                return page;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignedPageList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignedPageList;
    }

    @Transactional(readOnly = true)
    public List<Page> getAllPages() throws Exception {
        List<Page> allPageList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ALL_PAGE_LIST);
            allPageList = typeList.stream().map((record) -> {
                Page page = new Page();
                page.setPageCode(record.get("PAGECODE").toString());
                page.setDescription(record.get("DESCRIPTION").toString());
                return page;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            allPageList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return allPageList;
    }

    @Transactional(readOnly = true)
    public List<String> getAssignedPagesForUserrole(String userroleCode) throws Exception {
        List<String> assignedUserrolePageList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_PAGE_LIST_FOR_USERROLE, new Object[]{userroleCode});
            assignedUserrolePageList = typeList.stream().map((record) -> {
                return record.get("PAGECODE").toString();
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignedUserrolePageList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignedUserrolePageList;
    }

    @Transactional(readOnly = true)
    public List<String> getAssignedPageCodes(String userroleCode, String sectionCode) throws Exception {
        List<String> assignPageCodeList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_PAGE_LIST, new Object[]{userroleCode, sectionCode});
            assignPageCodeList = typeList.stream().map((record) -> {
                return record.get("PAGECODE").toString();
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignPageCodeList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignPageCodeList;
    }

    @Transactional
    public String assignPages(UserRole userRole) {
        String message = "";
        int count = 0;
        try {
            if (userRole.getUnAssignedList().size() > 0) {
                List<String> pages = userRole.getUnAssignedList();

                MapSqlParameterSource parameters = new MapSqlParameterSource();
                parameters.addValue("PAGES", pages);
                parameters.addValue("USERROLE", userRole.getUserroleCode());

                count = namedParameterJdbcTemplate.update(SQL_UNASSIGNED_PAGE_TASK, parameters);

                count = namedParameterJdbcTemplate.update(SQL_UNASSIGNED_PAGE, parameters);

                if (count < 0) {
                    message = MessageVarList.USERROLE_MGT_ERROR_UNASSIGNED_PAGE;
                }
            }

            if (message.isEmpty() && userRole.getAssignedList().size() > 0) {
                int numOfRows[] = jdbcTemplate.batchUpdate(
                        SQL_ASSIGNED_PAGE,
                        new BatchPreparedStatementSetter() {

                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                ps.setString(1, userRole.getUserroleCode());
                                ps.setString(2, userRole.getSection());
                                ps.setString(3, userRole.getAssignedList().get(i));
                                ps.setString(4, sessionBean.getUsername());
                            }

                            public int getBatchSize() {
                                return userRole.getAssignedList().size();
                            }

                        });

                if (numOfRows.length == 0) {
                    message = MessageVarList.USERROLE_MGT_ERROR_ASSIGNED_PAGE;
                }
            }

        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }


    @Transactional(readOnly = true)
    public List<Section> getAssignedSection(String userroleCode) throws Exception {
        List<Section> sectionList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_SECTION_LIST, new Object[]{userroleCode});
            sectionList = typeList.stream().map((record) -> {
                Section section = new Section();
                section.setSectionCode(record.get("SECTIONCODE").toString());
                section.setDescription(record.get("DESCRIPTION").toString());
                return section;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            sectionList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return sectionList;
    }

    @Transactional(readOnly = true)
    public List<Task> getAssignedTasks(String userroleCode, String pageCode) throws Exception {
        List<Task> assignTaskList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_TASK_LIST, new Object[]{userroleCode, pageCode});
            assignTaskList = typeList.stream().map((record) -> {
                Task task = new Task();
                task.setTaskCode(record.get("TASKCODE").toString());
                task.setDescription(record.get("DESCRIPTION").toString());
                return task;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignTaskList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignTaskList;
    }

    @Transactional(readOnly = true)
    public List<Task> getAllPageTasks(String pageCode) throws Exception {
        List<Task> allPageTaskList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ALL_PAGE_TASK_LIST, new Object[]{pageCode});
            allPageTaskList = typeList.stream().map((record) -> {
                Task task = new Task();
                task.setTaskCode(record.get("TASKCODE").toString());
                task.setDescription(record.get("DESCRIPTION").toString());
                return task;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            allPageTaskList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return allPageTaskList;
    }

    @Transactional(readOnly = true)
    public List<String> getAssignedTasksForUserrole(String userroleCode, String pageCode) throws Exception {
        List<String> assignedUserroleTaskList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_TASK_LIST, new Object[]{userroleCode, pageCode});
            assignedUserroleTaskList = typeList.stream().map((record) -> {
                return record.get("TASKCODE").toString();
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignedUserroleTaskList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignedUserroleTaskList;
    }


    @Transactional(readOnly = true)
    public List<String> getAssignedTaskCodes(String userroleCode, String pageCode) throws Exception {
        List<String> assignTaskCodeList;
        try {
            List<Map<String, Object>> typeList = jdbcTemplate.queryForList(SQL_GET_ASSIGNED_TASK_LIST, new Object[]{userroleCode, pageCode});
            assignTaskCodeList = typeList.stream().map((record) -> {
                return record.get("TASKCODE").toString();
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ere) {
            //handle the empty result data access exception
            assignTaskCodeList = new ArrayList<>();
        } catch (Exception e) {
            throw e;
        }
        return assignTaskCodeList;
    }

    @Transactional
    public String assignTasks(UserRole userRole) {
        String message = "";
        int count = 0;
        try {
            if (userRole.getUnAssignedList().size() > 0) {
                List<String> tasks = userRole.getUnAssignedList();

                MapSqlParameterSource parameters = new MapSqlParameterSource();
                parameters.addValue("USERROLE", userRole.getUserroleCode());
                parameters.addValue("PAGE", userRole.getPage());
                parameters.addValue("TASKS", tasks);

                count = namedParameterJdbcTemplate.update(SQL_UNASSIGNED_TASK, parameters);

                if (count < 0) {
                    message = MessageVarList.USERROLE_MGT_ERROR_UNASSIGNED_TASK;
                }
            }

            if (message.isEmpty() && userRole.getAssignedList().size() > 0) {
                int numOfRows[] = jdbcTemplate.batchUpdate(
                        SQL_ASSIGNED_TASK,
                        new BatchPreparedStatementSetter() {

                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                ps.setString(1, userRole.getUserroleCode());
                                ps.setString(2, userRole.getPage());
                                ps.setString(3, userRole.getAssignedList().get(i));
                                ps.setString(4, sessionBean.getUsername());
                            }

                            public int getBatchSize() {
                                return userRole.getAssignedList().size();
                            }

                        });

                if (numOfRows.length == 0) {
                    message = MessageVarList.USERROLE_MGT_ERROR_ASSIGNED_TASK;
                }
            }

        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }


}

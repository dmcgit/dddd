package com.epic.pb.repository.usermgt.task;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.task.TaskInputBean;
import com.epic.pb.mapper.usermgt.task.TaskDataMapper;
import com.epic.pb.mapper.usermgt.task.TaskDualMapper;
import com.epic.pb.mapper.usermgt.task.TaskMapper;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Scope("prototype")
public class TaskRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TASK T LEFT OUTER JOIN STATUS S ON S.STATUSCODE=T.STATUS WHERE ";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";
    private final String SQL_INSERT_TASK = "INSERT INTO WEB_TASK (TASKCODE,DESCRIPTION,STATUS,CREATEDTIME,LASTUPDATEDTIME,LASTUPDATEDUSER) values (?,?,?,?,?,?) ";
    private final String SQL_UPDATE_TASK = "UPDATE WEB_TASK SET DESCRIPTION=?,STATUS=?,LASTUPDATEDUSER=?,LASTUPDATEDTIME=? WHERE TASKCODE=?";
    private final String SQL_FIND_TASK = "SELECT T.TASKCODE,T.DESCRIPTION,T.STATUS,T.CREATEDTIME,T.LASTUPDATEDTIME,T.LASTUPDATEDUSER FROM WEB_TASK T WHERE T.TASKCODE = ? ";
    private final String SQL_DELETE_TASK = "DELETE FROM WEB_TASK WHERE TASKCODE=?";

    @Transactional(readOnly = true)
    public long getDataCount(TaskInputBean taskInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(taskInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (EmptyResultDataAccessException ere) {
            count = 0;
        } catch (Exception e) {
            throw e;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<TaskInputBean> getTaskSearchResults(TaskInputBean taskInputBean) throws Exception {
        List<TaskInputBean> taskList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClause(taskInputBean, dynamicClause);
            if (taskInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by T.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by T.CREATEDTIME " + taskInputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT T.TASKCODE, T.DESCRIPTION, S.DESCRIPTION AS STATUSDES,T.CREATEDTIME, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TASK T LEFT OUTER JOIN STATUS S ON S.STATUSCODE=T.STATUS "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (taskInputBean.displayLength + taskInputBean.displayStart) + "  ) WHERE R > " + taskInputBean.displayStart;

            taskList = jdbcTemplate.query(sql, new TaskDataMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return taskList;
    }

    private void setDynamicClause(TaskInputBean taskInputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (taskInputBean.getTaskCode() != null && !taskInputBean.getTaskCode().isEmpty()) {
            dynamicClause.append("AND T.TASKCODE LIKE '%").append(taskInputBean.getTaskCode()).append("%'");
        }

        if (taskInputBean.getDescription() != null && !taskInputBean.getDescription().isEmpty()) {
            dynamicClause.append("AND T.DESCRIPTION LIKE '%").append(taskInputBean.getDescription()).append("%'");
        }

        if (taskInputBean.getStatus() != null && !taskInputBean.getStatus().isEmpty()) {
            dynamicClause.append("AND T.STATUS = '").append(taskInputBean.getStatus()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(TaskInputBean taskInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(taskInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.TASK_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<TempAuthRecBean> getTaskSearchResultsDual(TaskInputBean taskInputBean) throws Exception {
        List<TempAuthRecBean> taskDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(taskInputBean, dynamicClause);
            if (taskInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + taskInputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID,D.KEY1,D.KEY2,S.DESCRIPTION KEY3,T.DESCRIPTION TASK,D.CREATEDTIME,D.LASTUPDATEDTIME,D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=D.KEY3 "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (taskInputBean.displayLength + taskInputBean.displayStart) + "  ) WHERE R > " + taskInputBean.displayStart;

            taskDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.TASK_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, new TaskDualMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }

        
        return taskDualList;
    }

    private void setDynamicClauseDual(TaskInputBean taskInputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (taskInputBean.getTaskCode() != null && !taskInputBean.getTaskCode().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(taskInputBean.getTaskCode()).append("%'");
        }

        if (taskInputBean.getDescription() != null && !taskInputBean.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY2 like '%").append(taskInputBean.getDescription()).append("%'");
        }

        if (taskInputBean.getStatus() != null && !taskInputBean.getStatus().isEmpty()) {
            dynamicClause.append("and D.KEY3 = '").append(taskInputBean.getStatus()).append("'");
        }
    }

    @Transactional
    public String insertTask(Task task) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_INSERT_TASK,
                    new Object[]{
                            task.getTaskCode(),
                            task.getDescription(),
                            task.getStatus(),
                            task.getCreateTime(),
                            task.getLastUpdatedTime(),
                            task.getLastUpdatedUser()
                    });

            if (value != 1) {
                message = "Error occurred while adding task";
            }
        } catch (DuplicateKeyException ex) {
            throw ex;
        } catch (NumberFormatException | DataAccessException ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String updateTask(Task task) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_UPDATE_TASK,
                    new Object[]{
                            task.getDescription(),
                            task.getStatus(),
                            task.getLastUpdatedUser(),
                            task.getLastUpdatedTime(),
                            task.getTaskCode()
                    });
            if (value != 1) {
                message = "Error occurred while updating task";
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional(readOnly = true)
    public Task getTask(String taskCode) throws Exception {
        Task task;
        try {
            task = jdbcTemplate.queryForObject(SQL_FIND_TASK, new Object[]{taskCode}, new TaskMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return task;
    }

    @Transactional
    public String deleteTask(String taskcode) throws Exception {
        String message = "";
        int count = 0;
        try {
            count = jdbcTemplate.update(SQL_DELETE_TASK, new Object[]{taskcode});
            if (count < 0) {
                message = "Error occurred while deleting task";
            }

        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }
}

package com.epic.pb.repository.usermgt.page;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.usermgt.page.PageInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapper.usermgt.page.PageDataMapper;
import com.epic.pb.mapper.usermgt.page.PageDualMapper;
import com.epic.pb.mapper.usermgt.page.PageMapper;
import com.epic.pb.mapping.usermgt.Page;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import com.epic.pb.util.varlist.MessageVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Repository
@Scope("prototype")
public class PageRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM WEB_PAGE P LEFT OUTER JOIN STATUS S ON S.STATUSCODE=P.STATUS WHERE ";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";
    private final String SQL_FIND_PAGE = "SELECT P.PAGECODE, P.DESCRIPTION, P.URL, P.SORTKEY, P.AFLAG, P.CFLAG, P.STATUS, P.CREATEDTIME, P.LASTUPDATEDTIME, P.LASTUPDATEDUSER FROM WEB_PAGE P WHERE P.PAGECODE = ? ";
    private final String SQL_UPDATE_PAGE = "UPDATE WEB_PAGE SET DESCRIPTION=?, SORTKEY=?, CFLAG=?, STATUS=?, LASTUPDATEDUSER=?, LASTUPDATEDTIME=? WHERE PAGECODE=?";
    private final String SQL_CHECK_SORTKEY_EXIST = "SELECT COUNT(PAGECODE) FROM WEB_PAGE WHERE SORTKEY=? AND PAGECODE!=?";
    private final String SQL_CHECK_TEMP_SORTKEY_EXIST = "SELECT COUNT(ID) FROM WEB_TMPAUTHREC WHERE KEY4=? AND STATUS= ? ";

    @Transactional(readOnly = true)
    public long getDataCount(PageInputBean inputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();

        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(inputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<PageInputBean> getPageSearchResults(PageInputBean inputBean) throws Exception {
        List<PageInputBean> pageList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClause(inputBean, dynamicClause);

            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by P.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by P.CREATEDTIME " + inputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT P.PAGECODE, P.DESCRIPTION, P.URL, P.SORTKEY, P.AFLAG, P.CFLAG, S.DESCRIPTION AS STATUSDES, P.CREATEDTIME, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_PAGE P LEFT OUTER JOIN STATUS S ON S.STATUSCODE=P.STATUS "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            pageList = jdbcTemplate.query(sql, new PageDataMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return pageList;
    }

    private void setDynamicClause(PageInputBean inputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (inputBean.getPageCode() != null && !inputBean.getPageCode().isEmpty()) {
            dynamicClause.append("and P.PAGECODE like '%").append(inputBean.getPageCode()).append("%'");
        }

        if (inputBean.getDescription() != null && !inputBean.getDescription().isEmpty()) {
            dynamicClause.append("and P.DESCRIPTION like '%").append(inputBean.getDescription()).append("%'");
        }

        if (inputBean.getStatus() != null && !inputBean.getStatus().isEmpty()) {
            dynamicClause.append("and P.STATUS = '").append(inputBean.getStatus()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(PageInputBean page) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(page, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.PAGE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getPageSearchResultsDual(PageInputBean inputBean) throws Exception {
        List<TempAuthRecBean> pageDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(inputBean, dynamicClause);
            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + inputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID, D.KEY1, D.KEY2, D.KEY3, D.KEY4, D.KEY5, D.KEY6, S.DESCRIPTION KEY7, T.DESCRIPTION TASK, D.CREATEDTIME, D.LASTUPDATEDTIME, D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN STATUS S ON S.STATUSCODE=D.KEY7 "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            pageDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.PAGE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, new PageDualMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }

        return pageDualList;
    }


    private void setDynamicClauseDual(PageInputBean pg, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (pg.getPageCode() != null && !pg.getPageCode().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(pg.getPageCode()).append("%'");
        }

        if (pg.getDescription() != null && !pg.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY2 like '%").append(pg.getDescription()).append("%'");
        }

        if (pg.getStatus() != null && !pg.getStatus().isEmpty()) {
            dynamicClause.append("and D.KEY7 = '").append(pg.getStatus()).append("'");
        }
    }

    public Page getPage(String pageCode) throws Exception {
        Page page = null;
        try {
            page = jdbcTemplate.queryForObject(SQL_FIND_PAGE, new Object[]{pageCode}, new PageMapper());
        } catch (DataAccessException ex) {
            throw ex;
        }
        return page;
    }


    public String updatePage(Page page) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_UPDATE_PAGE,
                    new Object[]{
                            page.getDescription(),
                            page.getSortKey(),
                            page.isCurrentFlag(),
                            page.getStatusCode(),
                            page.getLastUpdatedUser(),
                            page.getLastUpdatedTime(),
                            page.getPageCode()
                    });
            if (value != 1) {
                message = MessageVarList.PAGE_MGT_ERROR_UPDATE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }


    @Transactional(readOnly = true)
    public boolean checkSortKeyExist(String pageCode, int sortKey) {
        boolean check;
        long count = 0;
        try {
            count = jdbcTemplate.queryForObject(SQL_CHECK_SORTKEY_EXIST, new Object[]{sortKey, pageCode}, Long.class);
            if (count > 0) {
                check = true;
            } else {
                check = false;
            }
        } catch (EmptyResultDataAccessException ere) {
            check = false;
        } catch (Exception ex) {
            throw ex;
        }
        return check;
    }

    @Transactional(readOnly = true)
    public boolean checkTempSortKeyExist(int sortKey) {
        boolean check;
        long count = 0;
        try {
            count = jdbcTemplate.queryForObject(SQL_CHECK_TEMP_SORTKEY_EXIST, new Object[]{sortKey, StatusVarList.STATUS_AUTH_PEN}, Long.class);
            if (count > 0) {
                check = true;
            } else {
                check = false;
            }
        } catch (EmptyResultDataAccessException ere) {
            check = false;
        } catch (Exception ex) {
            throw ex;
        }
        return check;
    }


}

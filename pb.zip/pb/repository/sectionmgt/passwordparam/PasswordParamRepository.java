package com.epic.pb.repository.sectionmgt.passwordparam;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordparam.PasswordParamInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.sectionmgt.PasswordParam;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/*
        User: suren_v
        Date: 2/2/2021
        Time: 11:24 AM
 */

@Repository
@Scope("prototype")
public class PasswordParamRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM PASSWORDPARAM P WHERE ";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";
    private final String SQL_UPDATE_PASSWORD_PARAM = "UPDATE PASSWORDPARAM SET VALUE=?,USERROLETYPE=?,LASTUPDATEDUSER=?,LASTUPDATEDTIME=? WHERE PASSWORDPARAM=?";
    private final String SQL_FIND_PASSWORD_PARAM = "SELECT P.PASSWORDPARAM,P.USERROLETYPE,P.VALUE,P.CREATEDTIME,P.LASTUPDATEDTIME,P.LASTUPDATEDUSER FROM PASSWORDPARAM P WHERE P.PASSWORDPARAM = ? ";

    @Transactional(readOnly = true)
    public long getDataCount(PasswordParamInputBean passwordParamInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(passwordParamInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (EmptyResultDataAccessException ere) {
            count = 0;
        } catch (Exception e) {
            throw e;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<PasswordParamInputBean> getPasswordParamSearchResults(PasswordParamInputBean paramBean) throws Exception {
        List<PasswordParamInputBean> paramBeanList;
        try {
            String sortingStr;
            StringBuilder dynamicClause = new StringBuilder();

            this.setDynamicClause(paramBean, dynamicClause);
            if (paramBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by P.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by P.CREATEDTIME " + paramBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT P.PASSWORDPARAM, P.USERROLETYPE, P.VALUE, P.CREATEDTIME, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM PASSWORDPARAM P "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (paramBean.displayLength + paramBean.displayStart) + "  ) WHERE R > " + paramBean.displayStart;

            paramBeanList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                PasswordParamInputBean passwordParamInputBean = new PasswordParamInputBean();

                try {
                    passwordParamInputBean.setPasswordparam(rs.getString("PASSWORDPARAM"));
                } catch (Exception e) {
                    passwordParamInputBean.setPasswordparam(null);
                }

                try {
                    passwordParamInputBean.setUserroletype(rs.getString("USERROLETYPE"));
                } catch (Exception e) {
                    passwordParamInputBean.setUserroletype(null);
                }

                try {
                    passwordParamInputBean.setValue(rs.getString("VALUE"));
                } catch (Exception e) {
                    passwordParamInputBean.setValue(null);
                }

                try {
                    passwordParamInputBean.setCreatedtime(rs.getString("CREATEDTIME"));
                } catch (Exception e) {
                    passwordParamInputBean.setCreatedtime(null);
                }
                return passwordParamInputBean;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return paramBeanList;
    }

    private void setDynamicClause(PasswordParamInputBean paramBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (paramBean.getPasswordparam() != null && !paramBean.getPasswordparam().isEmpty()) {
            dynamicClause.append("AND P.PASSWORDPARAM = '").append(paramBean.getPasswordparam()).append("'");
        }

        if (paramBean.getUserroletype() != null && !paramBean.getUserroletype().isEmpty()) {
            dynamicClause.append("AND P.USERROLETYPE = '").append(paramBean.getUserroletype()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(PasswordParamInputBean passwordParamInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(passwordParamInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.PASSWORD_PARAMETER_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<TempAuthRecBean> getPasswordParamSearchResultsDual(PasswordParamInputBean passwordParamInputBean) throws Exception {
        List<TempAuthRecBean> passwordParamDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(passwordParamInputBean, dynamicClause);
            if (passwordParamInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + passwordParamInputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID,D.KEY1,D.KEY2,D.KEY3,T.DESCRIPTION TASK,D.CREATEDTIME,D.LASTUPDATEDTIME,D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (passwordParamInputBean.displayLength + passwordParamInputBean.displayStart) + "  ) WHERE R > " + passwordParamInputBean.displayStart;

            passwordParamDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.PASSWORD_PARAMETER_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, (rs, rowNum) -> {
                TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();

                try {
                    tempAuthRecBean.setId(rs.getString("ID"));
                } catch (Exception e) {
                    tempAuthRecBean.setId(null);
                }

                try {
                    tempAuthRecBean.setTask(rs.getString("TASK"));
                } catch (Exception e) {
                    tempAuthRecBean.setTask(null);
                }

                try {
                    //password param code
                    tempAuthRecBean.setKey1(rs.getString("KEY1"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey1(null);
                }

                try {
                    //user role type
                    tempAuthRecBean.setKey2(rs.getString("KEY2"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey2(null);
                }

                try {
                    //value
                    tempAuthRecBean.setKey3(rs.getString("KEY3"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey3(null);
                }

                try {
                    tempAuthRecBean.setLastUpdatedTime(rs.getString("LASTUPDATEDTIME"));
                } catch (Exception e) {
                    tempAuthRecBean.setLastUpdatedTime(null);
                }

                try {
                    tempAuthRecBean.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
                } catch (Exception e) {
                    tempAuthRecBean.setLastUpdatedUser(null);
                }

                try {
                    tempAuthRecBean.setCreatedTime(rs.getString("CREATEDTIME"));
                } catch (Exception e) {
                    tempAuthRecBean.setCreatedTime(null);
                }

                return tempAuthRecBean;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordParamDualList;
    }

    private void setDynamicClauseDual(PasswordParamInputBean passwordParamInputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (passwordParamInputBean.getPasswordparam() != null && !passwordParamInputBean.getPasswordparam().isEmpty()) {
            dynamicClause.append("and D.KEY1 = '").append(passwordParamInputBean.getPasswordparam()).append("'");
        }

        if (passwordParamInputBean.getUserroletype() != null && !passwordParamInputBean.getUserroletype().isEmpty()) {
            dynamicClause.append("and D.KEY2 = '").append(passwordParamInputBean.getUserroletype()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public PasswordParam getPasswordParam(String passwordParamCode) throws Exception {
        PasswordParam pwdParam;
        try {
            pwdParam = jdbcTemplate.queryForObject(SQL_FIND_PASSWORD_PARAM, new Object[]{passwordParamCode}, (rs, rowNum) -> {
                PasswordParam passwordParam = new PasswordParam();

                try {
                    passwordParam.setPasswordparam(rs.getString("PASSWORDPARAM"));
                } catch (Exception e) {
                    passwordParam.setPasswordparam(null);
                }

                try {
                    passwordParam.setUserroletype(rs.getString("USERROLETYPE"));
                } catch (Exception e) {
                    passwordParam.setUserroletype(null);
                }

                try {
                    passwordParam.setValue(rs.getString("VALUE"));
                } catch (Exception e) {
                    passwordParam.setValue(null);
                }

                return passwordParam;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return pwdParam;
    }

    @Transactional
    public String updatePasswordParam(PasswordParam passwordParam) throws Exception {
        String message = "";
        int value = 0;
        try {
            value = jdbcTemplate.update(SQL_UPDATE_PASSWORD_PARAM,
                    new Object[]{
                            passwordParam.getValue(),
                            passwordParam.getUserroletype(),
                            passwordParam.getLastUpdatedUser(),
                            passwordParam.getLastUpdatedTime(),
                            passwordParam.getPasswordparam()
                    });
            if (value != 1) {
                message = "Error occurred while updating password param";
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }
}

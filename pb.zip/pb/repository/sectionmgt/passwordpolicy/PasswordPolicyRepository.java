package com.epic.pb.repository.sectionmgt.passwordpolicy;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordpolicy.PasswordPolicyInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.passwordhistory.PasswordHistory;
import com.epic.pb.mapping.passwordpolicy.PasswordPolicy;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.CommonVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
        User: suren_v
        Date: 2/1/2021
        Time: 10:54 AM
 */

@Repository
@Scope("prototype")
public class PasswordPolicyRepository {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    CommonVarList commonVarList;

    @Autowired
    Common common;

    @Autowired
    SessionBean sessionBean;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM WEB_PASSWORDPOLICY P WHERE ";
    private final String SQL_GET_LIST_DUAL_DATA_COUNT = "SELECT COUNT(*) FROM WEB_TMPAUTHREC D WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND ";
    private final String SQL_FIND_WEB_PASSWORDPOLICY = "SELECT PASSWORDPOLICYID , MINIMUMLENGTH , MAXIMUMLENGTH , MINIMUMSPECIALCHARACTERS , MINIMUMUPPERCASECHARACTERS , MINIMUMNUMERICALCHARACTERS , MINIMUMLOWERCASECHARACTERS , NOOFINVALIDLOGINATTEMPT , REPEATCHARACTERSALLOW , INITIALPASSWORDEXPIRYSTATUS , PASSWORDEXPIRYPERIOD , NOOFHISTORYPASSWORD , MINIMUMPASSWORDCHANGEPERIOD , IDLEACCOUNTEXPIRYPERIOD , DESCRIPTION , LASTUPDATEDUSER , LASTUPDATEDTIME , CREATETIME FROM WEB_PASSWORDPOLICY WHERE PASSWORDPOLICYID=?";
    private final String SQL_UPDATE_PASSWORDPOLICY = "UPDATE WEB_PASSWORDPOLICY SET MINIMUMLENGTH=?,MAXIMUMLENGTH=?,MINIMUMSPECIALCHARACTERS=?,MINIMUMUPPERCASECHARACTERS=?,MINIMUMNUMERICALCHARACTERS=?,MINIMUMLOWERCASECHARACTERS=?,NOOFINVALIDLOGINATTEMPT=?,REPEATCHARACTERSALLOW=?,INITIALPASSWORDEXPIRYSTATUS=?,PASSWORDEXPIRYPERIOD=?,NOOFHISTORYPASSWORD=?,MINIMUMPASSWORDCHANGEPERIOD=?,IDLEACCOUNTEXPIRYPERIOD=?,DESCRIPTION=?,LASTUPDATEDUSER=?,LASTUPDATEDTIME=? WHERE PASSWORDPOLICYID=?";
    private final String SQL_GET_WEB_PASSWORDPOLICY = "select passwordpolicyid , minimumlength , maximumlength , minimumspecialcharacters , minimumuppercasecharacters , minimumnumericalcharacters , minimumlowercasecharacters , noofinvalidloginattempt , repeatcharactersallow , initialpasswordexpirystatus , passwordexpiryperiod , noofhistorypassword , minimumpasswordchangeperiod , idleaccountexpiryperiod , description , lastupdateduser , lastupdatedtime , createtime from web_passwordpolicy where passwordpolicyid = ?";
    private final String SQL_GET_WEB_PASSWORDHISTORYLIST = "select id,username,password,lastupdateduser,lastupdatedtime,createdtime from web_passwordhistory where username = ? order by id desc fetch first ? rows only";

    @Transactional(readOnly = true)
    public long getDataCount(PasswordPolicyInputBean passwordPolicy) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();

        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(passwordPolicy, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<PasswordPolicyInputBean> getPasswordPolicySearchResults(PasswordPolicyInputBean inputBean) throws Exception {
        List<PasswordPolicyInputBean> passwordPolicyList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClause(inputBean, dynamicClause);

            if (inputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by P.CREATETIME DESC ";
            } else {
                sortingStr = " order by P.CREATETIME " + inputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT P.PASSWORDPOLICYID, "
                    + "P.MINIMUMLENGTH, P.MAXIMUMLENGTH, P.MINIMUMSPECIALCHARACTERS, P.MINIMUMUPPERCASECHARACTERS, "
                    + "P.MINIMUMNUMERICALCHARACTERS, P.MINIMUMLOWERCASECHARACTERS, P.LASTUPDATEDUSER, P.LASTUPDATEDTIME, "
                    + "P.CREATETIME, P.NOOFINVALIDLOGINATTEMPT, P.REPEATCHARACTERSALLOW, P.INITIALPASSWORDEXPIRYSTATUS, "
                    + "P.PASSWORDEXPIRYPERIOD, P.NOOFHISTORYPASSWORD, P.MINIMUMPASSWORDCHANGEPERIOD, P.IDLEACCOUNTEXPIRYPERIOD, "
                    + "P.DESCRIPTION, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_PASSWORDPOLICY P "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (inputBean.displayLength + inputBean.displayStart) + "  ) WHERE R > " + inputBean.displayStart;

            passwordPolicyList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                PasswordPolicyInputBean passwordPolicyInputBean = new PasswordPolicyInputBean();

                try {
                    passwordPolicyInputBean.setPasswordPolicyId(rs.getString("PASSWORDPOLICYID"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setPasswordPolicyId(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumLength(rs.getString("MINIMUMLENGTH"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumLength(null);
                }

                try {
                    passwordPolicyInputBean.setMaximumLength(rs.getString("MAXIMUMLENGTH"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMaximumLength(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumSpecialCharacters(rs.getString("MINIMUMSPECIALCHARACTERS"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumSpecialCharacters(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumUpperCaseCharacters(rs.getString("MINIMUMUPPERCASECHARACTERS"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumUpperCaseCharacters(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumNumericalCharacters(rs.getString("MINIMUMNUMERICALCHARACTERS"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumNumericalCharacters(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumLowerCaseCharacters(rs.getString("MINIMUMLOWERCASECHARACTERS"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumLowerCaseCharacters(null);
                }

                try {
                    passwordPolicyInputBean.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setLastUpdatedUser(null);
                }

                try {
                    passwordPolicyInputBean.setNoOfInvalidLoginAttempt(rs.getString("NOOFINVALIDLOGINATTEMPT"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setNoOfInvalidLoginAttempt(null);
                }

                try {
                    passwordPolicyInputBean.setRepeatCharactersAllow(rs.getString("REPEATCHARACTERSALLOW"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setRepeatCharactersAllow(null);
                }

                try {
                    passwordPolicyInputBean.setInitialPasswordExpiryStatus(rs.getString("INITIALPASSWORDEXPIRYSTATUS"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setInitialPasswordExpiryStatus(null);
                }

                try {
                    passwordPolicyInputBean.setPasswordExpiryPeriod(rs.getString("PASSWORDEXPIRYPERIOD"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setPasswordExpiryPeriod(null);
                }

                try {
                    passwordPolicyInputBean.setNoOfHistoryPassword(rs.getString("NOOFHISTORYPASSWORD"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setNoOfHistoryPassword(null);
                }

                try {
                    passwordPolicyInputBean.setMinimumPasswordChangePeriod(rs.getString("MINIMUMPASSWORDCHANGEPERIOD"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setMinimumPasswordChangePeriod(null);
                }

                try {
                    passwordPolicyInputBean.setIdleAccountExpiryPeriod(rs.getString("IDLEACCOUNTEXPIRYPERIOD"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setIdleAccountExpiryPeriod(null);
                }

                try {
                    passwordPolicyInputBean.setDescription(rs.getString("DESCRIPTION"));
                } catch (Exception e) {
                    passwordPolicyInputBean.setDescription(null);
                }

                return passwordPolicyInputBean;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordPolicyList;
    }

    private void setDynamicClause(PasswordPolicyInputBean sc, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (sc.getDescription() != null && !sc.getDescription().isEmpty()) {
            dynamicClause.append("and P.DESCRIPTION like '%").append(sc.getDescription()).append("%'");
        }

        if (sc.getPasswordPolicyId() != null && !sc.getPasswordPolicyId().isEmpty()) {
            dynamicClause.append("and P.PASSWORDPOLICYID = '").append(sc.getPasswordPolicyId()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public long getDataCountDual(PasswordPolicyInputBean passwordPolicyInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DUAL_DATA_COUNT);
            this.setDynamicClauseDual(passwordPolicyInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), new Object[]{PageVarList.PASSWORDPOLICY_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, Long.class);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<TempAuthRecBean> getPasswordPolicySearchResultsDual(PasswordPolicyInputBean passwordPolicyInputBean) throws Exception {
        List<TempAuthRecBean> passwordPolicyDualList;
        StringBuilder dynamicClause = new StringBuilder();
        String sortingStr;
        try {
            this.setDynamicClauseDual(passwordPolicyInputBean, dynamicClause);
            if (passwordPolicyInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by D.CREATEDTIME DESC ";
            } else {
                sortingStr = " order by D.CREATEDTIME " + passwordPolicyInputBean.sortDirections.get(0);
            }
            String sql
                    = "SELECT * FROM ( SELECT * FROM ( SELECT "
                    + "D.ID,D.KEY1,D.KEY2,D.KEY3,D.KEY4,D.KEY5,D.KEY6,D.KEY7,D.KEY8,D.KEY9,D.KEY10,D.KEY11,D.KEY12,D.KEY13,D.KEY14,D.KEY15,T.DESCRIPTION TASK,D.CREATEDTIME,D.LASTUPDATEDTIME,D.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_TMPAUTHREC D "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE = D.TASK "
                    + "WHERE D.PAGE=? AND D.STATUS=? AND D.LASTUPDATEDUSER <> ? AND " + dynamicClause.toString() + ") WHERE R<= " + (passwordPolicyInputBean.displayLength + passwordPolicyInputBean.displayStart) + "  ) WHERE R > " + passwordPolicyInputBean.displayStart;

            passwordPolicyDualList = jdbcTemplate.query(sql, new Object[]{PageVarList.PASSWORDPOLICY_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN, sessionBean.getUsername()}, (rs, rowNum) -> {
                TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();

                try {
                    tempAuthRecBean.setId(rs.getString("ID"));
                } catch (Exception e) {
                    tempAuthRecBean.setId(null);
                }

                try {
                    tempAuthRecBean.setTask(rs.getString("TASK"));
                } catch (Exception e) {
                    tempAuthRecBean.setTask(null);
                }

                try {
                    //password policy id
                    tempAuthRecBean.setKey1(rs.getString("KEY1"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey1(null);
                }

                try {
                    tempAuthRecBean.setKey2(rs.getString("KEY2"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey2(null);
                }

                try {
                    tempAuthRecBean.setKey3(rs.getString("KEY3"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey3(null);
                }

                try {
                    tempAuthRecBean.setKey4(rs.getString("KEY4"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey4(null);
                }

                try {
                    tempAuthRecBean.setKey5(rs.getString("KEY5"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey5(null);
                }

                try {
                    tempAuthRecBean.setKey6(rs.getString("KEY6"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey6(null);
                }

                try {
                    tempAuthRecBean.setKey7(rs.getString("KEY7"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey7(null);
                }

                try {
                    tempAuthRecBean.setKey8(rs.getString("KEY8"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey8(null);
                }

                try {
                    tempAuthRecBean.setKey9(rs.getString("KEY9"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey9(null);
                }

                try {
                    tempAuthRecBean.setKey10(rs.getString("KEY10"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey10(null);
                }

                try {
                    tempAuthRecBean.setKey11(rs.getString("KEY11"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey11(null);
                }

                try {
                    tempAuthRecBean.setKey12(rs.getString("KEY12"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey12(null);
                }

                try {
                    tempAuthRecBean.setKey13(rs.getString("KEY13"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey13(null);
                }

                try {
                    tempAuthRecBean.setKey14(rs.getString("KEY14"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey14(null);
                }

                try {
                    tempAuthRecBean.setKey15(rs.getString("KEY15"));
                } catch (Exception e) {
                    tempAuthRecBean.setKey15(null);
                }

                try {
                    tempAuthRecBean.setLastUpdatedTime(rs.getString("LASTUPDATEDTIME"));
                } catch (Exception e) {
                    tempAuthRecBean.setLastUpdatedTime(null);
                }

                try {
                    tempAuthRecBean.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
                } catch (Exception e) {
                    tempAuthRecBean.setLastUpdatedUser(null);
                }

                try {
                    tempAuthRecBean.setCreatedTime(rs.getString("CREATEDTIME"));
                } catch (Exception e) {
                    tempAuthRecBean.setCreatedTime(null);
                }

                return tempAuthRecBean;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordPolicyDualList;
    }

    private void setDynamicClauseDual(PasswordPolicyInputBean passwordPolicyInputBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (passwordPolicyInputBean.getDescription() != null && !passwordPolicyInputBean.getDescription().isEmpty()) {
            dynamicClause.append("and D.KEY1 like '%").append(passwordPolicyInputBean.getDescription()).append("%'");
        }

        if (passwordPolicyInputBean.getPasswordPolicyId() != null && !passwordPolicyInputBean.getPasswordPolicyId().isEmpty()) {
            dynamicClause.append("and D.KEY2 = '").append(passwordPolicyInputBean.getPasswordPolicyId()).append("'");
        }
    }

    @Transactional(readOnly = true)
    public PasswordPolicy getWebPasswordPolicy(int passwordPolicyCode) {
        PasswordPolicy passwordPolicy = null;
        try {
            Map<String, Object> listmap = jdbcTemplate.queryForMap(SQL_FIND_WEB_PASSWORDPOLICY, new Object[]{passwordPolicyCode});
            if (listmap.size() != 0) {
                passwordPolicy = new PasswordPolicy();
                passwordPolicy.setPasswordPolicyId(Long.parseLong(listmap.get("PASSWORDPOLICYID") + ""));
                passwordPolicy.setMinimumLength(Long.parseLong(listmap.get("MINIMUMLENGTH") + ""));
                passwordPolicy.setMaximumLength(Long.parseLong(listmap.get("MAXIMUMLENGTH") + ""));
                passwordPolicy.setMinimumSpecialCharacters(Long.parseLong(listmap.get("MINIMUMSPECIALCHARACTERS") + ""));
                passwordPolicy.setMinimumUpperCaseCharacters(Long.parseLong(listmap.get("MINIMUMUPPERCASECHARACTERS") + ""));
                passwordPolicy.setMinimumNumericalCharacters(Long.parseLong(listmap.get("MINIMUMNUMERICALCHARACTERS") + ""));
                passwordPolicy.setMinimumLowerCaseCharacters(Long.parseLong(listmap.get("MINIMUMLOWERCASECHARACTERS") + ""));
                passwordPolicy.setNoOfInvalidLoginAttempt(Long.parseLong(listmap.get("NOOFINVALIDLOGINATTEMPT") + ""));
                passwordPolicy.setRepeatCharactersAllow(Long.parseLong(listmap.get("REPEATCHARACTERSALLOW") + ""));
                passwordPolicy.setInitialPasswordExpiryStatus(Long.parseLong(listmap.get("INITIALPASSWORDEXPIRYSTATUS") + ""));
                passwordPolicy.setPasswordExpiryPeriod(Long.parseLong(listmap.get("PASSWORDEXPIRYPERIOD") + ""));
                passwordPolicy.setNoOfHistoryPassword(Long.parseLong(listmap.get("NOOFHISTORYPASSWORD") + ""));
                passwordPolicy.setMinimumPasswordChangePeriod(Long.parseLong(listmap.get("MINIMUMPASSWORDCHANGEPERIOD") + ""));
                passwordPolicy.setIdleAccountExpiryPeriod(Long.parseLong(listmap.get("IDLEACCOUNTEXPIRYPERIOD") + ""));
                passwordPolicy.setDescription(listmap.get("DESCRIPTION") + "");
                passwordPolicy.setLastUpdatedUser(listmap.get("LASTUPDATEDUSER") + "");
                passwordPolicy.setCreatedTime((Date) listmap.get("CREATETIME"));
                passwordPolicy.setLastUpdatedTime((Date) listmap.get("LASTUPDATEDTIME"));
            }
        } catch (EmptyResultDataAccessException ex) {
            return passwordPolicy;
        } catch (Exception e) {
            throw e;
        }
        return passwordPolicy;
    }

    @Transactional(readOnly = true)
    public List<PasswordHistory> getPasswordHistoryList(String userName, int noOfHistoryPassword) {
        List<PasswordHistory> passwordHistoryList;
        try {
            List<Map<String, Object>> list = jdbcTemplate.queryForList(SQL_GET_WEB_PASSWORDHISTORYLIST, new Object[]{userName, noOfHistoryPassword});
            passwordHistoryList = list.stream().map((record) -> {
                PasswordHistory passwordHistory = new PasswordHistory();
                passwordHistory.setId(new BigInteger(record.get("id").toString()).longValue());
                passwordHistory.setUserName(record.get("username").toString());
                passwordHistory.setPassword(record.get("password").toString());
                passwordHistory.setLastUpdatedUser(record.get("lastupdateduser").toString());
                passwordHistory.setCreatedTime((Date) record.get("createdtime"));
                passwordHistory.setLastUpdatedTime((Date) record.get("lastupdatedtime"));
                return passwordHistory;
            }).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException ex) {
            passwordHistoryList = null;
        } catch (Exception e) {
            throw e;
        }
        return passwordHistoryList;
    }

    @Transactional(readOnly = true)
    public PasswordPolicy getPasswordPolicy(String passwordPolicy) throws Exception {
        PasswordPolicy password;
        try {
            password = jdbcTemplate.queryForObject(SQL_FIND_WEB_PASSWORDPOLICY, new Object[]{passwordPolicy}, (rs, rowNum) -> {
                PasswordPolicy policy = new PasswordPolicy();

                try {
                    policy.setPasswordPolicyId(Long.parseLong(rs.getString("PASSWORDPOLICYID")));
                } catch (Exception e) {
                    policy.setPasswordPolicyId(0);
                }

                try {
                    policy.setMinimumLength(Long.parseLong(rs.getString("MINIMUMLENGTH")));
                } catch (Exception e) {
                    policy.setMinimumLength(0);
                }

                try {
                    policy.setMaximumLength(Long.parseLong(rs.getString("MAXIMUMLENGTH")));
                } catch (Exception e) {
                    policy.setMaximumLength(0);
                }

                try {
                    policy.setMinimumSpecialCharacters(Long.parseLong(rs.getString("MINIMUMSPECIALCHARACTERS")));
                } catch (Exception e) {
                    policy.setMinimumSpecialCharacters(0);
                }

                try {
                    policy.setMinimumUpperCaseCharacters(Long.parseLong(rs.getString("MINIMUMUPPERCASECHARACTERS")));
                } catch (Exception e) {
                    policy.setMinimumUpperCaseCharacters(0);
                }

                try {
                    policy.setMinimumNumericalCharacters(Long.parseLong(rs.getString("MINIMUMNUMERICALCHARACTERS")));
                } catch (Exception e) {
                    policy.setMinimumNumericalCharacters(0);
                }

                try {
                    policy.setMinimumLowerCaseCharacters(Long.parseLong(rs.getString("MINIMUMLOWERCASECHARACTERS")));
                } catch (Exception e) {
                    policy.setMinimumLowerCaseCharacters(0);
                }

                try {
                    policy.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
                } catch (Exception e) {
                    policy.setLastUpdatedUser(null);
                }

                try {
                    policy.setNoOfInvalidLoginAttempt(Long.parseLong(rs.getString("NOOFINVALIDLOGINATTEMPT")));
                } catch (Exception e) {
                    policy.setNoOfInvalidLoginAttempt(0);
                }

                try {
                    policy.setRepeatCharactersAllow(Long.parseLong(rs.getString("REPEATCHARACTERSALLOW")));
                } catch (Exception e) {
                    policy.setRepeatCharactersAllow(0);
                }

                try {
                    policy.setInitialPasswordExpiryStatus(Long.parseLong(rs.getString("INITIALPASSWORDEXPIRYSTATUS")));
                } catch (Exception e) {
                    policy.setInitialPasswordExpiryStatus(0);
                }

                try {
                    policy.setPasswordExpiryPeriod(Long.parseLong(rs.getString("PASSWORDEXPIRYPERIOD")));
                } catch (Exception e) {
                    policy.setPasswordExpiryPeriod(0);
                }

                try {
                    policy.setNoOfHistoryPassword(Long.parseLong(rs.getString("NOOFHISTORYPASSWORD")));
                } catch (Exception e) {
                    policy.setNoOfHistoryPassword(0);
                }

                try {
                    policy.setMinimumPasswordChangePeriod(Long.parseLong(rs.getString("MINIMUMPASSWORDCHANGEPERIOD")));
                } catch (Exception e) {
                    policy.setMinimumPasswordChangePeriod(0);
                }

                try {
                    policy.setIdleAccountExpiryPeriod(Long.parseLong(rs.getString("IDLEACCOUNTEXPIRYPERIOD")));
                } catch (Exception e) {
                    policy.setIdleAccountExpiryPeriod(0);
                }

                try {
                    policy.setDescription(rs.getString("DESCRIPTION"));
                } catch (Exception e) {
                    policy.setDescription(null);
                }

                return policy;
            });
        } catch (DataAccessException ex) {
            throw ex;
        }
        return password;
    }

    @Transactional
    public String updatePasswordPolicy(PasswordPolicy passwordPolicy) throws Exception {
        String message = "";
        int value = 0;
        try {

            value = jdbcTemplate.update(SQL_UPDATE_PASSWORDPOLICY,
                    new Object[]{
                            passwordPolicy.getMinimumLength(),
                            passwordPolicy.getMaximumLength(),
                            passwordPolicy.getMinimumSpecialCharacters(),
                            passwordPolicy.getMinimumUpperCaseCharacters(),
                            passwordPolicy.getMinimumNumericalCharacters(),
                            passwordPolicy.getMinimumLowerCaseCharacters(),
                            passwordPolicy.getNoOfInvalidLoginAttempt(),
                            passwordPolicy.getRepeatCharactersAllow(),
                            passwordPolicy.getInitialPasswordExpiryStatus(),
                            passwordPolicy.getPasswordExpiryPeriod(),
                            passwordPolicy.getNoOfHistoryPassword(),
                            passwordPolicy.getMinimumPasswordChangePeriod(),
                            passwordPolicy.getIdleAccountExpiryPeriod(),
                            passwordPolicy.getDescription(),
                            passwordPolicy.getLastUpdatedUser(),
                            passwordPolicy.getLastUpdatedTime(),
                            passwordPolicy.getPasswordPolicyId()
                    });
            if (value != 1) {
                message = "Error occurred while updating password policy";
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }
}

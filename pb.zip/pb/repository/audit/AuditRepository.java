package com.epic.pb.repository.audit;

import com.epic.pb.bean.audit.AuditBean;
import com.epic.pb.bean.audit.AuditValueBean;
import com.epic.pb.bean.session.SessionBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Repository
@Scope("prototype")
public class AuditRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    private final String SQL_GET_LIST_DATA_COUNT = "SELECT COUNT(*) FROM WEB_SYSTEMAUDIT A LEFT OUTER JOIN WEB_SECTION S ON S.SECTIONCODE=A.SECTION LEFT OUTER JOIN WEB_PAGE P ON P.PAGECODE=A.PAGE LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE=A.TASK WHERE ";
    private final String SQL_FIND_AUDIT = "SELECT A.SYSTEMAUDITID, A.DESCRIPTION, S.DESCRIPTION AS SECTIONDES,P.DESCRIPTION AS PAGEDES, T.DESCRIPTION AS TASKDES,R.DESCRIPTION ROLEDES,A.CREATETIME,A.LASTUPDATEDUSER,A.LASTUPDATEDTIME,A.REMARKS,A.IP,A.FIELD,A.OLDVALUE,A.NEWVALUE FROM WEB_SYSTEMAUDIT A LEFT OUTER JOIN WEB_SECTION S ON S.SECTIONCODE=A.SECTION LEFT OUTER JOIN WEB_PAGE P ON P.PAGECODE=A.PAGE LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE=A.TASK LEFT OUTER JOIN USERROLE R ON R.USERROLECODE=A.USERROLE WHERE A.SYSTEMAUDITID=?";

    @Transactional(readOnly = true)
    public long getDataCount(AuditBean auditInputBean) throws Exception {
        long count = 0;
        StringBuilder dynamicClause = new StringBuilder();
        try {
            dynamicClause.append(SQL_GET_LIST_DATA_COUNT);
            this.setDynamicClause(auditInputBean, dynamicClause);
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (EmptyResultDataAccessException ere) {
            count = 0;
        } catch (Exception ex) {
            throw ex;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<AuditBean> getAuditSearchResults(AuditBean auditInputBean) throws Exception {
        List<AuditBean> taskList;
        try {
            String sortingStr;
            StringBuilder dynamicClause = new StringBuilder();
            //create the dynamic clause
            this.setDynamicClause(auditInputBean, dynamicClause);

            if (auditInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by A.CREATETIME DESC ";
            } else {
                sortingStr = " order by A.CREATETIME " + auditInputBean.sortDirections.get(0);
            }

            String sql
                    = "SELECT * FROM ( SELECT * FROM (SELECT A.SYSTEMAUDITID, A.DESCRIPTION, S.DESCRIPTION AS SECTIONDES, P.DESCRIPTION AS PAGEDES, T.DESCRIPTION AS TASKDES,A.CREATETIME,A.LASTUPDATEDUSER, "
                    + "row_number() over ( " + sortingStr + ") as R "
                    + "FROM WEB_SYSTEMAUDIT A "
                    + "LEFT OUTER JOIN WEB_SECTION S ON S.SECTIONCODE=A.SECTION "
                    + "LEFT OUTER JOIN WEB_PAGE P ON P.PAGECODE=A.PAGE "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE=A.TASK "
                    + "WHERE " + dynamicClause.toString() + ") WHERE R<= " + (auditInputBean.displayLength + auditInputBean.displayStart) + "  ) WHERE R > " + auditInputBean.displayStart;

            taskList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                AuditBean auditBean = new AuditBean();

                try {
                    auditBean.setId(rs.getString("SYSTEMAUDITID"));
                } catch (Exception e) {
                    auditBean.setId("--");
                }

                try {
                    if (rs.getString("DESCRIPTION") != null && !rs.getString("DESCRIPTION").isEmpty()) {
                        auditBean.setDescription(rs.getString("DESCRIPTION"));
                    } else {
                        auditBean.setDescription("--");
                    }
                } catch (Exception e) {
                    auditBean.setDescription("--");
                }

                try {
                    if (rs.getString("SECTIONDES") != null && !rs.getString("SECTIONDES").isEmpty()) {
                        auditBean.setSection(rs.getString("SECTIONDES"));
                    } else {
                        auditBean.setSection("--");
                    }
                } catch (Exception e) {
                    auditBean.setSection("--");
                }

                try {
                    if (rs.getString("PAGEDES") != null && !rs.getString("PAGEDES").isEmpty()) {
                        auditBean.setPage(rs.getString("PAGEDES"));
                    } else {
                        auditBean.setPage("--");
                    }
                } catch (Exception e) {
                    auditBean.setPage(null);
                }

                try {
                    if (rs.getString("TASKDES") != null && !rs.getString("TASKDES").isEmpty()) {
                        auditBean.setTask(rs.getString("TASKDES"));
                    } else {
                        auditBean.setTask("--");
                    }
                } catch (Exception e) {
                    auditBean.setTask("--");
                }

                try {
                    if (rs.getString("IP") != null && !rs.getString("IP").isEmpty()) {
                        auditBean.setIp(rs.getString("IP"));
                    } else {
                        auditBean.setIp("--");
                    }
                } catch (Exception e) {
                    auditBean.setIp("--");
                }

                try {
                    if (rs.getString("USERROLE") != null && !rs.getString("USERROLE").isEmpty()) {
                        auditBean.setUserRole(rs.getString("USERROLE"));
                    } else {
                        auditBean.setUserRole("--");
                    }
                } catch (Exception e) {
                    auditBean.setUserRole("--");
                }

                try {
                    if (rs.getString("LASTUPDATEDUSER") != null && !rs.getString("LASTUPDATEDUSER").isEmpty()) {
                        auditBean.setUserName(rs.getString("LASTUPDATEDUSER"));
                    } else {
                        auditBean.setUserName("--");
                    }
                } catch (Exception e) {
                    auditBean.setUserName("--");
                }

                try {
                    if (rs.getString("CREATETIME") != null && !rs.getString("CREATETIME").isEmpty()) {
                        auditBean.setCreatedTime(rs.getString("CREATETIME").substring(0, 19));
                    } else {
                        auditBean.setCreatedTime("--");
                    }
                } catch (Exception e) {
                    auditBean.setCreatedTime("--");
                }

                return auditBean;
            });
        } catch (EmptyResultDataAccessException ere) {
            taskList = null;
        } catch (Exception ex) {
            throw ex;
        }
        return taskList;
    }


    private void setDynamicClause(AuditBean auditBean, StringBuilder dynamicClause) {
        dynamicClause.append(" 1=1 ");

        if (auditBean.getUserName() != null && !auditBean.getUserName().isEmpty()) {
            dynamicClause.append("and A.LASTUPDATEDUSER like '%").append(auditBean.getUserName()).append("%'");
        }

        if (auditBean.getSection() != null && !auditBean.getSection().isEmpty()) {
            dynamicClause.append("and A.SECTION = '").append(auditBean.getSection()).append("'");
        }

        if (auditBean.getPage() != null && !auditBean.getPage().isEmpty()) {
            dynamicClause.append("and A.PAGE = '").append(auditBean.getPage()).append("'");
        }

        if (auditBean.getTask() != null && !auditBean.getTask().isEmpty()) {
            dynamicClause.append("and A.TASK = '").append(auditBean.getTask()).append("'");
        }

        if (auditBean.getDescription() != null && !auditBean.getDescription().isEmpty()) {
            dynamicClause.append("and A.DESCRIPTION like '%").append(auditBean.getDescription()).append("%'");
        }

        try {

            DateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat formatter = new SimpleDateFormat("dd MMM yyyy");

            if (auditBean.getFromDate() != null && !auditBean.getFromDate().isEmpty()) {

                String inputFromDate = auditBean.getFromDate();
                Date dateFromDate = parser.parse(inputFromDate);
                String outputFromDate = formatter.format(dateFromDate);
                dynamicClause.append(" and A.CREATETIME >='").append(outputFromDate).append("'");
            }

            if (auditBean.getToDate() != null && !auditBean.getToDate().isEmpty()) {

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Calendar c = Calendar.getInstance();
                c.setTime(sdf.parse(auditBean.getToDate()));
                c.add(Calendar.DATE, 1);  // number of days to add
                String inputtoDate = sdf.format(c.getTime());
                Date dateToDate = parser.parse(inputtoDate);
                String outputToDate = formatter.format(dateToDate);
                dynamicClause.append(" and A.CREATETIME <'").append(outputToDate).append("'");
            }
        } catch (Exception ex) {
        }
    }

    public AuditBean getAudit(String id) {
        AuditBean audittrace = null;
        try {
            audittrace = jdbcTemplate.queryForObject(SQL_FIND_AUDIT, new Object[]{id}, ((rs, rowNum) -> {
                AuditBean auditBean = new AuditBean();

                try {
                    auditBean.setId(rs.getString("SYSTEMAUDITID"));
                } catch (Exception e) {
                    auditBean.setId(null);
                }

                try {
                    if (rs.getString("DESCRIPTION") != null && !rs.getString("DESCRIPTION").isEmpty()) {
                        auditBean.setDescription(rs.getString("DESCRIPTION"));
                    } else {
                        auditBean.setDescription("--");
                    }
                } catch (Exception e) {
                    auditBean.setDescription("--");
                }

                try {
                    if (rs.getString("SECTIONDES") != null && !rs.getString("SECTIONDES").isEmpty()) {
                        auditBean.setSection(rs.getString("SECTIONDES"));
                    } else {
                        auditBean.setSection("--");
                    }
                } catch (Exception e) {
                    auditBean.setSection("--");
                }

                try {
                    if (rs.getString("PAGEDES") != null && !rs.getString("PAGEDES").isEmpty()) {
                        auditBean.setPage(rs.getString("PAGEDES"));
                    } else {
                        auditBean.setPage("--");
                    }
                } catch (Exception e) {
                    auditBean.setPage(null);
                }

                try {
                    if (rs.getString("TASKDES") != null && !rs.getString("TASKDES").isEmpty()) {
                        auditBean.setTask(rs.getString("TASKDES"));
                    } else {
                        auditBean.setTask("--");
                    }
                } catch (Exception e) {
                    auditBean.setTask("--");
                }

                try {
                    if (rs.getString("ROLEDES") != null && !rs.getString("ROLEDES").isEmpty()) {
                        auditBean.setUserRole(rs.getString("ROLEDES"));
                    } else {
                        auditBean.setUserRole("--");
                    }
                } catch (Exception e) {
                    auditBean.setUserRole("--");
                }


                try {
                    if (rs.getString("REMARKS") != null && !rs.getString("REMARKS").isEmpty()) {
                        auditBean.setRemarks(rs.getString("REMARKS"));
                    } else {
                        auditBean.setRemarks("--");
                    }
                } catch (Exception e) {
                    auditBean.setRemarks("--");
                }

                try {
                    if (rs.getString("IP") != null && !rs.getString("IP").isEmpty()) {
                        auditBean.setIp(rs.getString("IP"));
                    } else {
                        auditBean.setIp("--");
                    }
                } catch (Exception e) {
                    auditBean.setIp("--");
                }


                try {
                    if (rs.getString("LASTUPDATEDUSER") != null && !rs.getString("LASTUPDATEDUSER").isEmpty()) {
                        auditBean.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
                    } else {
                        auditBean.setLastUpdatedUser("--");
                    }
                } catch (Exception e) {
                    auditBean.setLastUpdatedUser("--");
                }

                try {
                    if (rs.getString("LASTUPDATEDTIME") != null && !rs.getString("LASTUPDATEDTIME").isEmpty()) {
                        auditBean.setLastUpdatedTime(rs.getString("LASTUPDATEDTIME").substring(0, 19));
                    } else {
                        auditBean.setLastUpdatedTime("--");
                    }
                } catch (Exception e) {
                    auditBean.setLastUpdatedTime("--");
                }

                try {
                    if (rs.getString("CREATETIME") != null && !rs.getString("CREATETIME").isEmpty()) {
                        auditBean.setCreatedTime(rs.getString("CREATETIME").substring(0, 19));
                    } else {
                        auditBean.setCreatedTime("--");
                    }
                } catch (Exception e) {
                    auditBean.setCreatedTime("--");
                }

                //set old value, new value with field name
                try {
                    if (rs.getString("FIELD") != null && !rs.getString("FIELD").isEmpty()) {
                        List<AuditValueBean> valueBeanList = new ArrayList<>();

                        String fieldArray[] = rs.getString("FIELD").split("\\|");
                        String oldArray[] = null;
                        String newArray[] = null;

                        if (rs.getString("OLDVALUE") != null && !rs.getString("OLDVALUE").isEmpty()) {
                            oldArray = rs.getString("OLDVALUE").split("\\|");
                        } else {
                            oldArray = null;
                        }

                        if (rs.getString("NEWVALUE") != null && !rs.getString("NEWVALUE").isEmpty()) {
                            newArray = rs.getString("NEWVALUE").split("\\|");
                        } else {
                            newArray = null;
                        }

                        for (int i = 0; i < fieldArray.length; i++) {
                            AuditValueBean valueBean = new AuditValueBean();
                            valueBean.setField(fieldArray[i]);

                            if (oldArray != null && oldArray[i] != null && !oldArray[i].isEmpty()) {
                                valueBean.setOldValue(oldArray[i]);
                            } else {
                                valueBean.setOldValue("--");
                            }

                            if (newArray != null && newArray[i] != null && !newArray[i].isEmpty()) {
                                valueBean.setNewValue(newArray[i]);
                            } else {
                                valueBean.setNewValue("--");
                            }

                            valueBeanList.add(valueBean);
                        }
                        auditBean.setValueBeanList(valueBeanList);
                    } else {
                        auditBean.setFields(null);
                    }
                } catch (Exception e) {
                    auditBean.setFields(null);
                }
                return auditBean;
            }));
        } catch (EmptyResultDataAccessException ex) {
            throw ex;
        }
        return audittrace;
    }

    @Transactional(readOnly = true)
    public List<AuditBean> getAuditExcelResults(AuditBean auditInputBean) throws Exception {
        List<AuditBean> taskList;
        try {
            StringBuilder dynamicClause = new StringBuilder();
            //create the dynamic clause
            this.setDynamicClause(auditInputBean, dynamicClause);
            //create the sorting order
            String sortingStr = " order by A.CREATETIME DESC ";

            String sql
                    = "SELECT A.SYSTEMAUDITID, A.DESCRIPTION, " +
                    " S.DESCRIPTION AS SECTIONDES, P.DESCRIPTION AS PAGEDES, T.DESCRIPTION AS TASKDES,A.CREATETIME, " +
                    " A.LASTUPDATEDUSER,A.IP,U.DESCRIPTION AS USERROLE "
                    + "FROM WEB_SYSTEMAUDIT A "
                    + "LEFT OUTER JOIN WEB_SECTION S ON S.SECTIONCODE=A.SECTION "
                    + "LEFT OUTER JOIN WEB_PAGE P ON P.PAGECODE=A.PAGE "
                    + "LEFT OUTER JOIN WEB_TASK T ON T.TASKCODE=A.TASK "
                    + "LEFT OUTER JOIN USERROLE U ON U.USERROLECODE=A.USERROLE "
                    + "WHERE " + dynamicClause.toString() + sortingStr;

            taskList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                AuditBean auditBean = new AuditBean();

                try {
                    auditBean.setId(rs.getString("SYSTEMAUDITID"));
                } catch (Exception e) {
                    auditBean.setId("--");
                }

                try {
                    if (rs.getString("DESCRIPTION") != null && !rs.getString("DESCRIPTION").isEmpty()) {
                        auditBean.setDescription(rs.getString("DESCRIPTION"));
                    } else {
                        auditBean.setDescription("--");
                    }
                } catch (Exception e) {
                    auditBean.setDescription("--");
                }

                try {
                    if (rs.getString("SECTIONDES") != null && !rs.getString("SECTIONDES").isEmpty()) {
                        auditBean.setSection(rs.getString("SECTIONDES"));
                    } else {
                        auditBean.setSection("--");
                    }
                } catch (Exception e) {
                    auditBean.setSection("--");
                }

                try {
                    if (rs.getString("PAGEDES") != null && !rs.getString("PAGEDES").isEmpty()) {
                        auditBean.setPage(rs.getString("PAGEDES"));
                    } else {
                        auditBean.setPage("--");
                    }
                } catch (Exception e) {
                    auditBean.setPage(null);
                }

                try {
                    if (rs.getString("TASKDES") != null && !rs.getString("TASKDES").isEmpty()) {
                        auditBean.setTask(rs.getString("TASKDES"));
                    } else {
                        auditBean.setTask("--");
                    }
                } catch (Exception e) {
                    auditBean.setTask("--");
                }

                try {
                    if (rs.getString("IP") != null && !rs.getString("IP").isEmpty()) {
                        auditBean.setIp(rs.getString("IP"));
                    } else {
                        auditBean.setIp("--");
                    }
                } catch (Exception e) {
                    auditBean.setIp("--");
                }

                try {
                    if (rs.getString("USERROLE") != null && !rs.getString("USERROLE").isEmpty()) {
                        auditBean.setUserRole(rs.getString("USERROLE"));
                    } else {
                        auditBean.setUserRole("--");
                    }
                } catch (Exception e) {
                    auditBean.setUserRole("--");
                }

                try {
                    if (rs.getString("LASTUPDATEDUSER") != null && !rs.getString("LASTUPDATEDUSER").isEmpty()) {
                        auditBean.setUserName(rs.getString("LASTUPDATEDUSER"));
                    } else {
                        auditBean.setUserName("--");
                    }
                } catch (Exception e) {
                    auditBean.setUserName("--");
                }

                try {
                    if (rs.getString("CREATETIME") != null && !rs.getString("CREATETIME").isEmpty()) {
                        auditBean.setCreatedTime(rs.getString("CREATETIME").substring(0, 19));
                    } else {
                        auditBean.setCreatedTime("--");
                    }
                } catch (Exception e) {
                    auditBean.setCreatedTime("--");
                }

                return auditBean;
            });
        } catch (EmptyResultDataAccessException ere) {
            taskList = null;
        } catch (Exception ex) {
            throw ex;
        }
        return taskList;
    }
}

package com.epic.pb.repository.reportmgt.smsoutbox;

import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.smsoutbox.SmsOutboxReportInputBean;
import com.epic.pb.mapping.smsoutbox.SmsOutbox;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.util.varlist.CommonVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Repository
@Scope("prototype")
public class SmsOutboxRepository {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    CommonService commonService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    CommonVarList commonVarList;

    private final String SQL_GET_LIST_DATA_COUNT = "select count(*) from smsoutbox so where ";

    @Transactional(readOnly = true)
    public long getDataCount(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        long count = 0;
        try {
            StringBuilder dynamicClause = new StringBuilder(SQL_GET_LIST_DATA_COUNT);
            //create the where clause
            dynamicClause = this.setDynamicClause(smsOutboxReportInputBean, dynamicClause);
            //create the query
            count = jdbcTemplate.queryForObject(dynamicClause.toString(), Long.class);
        } catch (EmptyResultDataAccessException ere) {
            count = 0;
        } catch (Exception e) {
            throw e;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public List<SmsOutbox> getSmsOutBoxSearchResultList(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        List<SmsOutbox> smsOutboxList = null;
        try {
            StringBuilder dynamicClause = this.setDynamicClause(smsOutboxReportInputBean, new StringBuilder());
            //create sorting order
            String sortingStr = "";
            if (smsOutboxReportInputBean.sortedColumns.get(0) == 0) {
                sortingStr = " order by so.createdtime desc ";
            } else {
                sortingStr = " order by so.createdtime " + smsOutboxReportInputBean.sortDirections.get(0);
            }

            String sql = "" +
                    " select " +
                    " so.id,so.refno,so.mobile,so.message,so.status,so.delstatus,so.delrefno,so.bulkid,so.bulktype,so.partcount, " +
                    " t.description as telcodescription,d.description as departmentdescription,sc.description as channeldescription ,so.category ,so.responsecode, " +
                    " so.createdtime as createdtime,so.lastupdatedtime as lastupdatedtime , so.lastupdateduser as lastupdateduser from smsoutbox so " +
                    " left outer join telco t on t.code=so.telco " +
                    " left outer join department d on d.code=so.department " +
                    " left outer join smschannel sc on sc.channelcode = so.channel " +
                    " where " + dynamicClause.toString() + sortingStr +
                    " offset " + smsOutboxReportInputBean.displayStart + " rows fetch next " + smsOutboxReportInputBean.displayLength + " rows only";

            smsOutboxList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                SmsOutbox smsOutbox = new SmsOutbox();

                try {
                    smsOutbox.setId(rs.getInt("id"));
                } catch (Exception e) {
                    smsOutbox.setId(0);
                }

                try {
                    smsOutbox.setReferenceNo(rs.getString("refno"));
                } catch (Exception e) {
                    smsOutbox.setReferenceNo(null);
                }

                try {
                    smsOutbox.setMobileNumber(rs.getString("mobile"));
                } catch (Exception e) {
                    smsOutbox.setMobileNumber(null);
                }

                try {
                    smsOutbox.setMessage(rs.getString("message"));
                } catch (Exception e) {
                    smsOutbox.setMessage(null);
                }

                try {
                    smsOutbox.setStatus(rs.getString("status"));
                } catch (Exception e) {
                    smsOutbox.setStatus(null);
                }

                try {
                    smsOutbox.setDeleteStatus(rs.getString("delstatus"));
                } catch (Exception e) {
                    smsOutbox.setDeleteStatus(null);
                }

                try {
                    smsOutbox.setDeleteReferenceNo(rs.getString("delrefno"));
                } catch (Exception e) {
                    smsOutbox.setDeleteReferenceNo(null);
                }

                try {
                    smsOutbox.setBulkId(rs.getString("bulkid"));
                } catch (Exception e) {
                    smsOutbox.setBulkId(null);
                }

                try {
                    smsOutbox.setBulkType(rs.getString("bulktype"));
                } catch (Exception e) {
                    smsOutbox.setBulkType(null);
                }

                try {
                    smsOutbox.setPartCount(rs.getInt("partcount"));
                } catch (Exception e) {
                    smsOutbox.setPartCount(0);
                }

                try {
                    smsOutbox.setTelco(rs.getString("telcodescription"));
                } catch (Exception e) {
                    smsOutbox.setTelco(null);
                }

                try {
                    smsOutbox.setDepartment(rs.getString("departmentdescription"));
                } catch (Exception e) {
                    smsOutbox.setDepartment(null);
                }

                try {
                    smsOutbox.setChannel(rs.getString("channeldescription"));
                } catch (Exception e) {
                    smsOutbox.setChannel(null);
                }

                try {
                    smsOutbox.setCategory(rs.getString("category"));
                } catch (Exception e) {
                    smsOutbox.setCategory(null);
                }

                try {
                    smsOutbox.setResponseCode(rs.getString("responsrcode"));
                } catch (Exception e) {
                    smsOutbox.setResponseCode(null);
                }

                try {
                    smsOutbox.setCreatedTime(rs.getDate("createdtime"));
                } catch (Exception e) {
                    smsOutbox.setCreatedTime(null);
                }

                try {
                    smsOutbox.setLastUpdatedTime(rs.getDate("lastupdatedtime"));
                } catch (Exception e) {
                    smsOutbox.setLastUpdatedTime(null);
                }

                try {
                    smsOutbox.setLastUpdatedUser(rs.getString("lastupdateduser"));
                } catch (Exception e) {
                    smsOutbox.setLastUpdatedUser(null);
                }
                return smsOutbox;
            });

        } catch (EmptyResultDataAccessException ex) {
            return smsOutboxList;
        } catch (Exception e) {
            throw e;
        }
        return smsOutboxList;
    }

    @Transactional(readOnly = true)
    public List<SmsOutbox> getSmsOutBoxSearchResultListForReport(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        List<SmsOutbox> smsOutboxList = null;
        try {
            StringBuilder dynamicClause = this.setDynamicClause(smsOutboxReportInputBean, new StringBuilder());
            //create sorting order
            String sortingStr = " order by so.createdtime desc ";

            String sql = "" +
                    " select " +
                    " so.id,so.refno,so.mobile,so.message,so.status,so.delstatus,so.delrefno,so.bulkid,so.bulktype,so.partcount, " +
                    " t.description as telcodescription,d.description as departmentdescription,sc.description as channeldescription ,so.category ,so.responsecode, " +
                    " so.createdtime as createdtime,so.lastupdatedtime as lastupdatedtime , so.lastupdateduser as lastupdateduser from smsoutbox so " +
                    " left outer join telco t on t.code=so.telco " +
                    " left outer join department d on d.code=so.department " +
                    " left outer join smschannel sc on sc.channelcode = so.channel " +
                    " where " + dynamicClause.toString() + sortingStr ;

            smsOutboxList = jdbcTemplate.query(sql, (rs, rowNum) -> {
                SmsOutbox smsOutbox = new SmsOutbox();

                try {
                    smsOutbox.setId(rs.getInt("id"));
                } catch (Exception e) {
                    smsOutbox.setId(0);
                }

                try {
                    smsOutbox.setReferenceNo(rs.getString("refno"));
                } catch (Exception e) {
                    smsOutbox.setReferenceNo(null);
                }

                try {
                    smsOutbox.setMobileNumber(rs.getString("mobile"));
                } catch (Exception e) {
                    smsOutbox.setMobileNumber(null);
                }

                try {
                    smsOutbox.setMessage(rs.getString("message"));
                } catch (Exception e) {
                    smsOutbox.setMessage(null);
                }

                try {
                    smsOutbox.setStatus(rs.getString("status"));
                } catch (Exception e) {
                    smsOutbox.setStatus(null);
                }

                try {
                    smsOutbox.setDeleteStatus(rs.getString("delstatus"));
                } catch (Exception e) {
                    smsOutbox.setDeleteStatus(null);
                }

                try {
                    smsOutbox.setDeleteReferenceNo(rs.getString("delrefno"));
                } catch (Exception e) {
                    smsOutbox.setDeleteReferenceNo(null);
                }

                try {
                    smsOutbox.setBulkId(rs.getString("bulkid"));
                } catch (Exception e) {
                    smsOutbox.setBulkId(null);
                }

                try {
                    smsOutbox.setBulkType(rs.getString("bulktype"));
                } catch (Exception e) {
                    smsOutbox.setBulkType(null);
                }

                try {
                    smsOutbox.setPartCount(rs.getInt("partcount"));
                } catch (Exception e) {
                    smsOutbox.setPartCount(0);
                }

                try {
                    smsOutbox.setTelco(rs.getString("telcodescription"));
                } catch (Exception e) {
                    smsOutbox.setTelco(null);
                }

                try {
                    smsOutbox.setDepartment(rs.getString("departmentdescription"));
                } catch (Exception e) {
                    smsOutbox.setDepartment(null);
                }

                try {
                    smsOutbox.setChannel(rs.getString("channeldescription"));
                } catch (Exception e) {
                    smsOutbox.setChannel(null);
                }

                try {
                    smsOutbox.setCategory(rs.getString("category"));
                } catch (Exception e) {
                    smsOutbox.setCategory(null);
                }

                try {
                    smsOutbox.setResponseCode(rs.getString("responsrcode"));
                } catch (Exception e) {
                    smsOutbox.setResponseCode(null);
                }

                try {
                    smsOutbox.setCreatedTime(rs.getDate("createdtime"));
                } catch (Exception e) {
                    smsOutbox.setCreatedTime(null);
                }

                try {
                    smsOutbox.setLastUpdatedTime(rs.getDate("lastupdatedtime"));
                } catch (Exception e) {
                    smsOutbox.setLastUpdatedTime(null);
                }

                try {
                    smsOutbox.setLastUpdatedUser(rs.getString("lastupdateduser"));
                } catch (Exception e) {
                    smsOutbox.setLastUpdatedUser(null);
                }
                return smsOutbox;
            });
        } catch (EmptyResultDataAccessException ex) {
            return smsOutboxList;
        } catch (Exception e) {
            throw e;
        }
        return smsOutboxList;
    }

    private StringBuilder setDynamicClause(SmsOutboxReportInputBean smsOutboxReportInputBean, StringBuilder dynamicClause) throws Exception {
        dynamicClause.append(" 1=1 ");
        try {
            DateFormat dateFormatterOne = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat dateFormatterTwo = new SimpleDateFormat("dd MMM yyyy");

            if (smsOutboxReportInputBean.getFromDate() != null && !smsOutboxReportInputBean.getFromDate().isEmpty()) {
                String inputFromDate = smsOutboxReportInputBean.getFromDate();
                //format and get from date
                Date dateFromDate = dateFormatterOne.parse(inputFromDate);
                String outputFromDate = dateFormatterTwo.format(dateFromDate);
                //append to dynamic clause
                dynamicClause.append(" and so.createdtime >='").append(outputFromDate).append("'");
            }

            if (smsOutboxReportInputBean.getToDate() != null && !smsOutboxReportInputBean.getToDate().isEmpty()) {
                String inputToDate = smsOutboxReportInputBean.getToDate();
                //format and get to date
                Date dateToDate = dateFormatterOne.parse(inputToDate);
                String outputToDate = dateFormatterTwo.format(dateToDate);
                //append to dynamic clause
                dynamicClause.append(" and so.createdtime <='").append(outputToDate).append("'");
            }

            if (smsOutboxReportInputBean.getTelco() != null && !smsOutboxReportInputBean.getTelco().isEmpty()) {
                dynamicClause.append("and so.telco = '").append(smsOutboxReportInputBean.getTelco()).append("'");
            }

            if (smsOutboxReportInputBean.getDepartment() != null && !smsOutboxReportInputBean.getDepartment().isEmpty()) {
                dynamicClause.append("and so.department = '").append(smsOutboxReportInputBean.getDepartment()).append("'");
            }

            if (smsOutboxReportInputBean.getChannel() != null && !smsOutboxReportInputBean.getChannel().isEmpty()) {
                dynamicClause.append("and so.channel = '").append(smsOutboxReportInputBean.getChannel()).append("'");
            }
        } catch (Exception e) {
            throw e;
        }
        return dynamicClause;
    }
}

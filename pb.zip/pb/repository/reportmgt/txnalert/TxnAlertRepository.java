package com.epic.pb.repository.reportmgt.txnalert;

public class TxnAlertRepository {
}

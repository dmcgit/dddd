package com.epic.pb.controller.usermgt.task;

import com.epic.pb.bean.common.Status;
import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.task.TaskInputBean;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.service.usermgt.task.TaskService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.common.ResponseBean;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.usermgt.task.TaskValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;

@Controller
@Scope("request")
public class TaskController implements AccessControlService, RequestBeanValidation<Object> {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonService commonService;

    @Autowired
    TaskService taskService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    TaskValidator taskValidator;

    @Autowired
    Common common;

    @GetMapping("/viewTask")
    public ModelAndView getTaskPage(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //get status list
            List<Status> statusList = commonRepository.getStatusList(StatusVarList.STATUS_CATEGORY_DEFAULT);
            List<Status> statusActList = common.getActiveStatusList();

            //set values to task bean
            TaskInputBean taskInputBean = new TaskInputBean();
            taskInputBean.setStatusList(statusList);
            taskInputBean.setStatusActList(statusActList);

            //set privileges
            this.applyUserPrivileges(taskInputBean);

            //add values to model map
            modelMap.put("task", taskInputBean);
            modelAndView = new ModelAndView("taskview", "taskviewform", taskInputBean);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("taskview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listTask", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<TaskInputBean> searchTask(@RequestBody TaskInputBean taskInputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK SEARCH");
        DataTablesResponse<TaskInputBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = taskService.getDataCount(taskInputBean);
            //set values to response bean
            responseBean.data.addAll(taskService.getTaskSearchResults(taskInputBean));
            responseBean.echo = taskInputBean.echo;
            responseBean.columns = taskInputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/listDualTask")
    public @ResponseBody
    DataTablesResponse<TempAuthRecBean> searchDualTask(@RequestBody TaskInputBean taskInputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK SEARCH DUAL");
        DataTablesResponse<TempAuthRecBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = taskService.getDataCountDual(taskInputBean);
            //set values to response bean
            responseBean.data.addAll(taskService.getTaskSearchResultsDual(taskInputBean));
            responseBean.echo = taskInputBean.echo;
            responseBean.columns = taskInputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @PostMapping(value = "/addTask", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean addTask(@ModelAttribute("task") Task task, JsonViewResponseBodyAdvice response, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK ADD");
        ResponseBean responseBean = null;
        try {
            BindingResult bindingResult = validateRequestBean(task);
            if (bindingResult.hasErrors()) {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, Locale.US));
            } else {
                String message = taskService.insertTask(task);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.TASK_MGT_SUCCESS_ADD, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @RequestMapping(value = "/getTask", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    Task getTask(@RequestParam String taskCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK GET");
        Task task = new Task();
        try {
            if (taskCode != null && !taskCode.trim().isEmpty()) {
                task = taskService.getTask(taskCode);
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return task;
    }


    @PostMapping(value = "/updateTask", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean updateTask(@ModelAttribute("task") Task task, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK UPDATE");
        ResponseBean responseBean = null;
        try {
            BindingResult bindingResult = validateRequestBean(task);
            if (bindingResult.hasErrors()) {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, Locale.US));
            } else {
                String message = taskService.updateTask(task);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.TASK_MGT_SUCCESS_UPDATE, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }


    @PostMapping(value = "/deleteTask", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean deleteTask(@RequestParam String taskCode, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK DELETE");
        ResponseBean responseBean = null;
        try {
            String message = taskService.deleteTask(taskCode);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.TASK_MGT_SUCCESS_DELETE, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }


    @PostMapping(value = "/confirmTask", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean confirmTask(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK CONFIRM");
        ResponseBean responseBean = null;
        try {
            String message = taskService.confirmTask(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.TASK_MGT_SUCCESS_CONFIRM, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/rejectTask", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean rejectTask(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  TASK REJECT");
        ResponseBean responseBean = null;
        try {
            String message = taskService.rejectTask(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.TASK_MGT_SUCCESS_REJECT, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    public BindingResult validateRequestBean(Object object) {
        DataBinder dataBinder = new DataBinder(object);
        dataBinder.setValidator(taskValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @Override
    public boolean checkAccess(String method, String userRole) {

        logger.info("[" + sessionBean.getSessionid() + "]  TASK PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.TASK_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "getTaskPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchTask":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchDualTask":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "addTask":
                    task = TaskVarList.ADD_TASK;
                    break;
                case "deleteTask":
                    task = TaskVarList.DELETE_TASK;
                    break;
                case "getTask":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "updateTask":
                    task = TaskVarList.UPDATE_TASK;
                    break;
                case "confirmTask":
                    task = TaskVarList.DUAL_AUTH_CONFIRM_TASK;
                    break;
                case "rejectTask":
                    task = TaskVarList.DUAL_AUTH_REJECT_TASK;
                    break;
                default:
                    break;
            }
        }

        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(TaskInputBean taskInputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.TASK_MGT_PAGE, sessionBean);

        taskInputBean.setVadd(false);
        taskInputBean.setVupdate(false);
        taskInputBean.setVdelete(false);
        taskInputBean.setVconfirm(false);
        taskInputBean.setVreject(false);
        taskInputBean.setVdualauth(commonRepository.checkPageIsDualAuthenticate(PageVarList.TASK_MGT_PAGE));

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ADD_TASK)) {
                    taskInputBean.setVadd(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.UPDATE_TASK)) {
                    taskInputBean.setVupdate(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DELETE_TASK)) {
                    taskInputBean.setVdelete(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_CONFIRM_TASK)) {
                    taskInputBean.setVconfirm(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_REJECT_TASK)) {
                    taskInputBean.setVreject(true);
                }
            });
        }

    }

}

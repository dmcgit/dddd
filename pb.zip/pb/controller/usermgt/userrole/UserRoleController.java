package com.epic.pb.controller.usermgt.userrole;

import com.epic.pb.bean.common.Status;
import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.userrole.UserRoleInputBean;
import com.epic.pb.mapping.usermgt.*;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.service.usermgt.userrole.UserRoleService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.common.ResponseBean;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.usermgt.userrole.UserRoleValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
@Scope("prototype")
public class UserRoleController implements AccessControlService, RequestBeanValidation<Object> {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonService commonService;

    @Autowired
    UserRoleService userRoleService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    UserRoleValidator userRoleValidator;

    @Autowired
    Common common;

    @GetMapping("/viewUserRole")
    public ModelAndView viewUserRole(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //get status list
            List<Status> statusList = commonRepository.getStatusList(StatusVarList.STATUS_CATEGORY_DEFAULT);
            List<Status> statusActList = common.getActiveStatusList();

            List<UserRoleType> userroleTypeList = commonRepository.getUserroleTypeList();
            List<UserRoleType> userroleTypeActList = commonRepository.getActUserroleTypeList();

            //set values to page bean
            UserRoleInputBean inputBean = new UserRoleInputBean();
            inputBean.setStatusList(statusList);
            inputBean.setStatusActList(statusActList);
            inputBean.setUserroleTypeList(userroleTypeList);
            inputBean.setUserroleTypeActList(userroleTypeActList);

            //set privileges
            this.applyUserPrivileges(inputBean);

            //add values to model map
            modelMap.put("userrole", inputBean);
            modelAndView = new ModelAndView("userroleview", "userroleviewform", inputBean);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("pageview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listUserRole", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<UserRoleInputBean> searchUserRole(@RequestBody UserRoleInputBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE SEARCH");
        DataTablesResponse<UserRoleInputBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = userRoleService.getDataCount(inputBean);
            //set values to response bean
            responseBean.data.addAll(userRoleService.getUserRoleSearchResults(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/listDualUserRole")
    public @ResponseBody
    DataTablesResponse<TempAuthRecBean> searchDualUserRole(@RequestBody UserRoleInputBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE SEARCH DUAL");
        DataTablesResponse<TempAuthRecBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = userRoleService.getDataCountDual(inputBean);
            //set values to response bean
            responseBean.data.addAll(userRoleService.getUserRoleSearchResultsDual(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @PostMapping(value = "/addUserRole", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean addUserRole(@ModelAttribute("userrole") UserRole userRole, JsonViewResponseBodyAdvice response, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE ADD");
        ResponseBean responseBean = null;
        try {
            BindingResult bindingResult = validateRequestBean(userRole);
            if (bindingResult.hasErrors()) {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, Locale.US));
            } else {
                String message = userRoleService.insertUserRole(userRole);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_ADD, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @RequestMapping(value = "/getUserRole", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    UserRole getUserRole(@RequestParam String userRoleCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE GET");
        UserRole userRole = new UserRole();
        try {
            if (userRoleCode != null && !userRoleCode.trim().isEmpty()) {
                userRole = userRoleService.getUserRole(userRoleCode);
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return userRole;
    }

    @PostMapping(value = "/updateUserRole", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean updateUserRole(@ModelAttribute("userrole") UserRole userRole, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE UPDATE");
        ResponseBean responseBean = new ResponseBean();
        try {
            BindingResult bindingResult = validateRequestBean(userRole);
            if (bindingResult.hasErrors()) {
                responseBean.setErrorMessage(messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, locale));
            } else {
                String message = userRoleService.updateUserRole(userRole);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_UPDATE, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/deleteUserRole", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean deleteUserRole(@RequestParam String userRoleCode, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE DELETE");
        ResponseBean responseBean = null;
        try {
            String message = userRoleService.deleteUserRole(userRoleCode);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_DELETE, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @RequestMapping(value = "/getAllSection", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Section> getAllSection() {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD SECTION");
        List<Section> list = new ArrayList<>();
        try {
            list = userRoleService.getAllSection();
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @RequestMapping(value = "/getAssignedPages", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Page> getAssignedPages(@RequestParam("userroleCode") String userroleCode, @RequestParam("sectionCode") String sectionCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD ASSIGNED PAGES");
        List<Page> list = new ArrayList<>();
        try {
            list = userRoleService.getAssignedPages(userroleCode, sectionCode);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @RequestMapping(value = "/getUnAssignedPages", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Page> getUnAssignedPages(@RequestParam("userroleCode") String userroleCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD UNASSIGNED PAGES");
        List<Page> list = new ArrayList<>();
        try {
            list = userRoleService.getUnAssignedPages(userroleCode);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @PostMapping(value = "/assignPages", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean assignPages(@ModelAttribute("assignPage") UserRoleInputBean inputBean, JsonViewResponseBodyAdvice response, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE ASSIGN PAGE");
        ResponseBean responseBean = null;
        try {
            String message = userRoleService.assignPages(inputBean);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_ASSIGNED_PAGE, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @RequestMapping(value = "/getAssignedSection", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Section> getAssignedSection(@RequestParam("userroleCode") String userroleCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD ASSIGNED SECTION");
        List<Section> list = new ArrayList<>();
        try {
            list = userRoleService.getAssignedSection(userroleCode);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @RequestMapping(value = "/getAssignedTasks", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Task> getAssignedTasks(@RequestParam("userroleCode") String userroleCode, @RequestParam("page") String pageCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD ASSIGNED TASKS");
        List<Task> list = new ArrayList<>();
        try {
            list = userRoleService.getAssignedTasks(userroleCode, pageCode);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @RequestMapping(value = "/getUnAssignedTasks", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    List<Task> getUnAssignedTasks(@RequestParam("userroleCode") String userroleCode, @RequestParam("page") String pageCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE LOAD UNASSIGNED TASKS");
        List<Task> list = new ArrayList<>();
        try {
            list = userRoleService.getUnAssignedTasks(userroleCode, pageCode);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return list;
    }

    @PostMapping(value = "/assignTasks", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean assignTasks(@ModelAttribute("assignTask") UserRoleInputBean inputBean, JsonViewResponseBodyAdvice response, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE ASSIGN TASK");
        ResponseBean responseBean = null;
        try {
            String message = userRoleService.assignTasks(inputBean);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_ASSIGNED_TASK, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/confirmUserRole", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean confirmUserRole(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE CONFIRM");
        ResponseBean responseBean = null;
        try {
            String message = userRoleService.confirmUserRole(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_CONFIRM, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/rejectUserRole", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean rejectUserRole(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE REJECT");
        ResponseBean responseBean = null;
        try {
            String message = userRoleService.rejectUserRole(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.USERROLE_MGT_SUCCESS_REJECT, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    public BindingResult validateRequestBean(Object object) {
        DataBinder dataBinder = new DataBinder(object);
        dataBinder.setValidator(userRoleValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @Override
    public boolean checkAccess(String method, String userRole) {

        logger.info("[" + sessionBean.getSessionid() + "]  USERROLE PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.USERROLE_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "viewUserRole":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchUserRole":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchDualUserRole":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "addUserRole":
                    task = TaskVarList.ADD_TASK;
                    break;
                case "getUserRole":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "updateUserRole":
                    task = TaskVarList.UPDATE_TASK;
                    break;
                case "deleteUserRole":
                    task = TaskVarList.DELETE_TASK;
                    break;
                case "getAllSection":
                    task = TaskVarList.ASSIGN_PAGE;
                    break;
                case "getAssignedPages":
                    task = TaskVarList.ASSIGN_PAGE;
                    break;
                case "getUnAssignedPages":
                    task = TaskVarList.ASSIGN_PAGE;
                    break;
                case "assignPages":
                    task = TaskVarList.ASSIGN_PAGE;
                    break;
                case "getAssignedSection":
                    task = TaskVarList.ASSIGN_TASK;
                    break;
                case "getAssignedTasks":
                    task = TaskVarList.ASSIGN_TASK;
                    break;
                case "getUnAssignedTasks":
                    task = TaskVarList.ASSIGN_TASK;
                    break;
                case "assignTasks":
                    task = TaskVarList.ASSIGN_TASK;
                    break;
                case "confirmUserRole":
                    task = TaskVarList.DUAL_AUTH_CONFIRM_TASK;
                    break;
                case "rejectUserRole":
                    task = TaskVarList.DUAL_AUTH_REJECT_TASK;
                    break;
                default:
                    break;
            }
        }

        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(UserRoleInputBean inputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.USERROLE_MGT_PAGE, sessionBean);

        inputBean.setVadd(false);
        inputBean.setVupdate(false);
        inputBean.setVdelete(false);
        inputBean.setVassignpage(false);
        inputBean.setVassigntask(false);
        inputBean.setVconfirm(false);
        inputBean.setVreject(false);
        inputBean.setVdualauth(commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE));

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ADD_TASK)) {
                    inputBean.setVadd(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.UPDATE_TASK)) {
                    inputBean.setVupdate(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DELETE_TASK)) {
                    inputBean.setVdelete(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ASSIGN_PAGE)) {
                    inputBean.setVassignpage(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ASSIGN_TASK)) {
                    inputBean.setVassigntask(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_CONFIRM_TASK)) {
                    inputBean.setVconfirm(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_REJECT_TASK)) {
                    inputBean.setVreject(true);
                }
            });
        }

    }

}

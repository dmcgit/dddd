package com.epic.pb.controller.usermgt.page;

import com.epic.pb.bean.common.Status;
import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.page.PageInputBean;
import com.epic.pb.mapping.usermgt.Page;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.service.usermgt.page.PageService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.common.ResponseBean;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.StatusVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.usermgt.page.PageValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;

@Controller
@Scope("prototype")
public class PageController implements AccessControlService, RequestBeanValidation<Object>  {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonService commonService;

    @Autowired
    PageService pageService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    PageValidator pageValidator;

    @Autowired
    Common common;

    @GetMapping("/viewPage")
    public ModelAndView viewPage(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //get status list
            List<Status> statusList = commonRepository.getStatusList(StatusVarList.STATUS_CATEGORY_DEFAULT);
            //set values to page bean
            PageInputBean pageInputBean = new PageInputBean();
            pageInputBean.setStatusList(statusList);

            //set privileges
            this.applyUserPrivileges(pageInputBean);

            //add values to model map
            modelMap.put("page", pageInputBean);
            modelAndView = new ModelAndView("pageview", "pageviewform", pageInputBean);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("pageview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listPage", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<PageInputBean> searchPage(@RequestBody PageInputBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE SEARCH");
        DataTablesResponse<PageInputBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = pageService.getDataCount(inputBean);
            //set values to response bean
            responseBean.data.addAll(pageService.getPageSearchResults(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/listDualPage")
    public @ResponseBody
    DataTablesResponse<TempAuthRecBean> searchDualPage(@RequestBody PageInputBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE SEARCH DUAL");
        DataTablesResponse<TempAuthRecBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = pageService.getDataCountDual(inputBean);
            //set values to response bean
            responseBean.data.addAll(pageService.getPageSearchResultsDual(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/getPage", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    Page getPage(@RequestParam String pageCode) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE GET");
        Page page = new Page();
        try {
            if (pageCode != null && !pageCode.trim().isEmpty()) {
                page = pageService.getPage(pageCode);
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return page;
    }

    @PostMapping(value = "/updatePage", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean updatePage(@ModelAttribute("page") Page page, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE UPDATE");
        ResponseBean responseBean = new ResponseBean();
        try {
            BindingResult bindingResult = validateRequestBean(page);
            if (bindingResult.hasErrors()) {
                responseBean.setErrorMessage(messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()},locale));
            } else {
                String message = pageService.updatePage(page);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PAGE_MGT_SUCCESS_UPDATE, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }


    @PostMapping(value = "/confirmPage", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean confirmPage(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE CONFIRM");
        ResponseBean responseBean = null;
        try {
            String message = pageService.confirmPage(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PAGE_MGT_SUCCESS_CONFIRM, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/rejectPage", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean rejectPage(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PAGE REJECT");
        ResponseBean responseBean = null;
        try {
            String message = pageService.rejectPage(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PAGE_MGT_SUCCESS_REJECT, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    public BindingResult validateRequestBean(Object object) {
        DataBinder dataBinder = new DataBinder(object);
        dataBinder.setValidator(pageValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @Override
    public boolean checkAccess(String method, String userRole) {

        logger.info("[" + sessionBean.getSessionid() + "] PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.PAGE_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "viewPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchDualPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "getPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "updatePage":
                    task = TaskVarList.UPDATE_TASK;
                    break;
                case "confirmPage":
                    task = TaskVarList.DUAL_AUTH_CONFIRM_TASK;
                    break;
                case "rejectPage":
                    task = TaskVarList.DUAL_AUTH_REJECT_TASK;
                    break;
                default:
                    break;
            }
        }

        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(PageInputBean inputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.PAGE_MGT_PAGE, sessionBean);

        inputBean.setVupdate(false);
        inputBean.setVconfirm(false);
        inputBean.setVreject(false);
        inputBean.setVdualauth(commonRepository.checkPageIsDualAuthenticate(PageVarList.PAGE_MGT_PAGE));

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.UPDATE_TASK)) {
                    inputBean.setVupdate(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_CONFIRM_TASK)) {
                    inputBean.setVconfirm(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_REJECT_TASK)) {
                    inputBean.setVreject(true);
                }
            });
        }

    }

}

package com.epic.pb.controller.sectionmgt.passwordpolicy;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordpolicy.PasswordPolicyInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.passwordpolicy.PasswordPolicy;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.service.sectionmgt.passwordpolicy.PasswordPolicyService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.common.ResponseBean;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.sectionmgt.passwordpolicy.PasswordPolicyValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;
/*
        User: suren_v
        Date: 2/1/2021
        Time: 10:54 AM
 */

@Controller
public class PasswordPolicyController implements AccessControlService, RequestBeanValidation<Object> {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonService commonService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    PasswordPolicyService passwordPolicyService;

    @Autowired
    PasswordPolicyValidator passwordPolicyValidator;

    @Autowired
    Common common;

    @GetMapping("/viewPasswordPolicy")
    public ModelAndView getPasswordPolicyPage(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //set values to password parameter bean
            PasswordPolicyInputBean pwdPolicy = new PasswordPolicyInputBean();

            //set privileges
            this.applyUserPrivileges(pwdPolicy);

            //add values to model map
            modelMap.put("passwordPolicy", pwdPolicy);
            modelAndView = new ModelAndView("passwordpolicyview", "passwordpolicyviewform", pwdPolicy);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("passwordpolicyview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listPasswordPolicy", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<PasswordPolicyInputBean> searchPasswordPolicy(@RequestBody PasswordPolicyInputBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY SEARCH");
        DataTablesResponse<PasswordPolicyInputBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = passwordPolicyService.getDataCount(inputBean);
            //set values to response bean
            responseBean.data.addAll(passwordPolicyService.getPasswordPolicySearchResults(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/listDualPasswordPolicy")
    public @ResponseBody
    DataTablesResponse<TempAuthRecBean> searchDualPasswordPolicy(@RequestBody PasswordPolicyInputBean passwordPolicyInputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY SEARCH DUAL");
        DataTablesResponse<TempAuthRecBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = passwordPolicyService.getDataCountDual(passwordPolicyInputBean);
            //set values to response bean
            responseBean.data.addAll(passwordPolicyService.getPasswordPolicySearchResultsDual(passwordPolicyInputBean));
            responseBean.echo = passwordPolicyInputBean.echo;
            responseBean.columns = passwordPolicyInputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/getPasswordPolicy", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    PasswordPolicy getPasswordPolicy(@RequestParam String policyid) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY GET");
        PasswordPolicy passwordPolicy = new PasswordPolicy();
        try {
            if (policyid != null && !policyid.trim().isEmpty()) {
                passwordPolicy = passwordPolicyService.getWebPasswordPolicy(Integer.parseInt(policyid));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return passwordPolicy;
    }

    @PostMapping(value = "/updatePasswordPolicy", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean updatePasswordPolicy(@ModelAttribute("passwordPolicy") PasswordPolicy passwordPolicy, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY UPDATE");
        ResponseBean responseBean = null;
        try {
            BindingResult bindingResult = validateRequestBean(passwordPolicy);
            if (bindingResult.hasErrors()) {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, Locale.US));
            } else {
                String message = passwordPolicyService.updatePasswordPolicy(passwordPolicy);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_POLICY_MGT_SUCCESS_UPDATE, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/confirmPasswordPolicy", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean confirmPasswordPolicy(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY CONFIRM");
        ResponseBean responseBean = null;
        try {
            String message = passwordPolicyService.confirmPasswordPolicy(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_POLICY_MGT_SUCCESS_CONFIRM, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/rejectPasswordPolicy", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean rejectPasswordPolicy(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY REJECT");
        ResponseBean responseBean = null;
        try {
            String message = passwordPolicyService.rejectPasswordPolicy(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_POLICY_MGT_SUCCESS_REJECT, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @Override
    public BindingResult validateRequestBean(Object o) {
        DataBinder dataBinder = new DataBinder(o);
        dataBinder.setValidator(passwordPolicyValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @Override
    public boolean checkAccess(String method, String userRole) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD POLICY PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.PASSWORDPOLICY_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "getPasswordPolicyPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchPasswordPolicy":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchDualPasswordPolicy":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "getPasswordPolicy":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "updatePasswordPolicy":
                    task = TaskVarList.UPDATE_TASK;
                    break;
                case "confirmPasswordPolicy":
                    task = TaskVarList.DUAL_AUTH_CONFIRM_TASK;
                    break;
                case "rejectPasswordPolicy":
                    task = TaskVarList.DUAL_AUTH_REJECT_TASK;
                    break;
                default:
                    break;
            }
        }
        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(PasswordPolicyInputBean passwordPolicyInputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.PASSWORDPOLICY_MGT_PAGE, sessionBean);

        passwordPolicyInputBean.setVadd(false);
        passwordPolicyInputBean.setVupdate(false);
        passwordPolicyInputBean.setVdelete(false);
        passwordPolicyInputBean.setVconfirm(false);
        passwordPolicyInputBean.setVreject(false);
        passwordPolicyInputBean.setVdualauth(commonRepository.checkPageIsDualAuthenticate(PageVarList.PASSWORDPOLICY_MGT_PAGE));

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ADD_TASK)) {
                    passwordPolicyInputBean.setVadd(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.UPDATE_TASK)) {
                    passwordPolicyInputBean.setVupdate(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DELETE_TASK)) {
                    passwordPolicyInputBean.setVdelete(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_CONFIRM_TASK)) {
                    passwordPolicyInputBean.setVconfirm(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_REJECT_TASK)) {
                    passwordPolicyInputBean.setVreject(true);
                }
            });
        }

    }
}

package com.epic.pb.controller.sectionmgt.passwordparam;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordparam.PasswordParamInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.task.TaskInputBean;
import com.epic.pb.mapping.sectionmgt.PasswordParam;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.common.CommonService;
import com.epic.pb.service.sectionmgt.passwordparam.PasswordParamService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.common.ResponseBean;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.sectionmgt.passwordparam.PasswordParamValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;

/*
        User: suren_v
        Date: 2/1/2021
        Time: 10:54 AM
 */

@Controller
public class PasswordParamController implements AccessControlService, RequestBeanValidation<Object> {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonService commonService;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    PasswordParamService passwordParamService;

    @Autowired
    PasswordParamValidator passwordParamValidator;

    @Autowired
    Common common;

    @GetMapping("/viewPasswordParam")
    public ModelAndView getPasswordParamPage(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //set values to password parameter bean
            PasswordParamInputBean paramInputBean = new PasswordParamInputBean();
            // retrieving user role and common password param list
            paramInputBean.setUserRoleTypeBeanList(commonRepository.getActiveUserRoleTypeList());
            paramInputBean.setPasswordParamBeanList(commonRepository.getCommonPasswordParamList());

            //set privileges
            this.applyUserPrivileges(paramInputBean);

            //add values to model map
            modelMap.put("passwordParam", paramInputBean);
            modelAndView = new ModelAndView("passwordparamview", "passwordparamviewform", paramInputBean);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("passwordparamview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listPasswordParam", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<PasswordParamInputBean> searchPasswordParam(@RequestBody PasswordParamInputBean paramBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM SEARCH");
        DataTablesResponse<PasswordParamInputBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = passwordParamService.getDataCount(paramBean);
            //set values to response bean
            responseBean.data.addAll(passwordParamService.getPasswordParamSearchResults(paramBean));
            responseBean.echo = paramBean.echo;
            responseBean.columns = paramBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/listDualPasswordParam")
    public @ResponseBody
    DataTablesResponse<TempAuthRecBean> searchDualPasswordParam(@RequestBody PasswordParamInputBean passwordParamInputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM SEARCH DUAL");
        DataTablesResponse<TempAuthRecBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = passwordParamService.getDataCountDual(passwordParamInputBean);
            //set values to response bean
            responseBean.data.addAll(passwordParamService.getPasswordParamSearchResultsDual(passwordParamInputBean));
            responseBean.echo = passwordParamInputBean.echo;
            responseBean.columns = passwordParamInputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/getPasswordParam", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    PasswordParam getPasswordParam(@RequestParam String passwordParam) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM GET");
        PasswordParam password = new PasswordParam();
        try {
            if (passwordParam != null && !passwordParam.trim().isEmpty()) {
                password = passwordParamService.getPasswordParam(passwordParam);
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return password;
    }

    @PostMapping(value = "/updatePasswordParam", produces = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody
    ResponseBean updatePasswordParam(@ModelAttribute("passwordParam") PasswordParam passwordParam, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM UPDATE");
        ResponseBean responseBean = null;
        try {
            BindingResult bindingResult = validateRequestBean(passwordParam);
            if (bindingResult.hasErrors()) {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(bindingResult.getAllErrors().get(0).getCode(), new Object[]{bindingResult.getAllErrors().get(0).getDefaultMessage()}, Locale.US));
            } else {
                String message = passwordParamService.updatePasswordParam(passwordParam);
                if (message.isEmpty()) {
                    responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_PARAM_MGT_SUCCESS_UPDATE, null, locale), null);
                } else {
                    responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
                }
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/confirmPasswordParam", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean confirmPasswordParam(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM CONFIRM");
        ResponseBean responseBean = null;
        try {
            String message = passwordParamService.confirmPasswordParam(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_PARAM_MGT_SUCCESS_CONFIRM, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @PostMapping(value = "/rejectPasswordParam", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseBean rejectPasswordParam(@RequestParam String id, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAM REJECT");
        ResponseBean responseBean = null;
        try {
            String message = passwordParamService.rejectPasswordParam(id);
            if (message.isEmpty()) {
                responseBean = new ResponseBean(true, messageSource.getMessage(MessageVarList.PASSWORD_PARAM_MGT_SUCCESS_REJECT, null, locale), null);
            } else {
                responseBean = new ResponseBean(false, null, messageSource.getMessage(message, null, locale));
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            responseBean = new ResponseBean(false, null, messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
        }
        return responseBean;
    }

    @Override
    public BindingResult validateRequestBean(Object o) {
        DataBinder dataBinder = new DataBinder(o);
        dataBinder.setValidator(passwordParamValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @Override
    public boolean checkAccess(String method, String userRole) {
        logger.info("[" + sessionBean.getSessionid() + "]  PASSWORD PARAMETER PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.PASSWORD_PARAMETER_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "getPasswordParamPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchPasswordParam":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "getPasswordParam":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchDualPasswordParam":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "updatePasswordParam":
                    task = TaskVarList.UPDATE_TASK;
                    break;
                case "confirmPasswordParam":
                    task = TaskVarList.DUAL_AUTH_CONFIRM_TASK;
                    break;
                case "rejectPasswordParam":
                    task = TaskVarList.DUAL_AUTH_REJECT_TASK;
                    break;
                default:
                    break;
            }
        }

        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(PasswordParamInputBean passwordParamInputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.PASSWORD_PARAMETER_MGT_PAGE, sessionBean);

        passwordParamInputBean.setVadd(false);
        passwordParamInputBean.setVupdate(false);
        passwordParamInputBean.setVdelete(false);
        passwordParamInputBean.setVconfirm(false);
        passwordParamInputBean.setVreject(false);
        passwordParamInputBean.setVdualauth(commonRepository.checkPageIsDualAuthenticate(PageVarList.PASSWORD_PARAMETER_MGT_PAGE));

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.ADD_TASK)) {
                    passwordParamInputBean.setVadd(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.UPDATE_TASK)) {
                    passwordParamInputBean.setVupdate(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DELETE_TASK)) {
                    passwordParamInputBean.setVdelete(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_CONFIRM_TASK)) {
                    passwordParamInputBean.setVconfirm(true);
                } else if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DUAL_AUTH_REJECT_TASK)) {
                    passwordParamInputBean.setVreject(true);
                }
            });
        }

    }
}

package com.epic.pb.controller.audit;

import com.epic.pb.bean.audit.AuditBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.audit.AuditService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.TaskVarList;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;

@Controller
@Scope("request")
public class AuditController implements AccessControlService {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    AuditService auditService;


    @Autowired
    Common common;

    @GetMapping("/viewAudit")
    public ModelAndView getAuditPage(ModelMap modelMap, @ModelAttribute("actionPerformed") String actionPerformed, @ModelAttribute("result") String result, @ModelAttribute("type") String type, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //set values to audit bean
            AuditBean auditBean = new AuditBean();
            auditBean.setSectionList(commonRepository.getSectionList());
            auditBean.setPageList(commonRepository.getPageList());
            auditBean.setTaskList(commonRepository.getTaskList());

            //set privileges
            this.applyUserPrivileges(auditBean);

            //add values to model map
            modelMap.put("audit", auditBean);
            modelAndView = new ModelAndView("auditview", "auditviewform", auditBean);
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("auditview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listAudit", method = RequestMethod.POST, headers = {"content-type=application/json"})
    public @ResponseBody
    DataTablesResponse<AuditBean> searchAudit(@RequestBody AuditBean inputBean, HttpServletResponse response, HttpServletRequest request) {
        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT SEARCH");
        DataTablesResponse<AuditBean> responseBean = new DataTablesResponse<>();
        try {
            long countTasks = auditService.getDataCount(inputBean);
            //set values to response bean
            responseBean.data.addAll(auditService.getAuditSearchResults(inputBean));
            responseBean.echo = inputBean.echo;
            responseBean.columns = inputBean.columns;
            responseBean.totalRecords = countTasks;
            responseBean.totalDisplayRecords = countTasks;
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/getAudit", method = RequestMethod.GET, headers = {"content-type=application/json"})
    public @ResponseBody
    AuditBean getAudit(@RequestParam String id) {
        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT GET");
        AuditBean audittrace = new AuditBean();
        try {
            if (id != null && !id.trim().isEmpty()) {
                audittrace = auditService.getAudit(id);
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return audittrace;
    }

    @RequestMapping(value = "/excelAudit", method = RequestMethod.POST)
    void excelReportAudit(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("auditviewform") AuditBean inputBean) {
        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT EXCEL");
        OutputStream outputStream = null;
        try {

        } catch (Exception ex) {
            logger.error("Exception  :  ", ex);
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }
            } catch (IOException ex) {
                //do nothing
            }
        }
    }

    @RequestMapping(value = "/pdfAudit", method = RequestMethod.POST)
    void pdfReportAudit(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("auditviewform") AuditBean inputBean) {
        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT PDF");
        OutputStream outputStream = null;
        try {

        } catch (Exception ex) {
            logger.error("Exception  :  ", ex);
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }
            } catch (IOException ex) {
                //do nothing
            }
        }

    }


    @Override
    public boolean checkAccess(String method, String userRole) {

        logger.info("[" + sessionBean.getSessionid() + "]  AUDIT PAGE CHECKACCESS");
        boolean status;
        String page = PageVarList.AUDITTRACE_MGT_PAGE;
        String task = null;

        if (null != method) {
            switch (method) {
                case "getAuditPage":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "searchAudit":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "getAudit":
                    task = TaskVarList.VIEW_TASK;
                    break;
                case "excelReportAudit":
                    task = TaskVarList.DOWNLOAD_TASK;
                    break;
                default:
                    break;
            }
        }

        status = common.checkMethodAccess(task, page, userRole, sessionBean);
        return status;
    }

    private void applyUserPrivileges(AuditBean inputBean) {

        List<Task> tasklist = common.getUserTaskListByPage(PageVarList.AUDITTRACE_MGT_PAGE, sessionBean);

        inputBean.setVdownload(false);

        if (tasklist != null && !tasklist.isEmpty()) {
            tasklist.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DOWNLOAD_TASK)) {
                    inputBean.setVdownload(true);
                }
            });
        }

    }

}

package com.epic.pb.controller.reportmgt.smsoutbox;

import com.epic.pb.annotation.accesscontrol.AccessControl;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.smsoutbox.SmsOutboxReportInputBean;
import com.epic.pb.mapping.department.Department;
import com.epic.pb.mapping.smschannel.SmsChannel;
import com.epic.pb.mapping.smsoutbox.SmsOutbox;
import com.epic.pb.mapping.telco.Telco;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.service.reportmgt.smsoutbox.SmsOutboxService;
import com.epic.pb.util.common.AccessControlService;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.common.DataTablesResponse;
import com.epic.pb.util.varlist.CommonVarList;
import com.epic.pb.util.varlist.MessageVarList;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.TaskVarList;
import com.epic.pb.validators.RequestBeanValidation;
import com.epic.pb.validators.smsoutput.SmsOutputValidator;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

@Controller
@Scope("request")
public class SmsOutboxReportController implements AccessControlService, RequestBeanValidation<Object> {
    private final Log logger = LogFactory.getLog(getClass());

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    Common common;

    @Autowired
    CommonVarList commonVarList;

    @Autowired
    SmsOutputValidator smsOutputValidator;

    @Autowired
    SmsOutboxService smsOutboxService;

    @GetMapping(value = "/viewSmsOutBox")
    @AccessControl(pageCode = PageVarList.SMSOUTBOX_REPORT_PAGE, taskCode = TaskVarList.VIEW_TASK)
    public ModelAndView getSytemUserPage(ModelMap modelMap, Locale locale) {
        logger.info("[" + sessionBean.getSessionid() + "]  SMS OUTBOX REPORT PAGE VIEW");
        ModelAndView modelAndView = null;
        try {
            //redirect to home page
            modelAndView = new ModelAndView("smsoutboxreportview", "beanmap", new ModelMap());
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
            //set the error message to model map
            modelMap.put("msg", messageSource.getMessage(MessageVarList.COMMON_ERROR_PROCESS, null, locale));
            modelAndView = new ModelAndView("smsoutboxreportview", modelMap);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/listSmsOutBox", method = RequestMethod.POST, headers = {"content-type=application/json"})
    @AccessControl(pageCode = PageVarList.SMSOUTBOX_REPORT_PAGE, taskCode = TaskVarList.VIEW_TASK)
    public @ResponseBody
    DataTablesResponse<SmsOutbox> searchSmsOutbox(@RequestBody SmsOutboxReportInputBean smsOutboxReportInputBean) {
        logger.info("[" + sessionBean.getSessionid() + "]  SMS OUTBOX REPORT SEARCH");
        DataTablesResponse<SmsOutbox> responseBean = new DataTablesResponse<>();
        try {
            long count = smsOutboxService.getCount(smsOutboxReportInputBean);
            if (count > 0) {
                List<SmsOutbox> smsOutboxList = smsOutboxService.getSmsOutBoxSearchResultList(smsOutboxReportInputBean);
                //set data set to response bean
                responseBean.data.addAll(smsOutboxList);
                responseBean.echo = smsOutboxReportInputBean.echo;
                responseBean.columns = smsOutboxReportInputBean.columns;
                responseBean.totalRecords = count;
                responseBean.totalDisplayRecords = count;
            } else {
                //set data set to response bean
                responseBean.data.addAll(new ArrayList<>());
                responseBean.echo = smsOutboxReportInputBean.echo;
                responseBean.columns = smsOutboxReportInputBean.columns;
                responseBean.totalRecords = count;
                responseBean.totalDisplayRecords = count;
            }
        } catch (Exception e) {
            logger.error("Exception  :  ", e);
        }
        return responseBean;
    }

    @RequestMapping(value = "/reportSmsOutBox/{type}", method = RequestMethod.POST)
    @AccessControl(pageCode = PageVarList.SMSOUTBOX_REPORT_PAGE, taskCode = TaskVarList.DOWNLOAD_TASK)
    public @ResponseBody
    void downloadSmsOutputPdfReport(@PathVariable("type") String type, @ModelAttribute("smsoutputreport") SmsOutboxReportInputBean smsOutboxReportInputBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        logger.info("[" + sessionBean.getSessionid() + "]  SMS OUTBOX REPORT PDF");
        OutputStream outputStream = null;
        try {
            List<SmsOutbox> smsOutboxList = smsOutboxService.getSmsOutBoxSearchResultListForReport(smsOutboxReportInputBean);
            if (!smsOutboxList.isEmpty()) {
                InputStream jasperStream = this.getClass().getResourceAsStream("/reports/smsoutbox/SmsOutboxReport.jasper");
                Map<String, Object> parameterMap = new HashMap<>();
                //set parameters to map
                parameterMap.put("fromdate", smsOutboxReportInputBean.getFromDate());
                parameterMap.put("todate", smsOutboxReportInputBean.getToDate());
                parameterMap.put("telco", smsOutboxReportInputBean.getTelco());
                parameterMap.put("department", smsOutboxReportInputBean.getDepartment());
                parameterMap.put("channel", smsOutboxReportInputBean.getChannel());

                JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, new JRBeanCollectionDataSource(smsOutboxList));

                if (type.equals("pdf")) {
                    httpServletResponse.setContentType("application/x-download");
                    httpServletResponse.setHeader("Content-disposition", "inline; filename=SmsOutBox-Report.pdf");
                    final OutputStream outStream = httpServletResponse.getOutputStream();
                    JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);

                } else if (type.equals("xls")) {
                    final OutputStream outStream1 = httpServletResponse.getOutputStream();
                    // Create a JRXlsExporter instance
                    JRXlsExporter exporter = new JRXlsExporter();
                    // jrxls Exporter
                    exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
                    exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outStream1);

                    httpServletResponse.setContentType("application/vnd.ms-excel");
                    httpServletResponse.setHeader("Content-disposition", "inline; filename=SmsOutBox-Report.xls");
                    exporter.exportReport();
                }
            }
        } catch (Exception ex) {
            logger.error("Exception  :  ", ex);
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }
            } catch (IOException ex) {
            }
        }
    }

    @Override
    public boolean checkAccess(String method, String userRole) {
        logger.info("[" + sessionBean.getSessionid() + "]  SMS OUTBOX REPORT PAGE CHECKACCESS");
        return true;
    }

    @Override
    public BindingResult validateRequestBean(Object o) {
        DataBinder dataBinder = new DataBinder(o);
        dataBinder.setValidator(smsOutputValidator);
        dataBinder.validate();
        return dataBinder.getBindingResult();
    }

    @ModelAttribute
    public void getSmsOutBoxReportBean(Model map) throws Exception {
        SmsOutboxReportInputBean smsOutboxReportInputBean = new SmsOutboxReportInputBean();
        //get telco list , department list , sms channel list
        List<Telco> telcoList = commonRepository.getTelcoList(commonVarList.STATUS_ACTIVE);
        List<Department> departmentList = commonRepository.getDepartmentList(commonVarList.STATUS_ACTIVE);
        List<SmsChannel> smsChannelList = commonRepository.getSmsChannelList(commonVarList.STATUS_ACTIVE);
        //set values to bean
        smsOutboxReportInputBean.setTelcoList(telcoList);
        smsOutboxReportInputBean.setDepartmentList(departmentList);
        smsOutboxReportInputBean.setSmsChannelList(smsChannelList);
        //add privileges to input bean
        this.applyUserPrivileges(smsOutboxReportInputBean);
        //add values to model map
        map.addAttribute("smsoutputreport", smsOutboxReportInputBean);
    }

    private void applyUserPrivileges(SmsOutboxReportInputBean smsOutboxReportInputBean) {
        List<Task> taskList = common.getUserTaskListByPage(PageVarList.SMSOUTBOX_REPORT_PAGE, sessionBean);
        smsOutboxReportInputBean.setVdownload(false);
        //check task list one by one
        if (taskList != null && !taskList.isEmpty()) {
            taskList.forEach(task -> {
                if (task.getTaskCode().equalsIgnoreCase(TaskVarList.DOWNLOAD_TASK)) {
                    smsOutboxReportInputBean.setVdownload(true);
                }
            });
        }
    }
}

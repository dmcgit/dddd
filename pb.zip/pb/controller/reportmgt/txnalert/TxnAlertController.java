package com.epic.pb.controller.reportmgt.txnalert;

public class TxnAlertController {
}

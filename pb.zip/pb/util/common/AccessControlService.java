package com.epic.pb.util.common;

public interface AccessControlService {
    public boolean checkAccess(String method, String userRole);
}

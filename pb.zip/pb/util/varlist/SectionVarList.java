package com.epic.pb.util.varlist;

public class SectionVarList {

    public static final String SECTION_USER_MGT = "UMSC";
    public static final String SECTION_SYS_CONFIGURATION_MGT = "SCSC";
    public static final String SECTION_SYS_AUDIT_MGT = "SYAU";
}

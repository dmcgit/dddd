package com.epic.pb.util.varlist;

public class PageVarList {
    public static final String LOGIN_PAGE = "LGIN";
    public static final String HOME = "HOME";
    public static final String TASK_MGT_PAGE = "TSMT";
    public static final String PAGE_MGT_PAGE = "PGMT";
    public static final String USER_MGT_PAGE = "USMT";
    public static final String USERROLE_MGT_PAGE = "URMT";
    public static final String REGION_MGT_PAGE = "RGMT";
    public static final String AUDITTRACE_MGT_PAGE = "ATMT";
    public static final String BRANCH_MGT_PAGE = "BRMT";
    public static final String MERCHANT_CAT_MGT_PAGE = "MCMT";
    public static final String AGENT_MGT_PAGE = "MTMT";
    public static final String PASSWORD_PARAMETER_MGT_PAGE = "PPMT";
    public static final String PASSWORDPOLICY_MGT_PAGE = "PWPM";
    public static final String SECTION_MGT_PAGE = "SCMT";
    public static final String OPERHOUR_PARAM_MGT_PAGE = "OHMT";
    public static final String TRANSACTIONTYPE_MGT_PAGE = "TTMT";
    public static final String DEPARTMENT_MGT_PAGE = "DPMT";
    public static final String CATEGORY_MGT_PAGE = "CTMT";
    public static final String SMPPCONFIG_MGT_PAGE = "SMMT";
    public static final String SMSOUTBOX_REPORT_PAGE = "SORT";
}

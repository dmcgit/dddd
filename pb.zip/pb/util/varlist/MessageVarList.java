package com.epic.pb.util.varlist;

public class MessageVarList {
    //-------------------------- start common messages----------------------------------------------------------------//
    public static final String COMMON_ERROR_PROCESS = "common.error.process";
    public static final String COMMON_ERROR_RECORD_DOESNOT_EXISTS = "common.error.record.doesnot.exists";
    public static final String COMMON_ERROR_NO_VALUE_CHANGE = "common.error.no.value.change";
    public static final String COMMON_ERROR_ALRADY_USE = "common.error.alreadyuse";
    //-------------------------- end common messages------------------------------------------------------------------//

    //-------------------------- start user login messages------------------------------------------------------------//
    public static final String LOGIN_USERNAME_EMPTY = "login.username.empty";
    public static final String LOGIN_USERNAME_INVALID = "login.username.invalid";
    public static final String LOGIN_PASSWORD_EMPTY = "login.password.empty";
    public static final String LOGIN_INVALID = "login.invalid";
    public static final String LOGIN_DEACTIVE = "login.deactive";
    public static final String LOGIN_IDLEDEACTIVE = "login.idledeactive";
    public static final String LOGIN_EXPIRYWARNING = "login.expirywarning";
    public static final String LOGIN_STATUSTIMEOUT = "login.statustimeout";
    //-------------------------- end user login messages--------------------------------------------------------------//

    //-------------------------- start password reset mgt-------------------------------------------------------------//
    public static final String PASSWORDRESET_NEWUSER = "passwordreset.newuser";
    public static final String PASSWORDRESET_RESETUSER = "passwordreset.resetuser";
    public static final String PASSWORDRESET_CHANGEPWD = "passwordreset.changepwd";
    public static final String PASSWORDRESET_EXPPWD = "passwordreset.exppwd";
    public static final String PASSWORDRESET_SUCCESS = "passwordreset.changepwd.success";
    //-------------------------- start password reset mgt-------------------------------------------------------------//

    //-------------------------- task mgt-----------------------------------------------------------------------------//
    public static final String TASK_MGT_EMPTY_TASKCODE = "task.empty.taskcode";
    public static final String TASK_MGT_EMPTY_DESCRIPTION = "task.empty.description";
    public static final String TASK_MGT_EMPTY_STATUS = "task.empty.status";
    public static final String TASK_MGT_SUCCESS_ADD = "task.success.add";
    public static final String TASK_MGT_SUCCESS_UPDATE = "task.success.update";
    public static final String TASK_MGT_SUCCESS_DELETE = "task.success.delete";
    public static final String TASK_MGT_SUCCESS_CONFIRM = "task.success.confirm";
    public static final String TASK_MGT_SUCCESS_REJECT = "task.success.reject";
    public static final String TASK_MGT_ALREADY_EXISTS = "task.already.exists";
    //-------------------------- task mgt-----------------------------------------------------------------------------//

    //-------------------------- start tmp record messages------------------------------------------------------------//
    public static final String TMP_RECORD_ALREADY_EXISTS = "tmp.record.already.exists";
    //-------------------------- start tmp record messages------------------------------------------------------------//

    //-------------------------- start user password change ----------------------------------------------------------//
    public static final String USER_CURRENTPASSWORD_EMPTY = "user.currentpassword.empty";
    public static final String USER_CURRENTPASSWORD_INVALID = "user.currentpassword.invalid";
    public static final String USER_NEWPASSWORD_EMPTY = "user.newpassword.empty";
    public static final String USER_NEWCONFIRMPASSWORD_EMPTY = "user.newconfirmpassword.empty";
    public static final String USER_NEWPASSWORD_TOO_SHORT = "user.newpassword.tooshort";
    public static final String USER_NEWPASSWORD_TOO_LONG = "user.newpassword.toolong";
    public static final String USER_NEWPASSWORD_LESS_SPECIALCHARACTERS = "user.newpassword.less.specialcharacters";
    public static final String USER_NEWPASSWORD_LESS_UPPERCHARACTERS = "user.newpassword.less.uppercharacters";
    public static final String USER_NEWPASSWORD_LESS_LOWERCHARACTERS = "user.newpassword.less.lowercharacters";
    public static final String USER_NEWPASSWORD_LESS_NUMERICCHARACTERS = "user.newpassword.less.numericcharacters";
    public static final String USER_NEWPASSWORD_MORE_REPEATCHARACTERS = "user.newpassword.more.repeatcharacters";
    public static final String USER_NEWPASSWORD_EXIST_PASSWORDHISTORY = "user.newpassword.exist.passwordhistory";
    public static final String USER_NEWPASSWORD_RESET_ERROR = "user.newpassword.reset.error";
    public static final String USER_SESSION_NOTFOUND = "user.session.notfound";
    public static final String USER_SESSION_INVALID = "user.session.invalid";
    public static final String USER_REQUESTED_PASSWORDCHANGE = "user.requested.passwordchange";
    public static final String USER_PRIVILEGE_INSUFFICIENT = "user.privilege.insufficient";
    //-------------------------- start user password change-----------------------------------------------------------//

    //-------------------------- start page mgt-----------------------------------------------------------------------//
    public static final String PAGE_MGT_EMPTY_PAGECODE = "page.empty.pagecode";
    public static final String PAGE_MGT_EMPTY_DESCRIPTION = "page.empty.description";
    public static final String PAGE_MGT_EMPTY_SORTKEY = "page.empty.sortkey";
    public static final String PAGE_MGT_SORTKEY_EXIST = "page.exist.sortkey";
    public static final String PAGE_MGT_SORTKEY_TEMP_EXIST = "page.temp.exist.sortkey";
    public static final String PAGE_MGT_EMPTY_STATUS = "page.empty.status";
    public static final String PAGE_MGT_SUCCESS_UPDATE = "page.success.update";
    public static final String PAGE_MGT_ERROR_UPDATE = "page.error.update";
    public static final String PAGE_MGT_SUCCESS_CONFIRM = "page.success.confirm";
    public static final String PAGE_MGT_SUCCESS_REJECT = "page.success.reject";
    //-------------------------- start page mgt-----------------------------------------------------------------------//

    //-------------------------- start userrole mgt-------------------------------------------------------------------//
    public static final String USERROLE_MGT_EMPTY_USERROLECODE = "userrole.empty.userrolecode";
    public static final String USERROLE_MGT_EMPTY_DESCRIPTION = "userrole.empty.description";
    public static final String USERROLE_MGT_EMPTY_USERROLETYPE = "userrole.empty.userroletype";
    public static final String USERROLE_MGT_EMPTY_STATUS = "userrole.empty.status";
    public static final String USERROLE_MGT_SUCCESS_ADD = "userrole.success.add";
    public static final String USERROLE_MGT_ALREADY_EXISTS = "userrole.already.exists";
    public static final String USERROLE_MGT_ERROR_ADD = "userrole.error.add";
    public static final String USERROLE_MGT_SUCCESS_UPDATE = "userrole.success.update";
    public static final String USERROLE_MGT_ERROR_UPDATE = "userrole.success.update";
    public static final String USERROLE_MGT_SUCCESS_DELETE = "userrole.success.delete";
    public static final String USERROLE_MGT_ERROR_DELETE = "userrole.success.delete";
    public static final String USERROLE_MGT_EMPTY_PAGE = "userrole.empty.page";
    public static final String USERROLE_MGT_ASSIGNED_PAGE = "userrole.assigned.page";
    public static final String USERROLE_MGT_ERROR_UNASSIGNED_PAGE_TASK = "userrole.error.unassigned.page.task";
    public static final String USERROLE_MGT_ERROR_UNASSIGNED_PAGE = "userrole.error.unassigned.page";
    public static final String USERROLE_MGT_ERROR_ASSIGNED_PAGE = "userrole.error.assigned.page";
    public static final String USERROLE_MGT_SUCCESS_ASSIGNED_PAGE = "userrole.success.assigned.page";
    public static final String USERROLE_MGT_SUCCESS_CONFIRM = "userrole.success.confirm";
    public static final String USERROLE_MGT_SUCCESS_REJECT = "userrole.success.reject";
    public static final String USERROLE_MGT_SUCCESS_ASSIGNED_TASK = "userrole.success.assigned.task";
    public static final String USERROLE_MGT_EMPTY_TASK = "userrole.empty.task";
    public static final String USERROLE_MGT_ASSIGNED_TASK = "userrole.assigned.task";
    public static final String USERROLE_MGT_ERROR_UNASSIGNED_TASK = "userrole.error.unassigned.task";
    public static final String USERROLE_MGT_ERROR_ASSIGNED_TASK = "userrole.error.assigned.task";
    //-------------------------- start userrole mgt-------------------------------------------------------------------//

    //-------------------------- password param mgt-------------------------------------------------------------------//
    public static final String PASSWORD_PARAM_MGT_EMPTY_PASSWORDPARAM = "passwordparam.empty.passwordparam";
    public static final String PASSWORD_PARAM_MGT_EMPTY_USERROLETYPE = "passwordparam.empty.userroletype";
    public static final String PASSWORD_PARAM_MGT_EMPTY_VALUE = "passwordparam.empty.value";
    public static final String PASSWORD_PARAM_MGT_SUCCESS_UPDATE = "passwordparam.success.update";
    public static final String PASSWORD_PARAM_MGT_SUCCESS_CONFIRM = "passwordparam.success.confirm";
    public static final String PASSWORD_PARAM_MGT_SUCCESS_REJECT = "passwordparam.success.reject";
    public static final String PASSWORD_PARAM_MGT_ALREADY_EXISTS = "passwordparam.already.exists";
    //-------------------------- password param mgt-------------------------------------------------------------------//

    //-------------------------- password policy mgt------------------------------------------------------------------//
    public static final String PASSWORD_POLICY_MGT_EMPTY_PASSWORDPOLICYID = "passwordpolicy.empty.passwordPolicyId";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LENGTH = "passwordpolicy.empty.minimumLength";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MAXIMUM_LENGTH = "passwordpolicy.empty.maximumLength";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MINIMUM_SPECIAL_CHARACTERS = "passwordpolicy.empty.minimumSpecialCharacters";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MINIMUM_UPPERCASE_CHARACTERS = "passwordpolicy.empty.minimumUpperCaseCharacters";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MINIMUM_NUMERICAL_CHARACTERS = "passwordpolicy.empty.minimumNumericalCharacters";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MINIMUM_LOWERCASE_CHARACTERS = "passwordpolicy.empty.minimumLowerCaseCharacters";
    public static final String PASSWORD_POLICY_MGT_EMPTY_INVALID_LOGIN_ATTEMPTS = "passwordpolicy.empty.noOfInvalidLoginAttempt";
    public static final String PASSWORD_POLICY_MGT_EMPTY_REPEAT_CHARACTER_ALLOW = "passwordpolicy.empty.repeatCharactersAllow";
    public static final String PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_STATUS = "passwordpolicy.empty.initialPasswordExpiryStatus";
    public static final String PASSWORD_POLICY_MGT_EMPTY_PASSWORD_EXPIRY_PERIOD = "passwordpolicy.empty.passwordExpiryPeriod";
    public static final String PASSWORD_POLICY_MGT_EMPTY_NO_OF_HISTORY_PASSWORD = "passwordpolicy.empty.noOfHistoryPassword";
    public static final String PASSWORD_POLICY_MGT_EMPTY_MIN_PASSWORD_CHANGE_PERIOD = "passwordpolicy.empty.minimumPasswordChangePeriod";
    public static final String PASSWORD_POLICY_MGT_EMPTY_IDLE_ACCOUNT_EXPIRY_PERIOD = "passwordpolicy.empty.idleAccountExpiryPeriod";
    public static final String PASSWORD_POLICY_MGT_EMPTY_DESCRIPTION = "passwordpolicy.empty.description";
    public static final String PASSWORD_POLICY_MGT_EMPTY_VALUE = "passwordpolicy.empty.value";
    public static final String PASSWORD_POLICY_MGT_SUCCESS_UPDATE = "passwordpolicy.success.update";
    public static final String PASSWORD_POLICY_MGT_SUCCESS_CONFIRM = "passwordpolicy.success.confirm";
    public static final String PASSWORD_POLICY_MGT_SUCCESS_REJECT = "passwordpolicy.success.reject";
    public static final String PASSWORD_POLICY_MGT_ALREADY_EXISTS = "passwordpolicy.already.exists";
    //-------------------------- password policy mgt------------------------------------------------------------------//

    //-------------------------- system user mgt----------------------------------------------------------------------//
    public static final String SYSTEMUSER_MGT_EMPTY_USERNAME = "systemuser.empty.username";
    public static final String SYSTEMUSER_MGT_EMPTY_FULLNAME = "systemuser.empty.fullname";
    public static final String SYSTEMUSER_MGT_EMPTY_EMAIL = "systemuser.empty.email";
    public static final String SYSTEMUSER_MGT_EMPTY_USERROLECODE = "systemuser.empty.userrolecode";
    public static final String SYSTEMUSER_MGT_EMPTY_STATUS = "systemuser.empty.status";
    public static final String SYSTEMUSER_MGT_EMPTY_MOBILENUMBER = "systemuser.empty.mobilenumber";
    public static final String SYSTEMUSER_MGT_EMPTY_PASSWORD = "systemuser.empty.password";
    public static final String SYSTEMUSER_MGT_EMPTY_CONFIRMPASSWORD = "systemuser.empty.confirmpassword";
    public static final String SYSTEMUSER_MGT_PASSWORDS_MISMATCH = "systemuser.password.mismatch";
    public static final String SYSTEMUSER_MGT_ADDED_SUCCESSFULLY = "systemuser.added.success";
    public static final String SYSTEMUSER_MGT_UPDATE_SUCCESSFULLY = "systemuser.updated.success";
    public static final String SYSTEMUSER_MGT_DELETE_SUCCESSFULLY = "systemuser.delete.success";
    public static final String SYSTEMUSER_MGT_CONFIRM_SUCCESSFULLY = "systemuser.confirm.success";
    public static final String SYSTEMUSER_MGT_REJECT_SUCCESSFULLY = "systemuser.reject.success";
    public static final String SYSTEMUSER_MGT_ALREADY_EXISTS = "systemuser.already.exists";
    public static final String SYSTEMUSER_MGT_NORECORD_FOUND = "systemuser.norecord.found";
    //-------------------------- system user mgt----------------------------------------------------------------------//

    //-------------------------- department mgt-----------------------------------------------------------------------//
    public static final String DEPARTMENT_MGT_ADDED_SUCCESSFULLY = "department.added.success";
    public static final String DEPARTMENT_MGT_UPDATE_SUCCESSFULLY = "department.updated.success";
    public static final String DEPARTMENT_MGT_DELETE_SUCCESSFULLY = "department.deleted.success";
    public static final String DEPARTMENT_MGT_CONFIRM_SUCCESSFULLY = "department.confirm.success";
    public static final String DEPARTMENT_MGT_REJECT_SUCCESSFULLY = "department.reject.success";
    public static final String DEPARTMENT_MGT_ALREADY_EXISTS = "department.already.exists";
    public static final String DEPARTMENT_MGT_NORECORD_FOUND = "department.norecord.found";
    //-------------------------- department mgt-----------------------------------------------------------------------//

    //-------------------------- category mgt-------------------------------------------------------------------------//
    public static final String CATEGORY_MGT_ADDED_SUCCESSFULLY = "category.added.success";
    public static final String CATEGORY_MGT_UPDATE_SUCCESSFULLY = "category.updated.success";
    public static final String CATEGORY_MGT_DELETE_SUCCESSFULLY = "category.deleted.success";
    public static final String CATEGORY_MGT_CONFIRM_SUCCESSFULLY = "category.confirm.success";
    public static final String CATEGORY_MGT_REJECT_SUCCESSFULLY = "category.reject.success";
    public static final String CATEGORY_MGT_ALREADY_EXISTS = "category.already.exists";
    public static final String CATEGORY_MGT_NORECORD_FOUND = "category.norecord.found";
    //-------------------------- category mgt-------------------------------------------------------------------------//

    //-------------------------- smpp configuration mgt---------------------------------------------------------------//
    public static final String SMPP_CONFIGURATION_MGT_ADDED_SUCCESSFULLY = "smppconfiguration.added.success";
    public static final String SMPP_CONFIGURATION_MGT_UPDATE_SUCCESSFULLY = "smppconfiguration.updated.success";
    public static final String SMPP_CONFIGURATION_MGT_DELETE_SUCCESSFULLY = "smppconfiguration.deleted.success";
    public static final String SMPP_CONFIGURATION_MGT_CONFIRM_SUCCESSFULLY = "smppconfiguration.confirm.success";
    public static final String SMPP_CONFIGURATION_MGT_REJECT_SUCCESSFULLY = "smppconfiguration.reject.success";
    public static final String SMPP_CONFIGURATION_MGT_ALREADY_EXISTS = "smppconfiguration.already.exists";
    public static final String SMPP_CONFIGURATION_MGT_NORECORD_FOUND = "smppconfiguration.norecord.found";
    //-------------------------- smpp configuration mgt---------------------------------------------------------------//
}

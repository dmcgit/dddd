package com.epic.pb.service.usermgt.page;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.page.PageInputBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.usermgt.Page;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.usermgt.page.PageRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Scope("prototype")
public class PageService {

    @Autowired
    PageRepository pageRepository;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    private final String fields = "Page Code|Description|Url|Sort Key|Actual Flag|Current Flag|Status|Created Time|Last Updated Time|Last Updated User";

    public long getDataCount(PageInputBean inputBean) throws Exception {
        long count = 0;
        try {
            count = pageRepository.getDataCount(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<PageInputBean> getPageSearchResults(PageInputBean inputBean) throws Exception {
        List<PageInputBean> pageList;
        try {
            pageList = pageRepository.getPageSearchResults(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return pageList;
    }

    public long getDataCountDual(PageInputBean inputBean) throws Exception {
        long count = 0;
        try {
            count = pageRepository.getDataCountDual(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getPageSearchResultsDual(PageInputBean inputBean) throws Exception {
        List<TempAuthRecBean> taskDualList;
        try {
            taskDualList = pageRepository.getPageSearchResultsDual(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return taskDualList;
    }

    public Page getPage(String pageCode) throws Exception {
        Page page;
        try {
            page = pageRepository.getPage(pageCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return page;
    }

    public String updatePage(Page page) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.PAGE_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        try {
            //set page data
            page.setCreatedTime(commonRepository.getCurrentDate());
            page.setLastUpdatedTime(commonRepository.getCurrentDate());
            page.setLastUpdatedUser(sessionBean.getUsername());
            //check record exist and get old values
            Page pageOldBean = this.getPage(page.getPageCode());
            if (pageOldBean != null) {
                page.setActualFalg(pageOldBean.isActualFalg());
                //check changed values
                String oldValueCheck = this.getPageAsString(pageOldBean, true);
                String newValueCheck = this.getPageAsString(page, true);

                if (oldValueCheck.equals(newValueCheck)) {
                    message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
                } else if (pageRepository.checkSortKeyExist(pageOldBean.getPageCode(), page.getSortKey())) {
                    message = MessageVarList.PAGE_MGT_SORTKEY_EXIST;
                } else {
                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.PAGE_MGT_PAGE)) {
                        audit.setDescription("Requested to update page (page code: " + page.getPageCode().trim().toUpperCase() + ") by " + sessionBean.getUsername());
                        message = this.insertDualAuthRecord(page, TaskVarList.UPDATE_TASK);
                    } else {
                        audit.setDescription("Page (page code: " + page.getPageCode().trim().toUpperCase() + ") updated by " + sessionBean.getUsername());
                        message = pageRepository.updatePage(page);
                    }
                    //create audit record
                    if (message.isEmpty()) {
                        audit.setField(fields);
                        audit.setNewvalue(this.getPageAsString(page, false));
                        audit.setOldvalue(this.getPageAsString(pageOldBean, false));
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    }
                }
            } else {
                message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String insertDualAuthRecord(Page page, String pageCode) throws Exception {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();
        String message = "";
        long count = 0;
        try {
            count = commonRepository.getTempAuthRecordCount(page.getPageCode().trim(), PageVarList.PAGE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN);
            if (count > 0) {
                message = MessageVarList.TMP_RECORD_ALREADY_EXISTS;
            } else if (pageRepository.checkTempSortKeyExist(page.getSortKey())) {
                message = MessageVarList.PAGE_MGT_SORTKEY_TEMP_EXIST;
            } else {
                tempAuthRecBean.setPage(PageVarList.PAGE_MGT_PAGE);
                tempAuthRecBean.setTask(pageCode);
                tempAuthRecBean.setKey1(page.getPageCode().trim().toUpperCase());
                tempAuthRecBean.setKey2(page.getDescription().trim());
                tempAuthRecBean.setKey3(page.getUrl().trim());
                tempAuthRecBean.setKey4(String.valueOf(page.getSortKey()));
                tempAuthRecBean.setKey5(String.valueOf(page.isActualFalg()));
                tempAuthRecBean.setKey6(String.valueOf(page.isCurrentFlag()));
                tempAuthRecBean.setKey7(page.getStatusCode().trim());
                //insert dual auth record
                message = commonRepository.insertDualAuthRecordSQL(tempAuthRecBean);
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String confirmPage(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.PAGE_MGT_PAGE, TaskVarList.DUAL_AUTH_CONFIRM_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                Page page = new Page();
                page.setPageCode(tempAuthRecBean.getKey1());
                page.setDescription(tempAuthRecBean.getKey2());
                page.setUrl(tempAuthRecBean.getKey3());
                page.setSortKey(Integer.parseInt(tempAuthRecBean.getKey4()));
                page.setActualFalg(new Boolean(tempAuthRecBean.getKey5()));
                page.setCurrentFlag(new Boolean(tempAuthRecBean.getKey6()));
                page.setStatusCode(tempAuthRecBean.getKey7());
                page.setCreatedTime(commonRepository.getCurrentDate());
                page.setLastUpdatedTime(commonRepository.getCurrentDate());
                page.setLastUpdatedUser(sessionBean.getUsername());

                //check taskcode is already exist or not
                Page existingPage = null;
                try {
                    existingPage = pageRepository.getPage(page.getPageCode().trim());
                } catch (EmptyResultDataAccessException ex) {
                    existingPage = null;
                }

                if (TaskVarList.UPDATE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingPage == null) {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    } else if (pageRepository.checkSortKeyExist(tempAuthRecBean.getKey1(), Integer.parseInt(tempAuthRecBean.getKey4()))) {
                        message = MessageVarList.PAGE_MGT_SORTKEY_EXIST;
                    } else {
                        message = pageRepository.updatePage(page);
                    }
                }

                //if page db operation sucess, update temp auth record
                if (message.isEmpty()) {
                    message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_CON);

                    //if tempauth db operation success,insert the audit
                    if (message.isEmpty()) {
                        //create audit record
                        audit.setField(fields);
                        audit.setNewvalue(this.getPageAsString(page, false));
                        audit.setOldvalue(this.getPageAsString(existingPage, false));
                        //create audit description
                        StringBuilder auditDesBuilder = new StringBuilder();
                        auditDesBuilder.append("Approved performing  '").append(tempAuthRecBean.getTask())
                                .append("' operation on page (page code: ").append(page.getPageCode())
                                .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" approved by ")
                                .append(sessionBean.getUsername());
                        audit.setDescription(auditDesBuilder.toString());
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    } else {
                        message = MessageVarList.COMMON_ERROR_PROCESS;
                    }
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }


    public String rejectPage(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.PAGE_MGT_PAGE, TaskVarList.DUAL_AUTH_REJECT_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_REJ);

                //if tempauth db operation success,insert the audit
                if (message.isEmpty()) {
                    //create audit description
                    StringBuilder auditDesBuilder = new StringBuilder();
                    auditDesBuilder.append("Rejected performing  '").append(tempAuthRecBean.getTask())
                            .append("' operation on page (page code: ").append(tempAuthRecBean.getKey1())
                            .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" rejected by ")
                            .append(sessionBean.getUsername());
                    audit.setDescription(auditDesBuilder.toString());
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }

            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }


    private String getPageAsString(Page page, boolean checkChanges) {
        StringBuilder taskStringBuilder = new StringBuilder();

        if (page != null) {
            if (page.getPageCode() != null) {
                taskStringBuilder.append(page.getPageCode());
            } else {
                taskStringBuilder.append("error");
            }

            taskStringBuilder.append("|");
            if (page.getDescription() != null) {
                taskStringBuilder.append(page.getDescription());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (page.getUrl() != null) {
                taskStringBuilder.append(page.getUrl());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (String.valueOf(page.getSortKey()) != null) {
                taskStringBuilder.append(String.valueOf(page.getSortKey()));
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (String.valueOf(page.isActualFalg()) != null) {
                taskStringBuilder.append(page.isActualFalg());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (String.valueOf(page.isCurrentFlag()) != null) {
                taskStringBuilder.append(page.isCurrentFlag());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (page.getStatusCode() != null) {
                taskStringBuilder.append(page.getStatusCode());
            } else {
                taskStringBuilder.append("--");
            }

            if (!checkChanges) {
                taskStringBuilder.append("|");
                if (page.getCreatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(page.getCreatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (page.getLastUpdatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(page.getLastUpdatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (page.getLastUpdatedUser() != null) {
                    taskStringBuilder.append(page.getLastUpdatedUser());
                } else {
                    taskStringBuilder.append("--");
                }
            }
        }
        return taskStringBuilder.toString();
    }

}

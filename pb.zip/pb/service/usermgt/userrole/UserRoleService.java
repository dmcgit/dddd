package com.epic.pb.service.usermgt.userrole;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.userrole.UserRoleInputBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.usermgt.Page;
import com.epic.pb.mapping.usermgt.Section;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.mapping.usermgt.UserRole;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.usermgt.userrole.UserRoleRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Repository
public class UserRoleService {

    @Autowired
    UserRoleRepository userRoleRepository;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    private final String fields = "Userrole Code|Description|Userrole Type|Status|Created Time|Last Updated Time|Last Updated User";

    public long getDataCount(UserRoleInputBean inputBean) throws Exception {
        long count = 0;
        try {
            count = userRoleRepository.getDataCount(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<UserRoleInputBean> getUserRoleSearchResults(UserRoleInputBean inputBean) throws Exception {
        List<UserRoleInputBean> pageList;
        try {
            pageList = userRoleRepository.getUserRoleSearchResults(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return pageList;
    }

    public long getDataCountDual(UserRoleInputBean inputBean) throws Exception {
        long count = 0;
        try {
            count = userRoleRepository.getDataCountDual(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getUserRoleSearchResultsDual(UserRoleInputBean inputBean) throws Exception {
        List<TempAuthRecBean> taskDualList;
        try {
            taskDualList = userRoleRepository.getUserRoleSearchResultsDual(inputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return taskDualList;
    }

    public String insertUserRole(UserRole userRole) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.ADD_TASK);
        String message = "";
        try {
            //check user role code is already exist or not
            UserRole existingUserRole = null;
            try {
                existingUserRole = userRoleRepository.getUserRole(userRole.getUserroleCode().trim());
            } catch (EmptyResultDataAccessException ex) {
                existingUserRole = null;
            }

            if (existingUserRole == null) {
                //set userrole data
                userRole.setCreatedTime(commonRepository.getCurrentDate());
                userRole.setLastUpdatedTime(commonRepository.getCurrentDate());
                userRole.setLastUpdatedUser(sessionBean.getUsername());

                if (commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE)) {
                    audit.setDescription("Requested to add userrole (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                    message = this.insertDualAuthRecord(userRole, TaskVarList.ADD_TASK);
                } else {
                    audit.setDescription("Userrole (userrole code: " + userRole.getUserroleCode() + ") added by " + sessionBean.getUsername());
                    message = userRoleRepository.insertUserRole(userRole);
                }
                //create audit record
                if (message.isEmpty()) {
                    audit.setField(fields);
                    audit.setNewvalue(this.getUserRoleAsString(userRole, false));
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                }

            } else {
                message = MessageVarList.USERROLE_MGT_ALREADY_EXISTS;
            }
        } catch (DuplicateKeyException ex) {
            message = MessageVarList.USERROLE_MGT_ALREADY_EXISTS;
        } catch (NumberFormatException | DataAccessException ex) {
            throw ex;
        }
        return message;
    }

    public UserRole getUserRole(String userroleCode) throws Exception {
        UserRole userRole;
        try {
            userRole = userRoleRepository.getUserRole(userroleCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return userRole;
    }

    public String updateUserRole(UserRole userRole) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        try {
            //set userrole data
            userRole.setCreatedTime(commonRepository.getCurrentDate());
            userRole.setLastUpdatedTime(commonRepository.getCurrentDate());
            userRole.setLastUpdatedUser(sessionBean.getUsername());
            //check record exist and get old values
            UserRole taskOldBean = this.getUserRole(userRole.getUserroleCode());
            if (taskOldBean != null) {
                //check changed values
                String oldValueCheck = this.getUserRoleAsString(taskOldBean, true);
                String newValueCheck = this.getUserRoleAsString(userRole, true);

                if (oldValueCheck.equals(newValueCheck)) {
                    message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
                } else {
                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE)) {
                        audit.setDescription("Requested to update userrole (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                        message = this.insertDualAuthRecord(userRole, TaskVarList.UPDATE_TASK);
                    } else {
                        audit.setDescription("Userrole (userrole code: " + userRole.getUserroleCode().trim() + ") updated by " + sessionBean.getUsername());
                        message = userRoleRepository.updateUserRole(userRole);
                    }
                    //create audit record
                    if (message.isEmpty()) {
                        audit.setField(fields);
                        audit.setNewvalue(this.getUserRoleAsString(userRole, false));
                        audit.setOldvalue(this.getUserRoleAsString(taskOldBean, false));
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    }
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String deleteUserRole(String userroleCode) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        UserRole userRole;
        try {
            if (commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE)) {
                audit.setDescription("Requested to delete userrole (userrole code: " + userroleCode.trim() + ") by " + sessionBean.getUsername());
                userRole = userRoleRepository.getUserRole(userroleCode);
                message = this.insertDualAuthRecord(userRole, TaskVarList.DELETE_TASK);
            } else {
                audit.setDescription("Userrole (userrole code: " + userroleCode.trim() + ") deleted by " + sessionBean.getUsername());
                message = userRoleRepository.deleteUserRole(userroleCode);

            }
            //set audit to session bean
            if (message.isEmpty()) {
                sessionBean.setAudittrace(audit);
            }
        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }

    public List<Section> getAllSection() throws Exception {
        List<Section> sectionList;
        try {
            sectionList = userRoleRepository.getAllSection();
        } catch (DataAccessException ex) {
            throw ex;
        }
        return sectionList;
    }

    public List<Page> getAssignedPages(String userroleCode, String sectionCode) throws Exception {
        List<Page> assignedPageList;
        try {
            assignedPageList = userRoleRepository.getAssignedPages(userroleCode, sectionCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return assignedPageList;
    }

    public List<Page> getUnAssignedPages(String userroleCode) throws Exception {
        List<Page> unAssignPageList = new ArrayList<>();
        try {
            List<Page> allPageList = userRoleRepository.getAllPages();
            List<String> assignedUserrolePageList = userRoleRepository.getAssignedPagesForUserrole(userroleCode);

            for (Page page : allPageList) {
                if (!assignedUserrolePageList.contains(page.getPageCode())) {
                    unAssignPageList.add(page);
                }
            }

        } catch (DataAccessException ex) {
            throw ex;
        }
        return unAssignPageList;
    }

    public String assignPages(UserRoleInputBean inputBean) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.ASSIGN_PAGE);
        String message = "";
        try {
            UserRole userRole = this.getUserRole(inputBean.getUserroleCode());

            if (userRole != null) {
                List<String> assignedPages = inputBean.getAssignedPages();
                List<String> alreadyAssignedList = userRoleRepository.getAssignedPageCodes(inputBean.getUserroleCode(), inputBean.getSection());

                if (assignedPages.size() == 0 && alreadyAssignedList.size() == 0) {
                    message = MessageVarList.USERROLE_MGT_EMPTY_PAGE;
                } else if (assignedPages.size() > 0 && alreadyAssignedList.size() > 0 && assignedPages.equals(alreadyAssignedList)) {
                    message = MessageVarList.USERROLE_MGT_ASSIGNED_PAGE;
                } else {
                    userRole.setSection(inputBean.getSection());
                    userRole.setLastUpdatedTime(commonRepository.getCurrentDate());
                    userRole.setLastUpdatedUser(sessionBean.getUsername());

                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE)) {
                        audit.setDescription("Requested to assign page to User role (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                        userRole.setAssignedList(assignedPages);
                        message = this.insertDualAuthRecord(userRole, TaskVarList.ASSIGN_PAGE);
                    } else {
                        List<String> unAssignedPages = new ArrayList<>();

                        for (String pageCode : alreadyAssignedList) {
                            if (assignedPages.contains(pageCode)) {
                                assignedPages.remove(pageCode);
                            } else {
                                unAssignedPages.add(pageCode);
                            }
                        }

                        audit.setDescription("Assign page to User role (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                        userRole.setAssignedList(assignedPages);
                        userRole.setUnAssignedList(unAssignedPages);
                        message = userRoleRepository.assignPages(userRole);
                    }

                    if (message.isEmpty()) {
                        sessionBean.setAudittrace(audit);
                    }
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public List<Section> getAssignedSection(String userroleCode) throws Exception {
        List<Section> sectionList;
        try {
            sectionList = userRoleRepository.getAssignedSection(userroleCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return sectionList;
    }

    public List<Task> getAssignedTasks(String userroleCode, String pageCode) throws Exception {
        List<Task> assignTaskList;
        try {
            assignTaskList = userRoleRepository.getAssignedTasks(userroleCode, pageCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return assignTaskList;
    }

    public List<Task> getUnAssignedTasks(String userroleCode, String pageCode) throws Exception {
        List<Task> unAssignTaskList = new ArrayList<>();
        try {
            List<Task> allPageTaskList = userRoleRepository.getAllPageTasks(pageCode);
            List<String> assignedUserroleTaskList = userRoleRepository.getAssignedTasksForUserrole(userroleCode, pageCode);

            for (Task task : allPageTaskList) {
                if (!assignedUserroleTaskList.contains(task.getTaskCode())) {
                    unAssignTaskList.add(task);
                }
            }

        } catch (DataAccessException ex) {
            throw ex;
        }
        return unAssignTaskList;
    }

    public String assignTasks(UserRoleInputBean inputBean) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.ASSIGN_TASK);
        String message = "";
        try {
            UserRole userRole = this.getUserRole(inputBean.getUserroleCode());

            if (userRole != null) {
                List<String> assignedTasks = inputBean.getAssignedTasks();
                List<String> alreadyAssignedList = userRoleRepository.getAssignedTaskCodes(inputBean.getUserroleCode(), inputBean.getPage());

                if (assignedTasks.size() == 0 && alreadyAssignedList.size() == 0) {
                    message = MessageVarList.USERROLE_MGT_EMPTY_TASK;
                } else if (assignedTasks.size() > 0 && alreadyAssignedList.size() > 0 && assignedTasks.equals(alreadyAssignedList)) {
                    message = MessageVarList.USERROLE_MGT_ASSIGNED_TASK;
                } else {
                    userRole.setSection(inputBean.getSection());
                    userRole.setPage(inputBean.getPage());
                    userRole.setLastUpdatedTime(commonRepository.getCurrentDate());
                    userRole.setLastUpdatedUser(sessionBean.getUsername());

                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.USERROLE_MGT_PAGE)) {
                        audit.setDescription("Requested to assign task to User role (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                        userRole.setAssignedList(assignedTasks);
                        message = this.insertDualAuthRecord(userRole, TaskVarList.ASSIGN_TASK);
                    } else {
                        List<String> unAssignedTasks = new ArrayList<>();

                        for (String taskCode : alreadyAssignedList) {
                            if (assignedTasks.contains(taskCode)) {
                                assignedTasks.remove(taskCode);
                            } else {
                                unAssignedTasks.add(taskCode);
                            }
                        }

                        audit.setDescription("Assign task to User role (userrole code: " + userRole.getUserroleCode().trim() + ") by " + sessionBean.getUsername());
                        userRole.setAssignedList(assignedTasks);
                        userRole.setUnAssignedList(unAssignedTasks);
                        if (message.isEmpty()) {
                            message = userRoleRepository.assignTasks(userRole);
                        }
                    }

                    sessionBean.setAudittrace(audit);
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String insertDualAuthRecord(UserRole userRole, String taskCode) throws Exception {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();
        String message = "";
        long count = 0;
        try {
            count = commonRepository.getTempAuthRecordCount(userRole.getUserroleCode().trim(), PageVarList.USERROLE_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN);
            if (count > 0) {
                message = MessageVarList.TMP_RECORD_ALREADY_EXISTS;
            } else {
                tempAuthRecBean.setPage(PageVarList.USERROLE_MGT_PAGE);
                tempAuthRecBean.setTask(taskCode);
                tempAuthRecBean.setKey1(userRole.getUserroleCode().trim());
                tempAuthRecBean.setKey2(userRole.getDescription().trim());
                tempAuthRecBean.setKey3(userRole.getUserroleType().trim());
                tempAuthRecBean.setKey4(userRole.getStatus().trim());
                //insert dual auth record
                if (taskCode.equalsIgnoreCase(TaskVarList.ASSIGN_PAGE)) {
                    tempAuthRecBean.setKey5(userRole.getSection().trim());
                    tempAuthRecBean.setTmpRecord(userRole.getAssignedList().toString().replace("[", "").replace("]", ""));
                } else if (taskCode.equalsIgnoreCase(TaskVarList.ASSIGN_TASK)) {
                    tempAuthRecBean.setKey5(userRole.getSection().trim());
                    tempAuthRecBean.setKey6(userRole.getPage().trim());
                    tempAuthRecBean.setTmpRecord(userRole.getAssignedList().toString().replace("[", "").replace("]", ""));
                }
                message = commonRepository.insertDualAuthRecordSQL(tempAuthRecBean);
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String confirmUserRole(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.DUAL_AUTH_CONFIRM_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                UserRole userRole = new UserRole();
                userRole.setUserroleCode(tempAuthRecBean.getKey1());
                userRole.setDescription(tempAuthRecBean.getKey2());
                userRole.setUserroleType(tempAuthRecBean.getKey3());
                userRole.setStatus(tempAuthRecBean.getKey4());
                userRole.setCreatedTime(commonRepository.getCurrentDate());
                userRole.setLastUpdatedTime(commonRepository.getCurrentDate());
                userRole.setLastUpdatedUser(sessionBean.getUsername());

                //check taskcode is already exist or not
                UserRole existingUserRole = null;
                try {
                    existingUserRole = userRoleRepository.getUserRole(userRole.getUserroleCode().trim());
                } catch (EmptyResultDataAccessException ex) {
                    existingUserRole = null;
                }

                if (TaskVarList.ADD_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingUserRole == null) {
                        message = userRoleRepository.insertUserRole(userRole);
                    } else {
                        message = MessageVarList.USERROLE_MGT_ALREADY_EXISTS;
                    }
                } else if (TaskVarList.UPDATE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingUserRole != null) {
                        message = userRoleRepository.updateUserRole(userRole);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                } else if (TaskVarList.DELETE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingUserRole != null) {
                        message = userRoleRepository.deleteUserRole(userRole.getUserroleCode());
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                } else if (TaskVarList.ASSIGN_PAGE.equals(tempAuthRecBean.getTask())) {
                    if (existingUserRole != null) {
                        List<String> assignedPages = new ArrayList<>();
                        if (tempAuthRecBean.getTmpRecord() != null && !tempAuthRecBean.getTmpRecord().isEmpty()) {
                            assignedPages = new ArrayList<>(Arrays.asList(tempAuthRecBean.getTmpRecord().replaceAll(" ", "").split(",")));
                        }

                        List<String> alreadyAssignedList = userRoleRepository.getAssignedPageCodes(tempAuthRecBean.getKey1().trim(), tempAuthRecBean.getKey5().trim());
                        List<String> unAssignedPages = new ArrayList<>();

                        for (String pageCode : alreadyAssignedList) {
                            if (assignedPages.contains(pageCode)) {
                                assignedPages.remove(pageCode);
                            } else {
                                unAssignedPages.add(pageCode);
                            }
                        }

                        userRole.setSection(tempAuthRecBean.getKey5());
                        userRole.setAssignedList(assignedPages);
                        userRole.setUnAssignedList(unAssignedPages);
                        message = userRoleRepository.assignPages(userRole);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                } else if (TaskVarList.ASSIGN_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingUserRole != null) {
                        List<String> assignedTasks = new ArrayList<>();
                        if (tempAuthRecBean.getTmpRecord() != null && !tempAuthRecBean.getTmpRecord().isEmpty()) {
                            assignedTasks = new ArrayList<>(Arrays.asList(tempAuthRecBean.getTmpRecord().replaceAll(" ", "").split(",")));
                        }

                        List<String> alreadyAssignedList = userRoleRepository.getAssignedTaskCodes(tempAuthRecBean.getKey1().trim(), tempAuthRecBean.getKey6().trim());
                        List<String> unAssignedTasks = new ArrayList<>();

                        for (String taskCode : alreadyAssignedList) {
                            if (assignedTasks.contains(taskCode)) {
                                assignedTasks.remove(taskCode);
                            } else {
                                unAssignedTasks.add(taskCode);
                            }
                        }

                        userRole.setSection(tempAuthRecBean.getKey5());
                        userRole.setPage(tempAuthRecBean.getKey6());
                        userRole.setAssignedList(assignedTasks);
                        userRole.setUnAssignedList(unAssignedTasks);
                        message = userRoleRepository.assignTasks(userRole);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                }

                //if + db operation sucess, update temp auth record
                if (message.isEmpty()) {
                    message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_CON);

                    //if tempauth db operation success,insert the audit
                    if (message.isEmpty()) {
                        //create audit record
                        audit.setField(fields);
                        audit.setNewvalue(this.getUserRoleAsString(userRole, false));
                        audit.setOldvalue(this.getUserRoleAsString(existingUserRole, false));
                        //create audit description
                        StringBuilder auditDesBuilder = new StringBuilder();
                        auditDesBuilder.append("Approved performing  '").append(tempAuthRecBean.getTask())
                                .append("' operation on userrole (userrole code: ").append(userRole.getUserroleCode())
                                .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" approved by ")
                                .append(sessionBean.getUsername());
                        audit.setDescription(auditDesBuilder.toString());
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    } else {
                        message = MessageVarList.COMMON_ERROR_PROCESS;
                    }
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }


    public String rejectUserRole(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.USERROLE_MGT_PAGE, TaskVarList.DUAL_AUTH_REJECT_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_REJ);

                //if tempauth db operation success,insert the audit
                if (message.isEmpty()) {
                    //create audit description
                    StringBuilder auditDesBuilder = new StringBuilder();
                    auditDesBuilder.append("Rejected performing  '").append(tempAuthRecBean.getTask())
                            .append("' operation on userrole (userrole code: ").append(tempAuthRecBean.getKey1())
                            .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" rejected by ")
                            .append(sessionBean.getUsername());
                    audit.setDescription(auditDesBuilder.toString());
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }

            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }

    private String getUserRoleAsString(UserRole userRole, boolean checkChanges) {
        StringBuilder taskStringBuilder = new StringBuilder();

        if (userRole != null) {
            if (userRole.getUserroleCode() != null) {
                taskStringBuilder.append(userRole.getUserroleCode());
            } else {
                taskStringBuilder.append("error");
            }

            taskStringBuilder.append("|");
            if (userRole.getDescription() != null) {
                taskStringBuilder.append(userRole.getDescription());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (userRole.getUserroleType() != null) {
                taskStringBuilder.append(userRole.getUserroleType());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (userRole.getStatus() != null) {
                taskStringBuilder.append(userRole.getStatus());
            } else {
                taskStringBuilder.append("--");
            }

            if (!checkChanges) {
                taskStringBuilder.append("|");
                if (userRole.getCreatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(userRole.getCreatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (userRole.getLastUpdatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(userRole.getLastUpdatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (userRole.getLastUpdatedUser() != null) {
                    taskStringBuilder.append(userRole.getLastUpdatedUser());
                } else {
                    taskStringBuilder.append("--");
                }
            }
        }
        return taskStringBuilder.toString();
    }
}

package com.epic.pb.service.usermgt.task;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.usermgt.task.TaskInputBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.usermgt.Task;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.usermgt.task.TaskRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Scope("prototype")
public class TaskService {

    @Autowired
    TaskRepository taskRepository;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    private final String fields = "Task Code|Description|Status|Created Time|Last Updated Time|Last Updated User";

    public long getDataCount(TaskInputBean taskInputBean) throws Exception {
        long count = 0;
        try {
            count = taskRepository.getDataCount(taskInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<TaskInputBean> getTaskSearchResults(TaskInputBean taskInputBean) throws Exception {
        List<TaskInputBean> taskList;
        try {
            taskList = taskRepository.getTaskSearchResults(taskInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return taskList;
    }

    public long getDataCountDual(TaskInputBean taskInputBean) throws Exception {
        long count = 0;
        try {
            count = taskRepository.getDataCountDual(taskInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<TempAuthRecBean> getTaskSearchResultsDual(TaskInputBean taskInputBean) throws Exception {
        List<TempAuthRecBean> taskDualList;
        try {
            taskDualList = taskRepository.getTaskSearchResultsDual(taskInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return taskDualList;
    }

    public String insertTask(Task task) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.TASK_MGT_PAGE, TaskVarList.ADD_TASK);
        String message = "";
        try {
            //check task code is already exist or not
            Task existingTask = null;
            try {
                existingTask = taskRepository.getTask(task.getTaskCode().trim());
            } catch (EmptyResultDataAccessException ex) {
                existingTask = null;
            }

            if (existingTask == null) {
                //set task data
                task.setCreateTime(commonRepository.getCurrentDate());
                task.setLastUpdatedTime(commonRepository.getCurrentDate());
                task.setLastUpdatedUser(sessionBean.getUsername());

                if (commonRepository.checkPageIsDualAuthenticate(PageVarList.TASK_MGT_PAGE)) {
                    audit.setDescription("Requested to add task (task code: " + task.getTaskCode().trim().toUpperCase() + ") by " + sessionBean.getUsername());
                    message = this.insertDualAuthRecord(task, TaskVarList.ADD_TASK);
                } else {
                    audit.setDescription("Section (section code: " + task.getTaskCode().trim().toUpperCase() + ") added by " + sessionBean.getUsername());
                    message = taskRepository.insertTask(task);
                }
                //create audit record
                audit.setField(fields);
                audit.setNewvalue(this.getTaskAsString(task, false));
                //set audit to session bean
                sessionBean.setAudittrace(audit);
            } else {
                message = MessageVarList.TASK_MGT_ALREADY_EXISTS;
            }
        } catch (DuplicateKeyException ex) {
            message = MessageVarList.TASK_MGT_ALREADY_EXISTS;
        } catch (NumberFormatException | DataAccessException ex) {
            throw ex;
        }
        return message;
    }

    public String updateTask(Task task) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.TASK_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        try {
            //set task data
            task.setCreateTime(commonRepository.getCurrentDate());
            task.setLastUpdatedTime(commonRepository.getCurrentDate());
            task.setLastUpdatedUser(sessionBean.getUsername());
            //check record exist and get old values
            Task taskOldBean = this.getTask(task.getTaskCode());
            if (taskOldBean != null) {
                //check changed values
                String oldValueCheck = this.getTaskAsString(taskOldBean, true);
                String newValueCheck = this.getTaskAsString(task, true);

                if (oldValueCheck.equals(newValueCheck)) {
                    message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
                } else {
                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.TASK_MGT_PAGE)) {
                        audit.setDescription("Requested to update task (task code: " + task.getTaskCode().trim().toUpperCase() + ") by " + sessionBean.getUsername());
                        message = this.insertDualAuthRecord(task, TaskVarList.UPDATE_TASK);
                    } else {
                        audit.setDescription("Task (task code: " + task.getTaskCode().trim().toUpperCase() + ") updated by " + sessionBean.getUsername());
                        message = taskRepository.updateTask(task);
                    }
                    //create audit record
                    audit.setField(fields);
                    audit.setNewvalue(this.getTaskAsString(task, false));
                    audit.setOldvalue(this.getTaskAsString(taskOldBean, false));
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                }
            } else {
                message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }


    public Task getTask(String taskCode) throws Exception {
        Task task;
        try {
            task = taskRepository.getTask(taskCode);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return task;
    }

    public String deleteTask(String taskCode) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.TASK_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        Task task;
        try {
            if (commonRepository.checkPageIsDualAuthenticate(PageVarList.TASK_MGT_PAGE)) {
                audit.setDescription("Requested to deleted task (task code: " + taskCode.trim().toUpperCase() + ") by " + sessionBean.getUsername());
                task = taskRepository.getTask(taskCode);
                message = this.insertDualAuthRecord(task, TaskVarList.DELETE_TASK);
            } else {
                audit.setDescription("Task (task code: " + taskCode.trim().toUpperCase() + ") deleted by " + sessionBean.getUsername());
                message = taskRepository.deleteTask(taskCode);

            }
            //set audit to session bean
            sessionBean.setAudittrace(audit);
        } catch (DataAccessException e) {
            throw e;
        }
        return message;
    }


    public String insertDualAuthRecord(Task task, String taskCode) throws Exception {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();
        String message = "";
        long count = 0;
        try {
            count = commonRepository.getTempAuthRecordCount(task.getTaskCode().trim(), PageVarList.TASK_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN);
            if (count > 0) {
                message = MessageVarList.TMP_RECORD_ALREADY_EXISTS;
            } else {
                tempAuthRecBean.setPage(PageVarList.TASK_MGT_PAGE);
                tempAuthRecBean.setTask(taskCode);
                tempAuthRecBean.setKey1(task.getTaskCode().trim().toUpperCase());
                tempAuthRecBean.setKey2(task.getDescription().trim());
                tempAuthRecBean.setKey3(task.getStatus().trim());
                //insert dual auth record
                message = commonRepository.insertDualAuthRecordSQL(tempAuthRecBean);
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String confirmTask(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.TASK_MGT_PAGE, TaskVarList.DUAL_AUTH_CONFIRM_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                Task task = new Task();
                task.setTaskCode(tempAuthRecBean.getKey1());
                task.setDescription(tempAuthRecBean.getKey2());
                task.setStatus(tempAuthRecBean.getKey3());
                task.setCreateTime(commonRepository.getCurrentDate());
                task.setLastUpdatedTime(commonRepository.getCurrentDate());
                task.setLastUpdatedUser(sessionBean.getUsername());

                //check taskcode is already exist or not
                Task existingTask = null;
                try {
                    existingTask = taskRepository.getTask(task.getTaskCode().trim());
                } catch (EmptyResultDataAccessException ex) {
                    existingTask = null;
                }

                if (TaskVarList.ADD_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingTask == null) {
                        message = taskRepository.insertTask(task);
                    } else {
                        message = MessageVarList.TASK_MGT_ALREADY_EXISTS;
                    }
                } else if (TaskVarList.UPDATE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingTask != null) {
                        message = taskRepository.updateTask(task);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                } else if (TaskVarList.DELETE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingTask != null) {
                        message = taskRepository.deleteTask(task.getTaskCode().trim());
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                }

                //if task db operation sucess, update temp auth record
                if (message.isEmpty()) {
                    message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_CON);

                    //if tempauth db operation success,insert the audit
                    if (message.isEmpty()) {
                        //create audit record
                        audit.setField(fields);
                        audit.setNewvalue(this.getTaskAsString(task, false));
                        audit.setOldvalue(this.getTaskAsString(existingTask, false));
                        //create audit description
                        StringBuilder auditDesBuilder = new StringBuilder();
                        auditDesBuilder.append("Approved performing  '").append(tempAuthRecBean.getTask())
                                .append("' operation on task (task code: ").append(task.getTaskCode())
                                .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" approved by ")
                                .append(sessionBean.getUsername());
                        audit.setDescription(auditDesBuilder.toString());
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    } else {
                        message = MessageVarList.COMMON_ERROR_PROCESS;
                    }
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }

    public String rejectTask(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_USER_MGT, PageVarList.TASK_MGT_PAGE, TaskVarList.DUAL_AUTH_REJECT_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;

        try {

            tempAuthRecBean = commonRepository.getTempAuthRecord(id);

            if (tempAuthRecBean != null) {

                message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_REJ);

                //if tempauth db operation success,insert the audit
                if (message.isEmpty()) {
                    //create audit description
                    StringBuilder auditDesBuilder = new StringBuilder();
                    auditDesBuilder.append("Rejected performing  '").append(tempAuthRecBean.getTask())
                            .append("' operation on task (task code: ").append(tempAuthRecBean.getKey1())
                            .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" rejected by ")
                            .append(sessionBean.getUsername());
                    audit.setDescription(auditDesBuilder.toString());
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }

            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;

    }


    private String getTaskAsString(Task task, boolean checkChanges) {
        StringBuilder taskStringBuilder = new StringBuilder();

        if (task != null) {
            if (task.getTaskCode() != null) {
                taskStringBuilder.append(task.getTaskCode());
            } else {
                taskStringBuilder.append("error");
            }

            taskStringBuilder.append("|");
            if (task.getDescription() != null) {
                taskStringBuilder.append(task.getDescription());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (task.getStatus() != null) {
                taskStringBuilder.append(task.getStatus());
            } else {
                taskStringBuilder.append("--");
            }

            if (!checkChanges) {
                taskStringBuilder.append("|");
                if (task.getCreateTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(task.getCreateTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (task.getLastUpdatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(task.getLastUpdatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (task.getLastUpdatedUser() != null) {
                    taskStringBuilder.append(task.getLastUpdatedUser());
                } else {
                    taskStringBuilder.append("--");
                }
            }
        }
        return taskStringBuilder.toString();
    }
}

package com.epic.pb.service.reportmgt.smsoutbox;

import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.bean.smsoutbox.SmsOutboxReportInputBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.smsoutbox.SmsOutbox;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.reportmgt.smsoutbox.SmsOutboxRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.PageVarList;
import com.epic.pb.util.varlist.SectionVarList;
import com.epic.pb.util.varlist.TaskVarList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Scope("prototype")
public class SmsOutboxService {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    @Autowired
    SmsOutboxRepository smsOutboxRepository;

    @Autowired
    Audittrace audittrace;

    @Autowired
    MessageSource messageSource;

    public long getCount(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        long count = 0;
        try {
            count = smsOutboxRepository.getDataCount(smsOutboxReportInputBean);
        } catch (EmptyResultDataAccessException ere) {
            throw ere;
        } catch (Exception e) {
            throw e;
        }
        return count;
    }

    public List<SmsOutbox> getSmsOutBoxSearchResultList(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        List<SmsOutbox> smsOutBoxList;
        try {
            //set audit trace values
            audittrace.setSection(SectionVarList.SECTION_SYS_CONFIGURATION_MGT);
            audittrace.setPage(PageVarList.SMSOUTBOX_REPORT_PAGE);
            audittrace.setTask(TaskVarList.VIEW_TASK);
            audittrace.setDescription("Get sms outbox search list.");
            //get category search list
            smsOutBoxList = smsOutboxRepository.getSmsOutBoxSearchResultList(smsOutboxReportInputBean);
        } catch (EmptyResultDataAccessException ere) {
            audittrace.setSkip(true);
            throw ere;
        } catch (Exception e) {
            audittrace.setSkip(true);
            throw e;
        }
        return smsOutBoxList;
    }

    public List<SmsOutbox> getSmsOutBoxSearchResultListForReport(SmsOutboxReportInputBean smsOutboxReportInputBean) throws Exception {
        List<SmsOutbox> smsOutBoxList;
        try {
            //set audit trace values
            audittrace.setSection(SectionVarList.SECTION_SYS_CONFIGURATION_MGT);
            audittrace.setPage(PageVarList.SMSOUTBOX_REPORT_PAGE);
            audittrace.setTask(TaskVarList.DOWNLOAD_TASK);
            audittrace.setDescription("Get sms outbox search list.");
            //get category search list for report
            smsOutBoxList = smsOutboxRepository.getSmsOutBoxSearchResultListForReport(smsOutboxReportInputBean);
        } catch (EmptyResultDataAccessException ere) {
            audittrace.setSkip(true);
            throw ere;
        } catch (Exception e) {
            audittrace.setSkip(true);
            throw e;
        }
        return smsOutBoxList;
    }

}

package com.epic.pb.service.reportmgt.txnalert;

import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.util.common.Common;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("prototype")
public class TxnAlertService {

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    @Autowired
    Audittrace audittrace;

    @Autowired
    MessageSource messageSource;
}

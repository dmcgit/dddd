package com.epic.pb.service.sectionmgt.passwordpolicy;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordpolicy.PasswordPolicyInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.passwordpolicy.PasswordPolicy;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.sectionmgt.passwordpolicy.PasswordPolicyRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
public class PasswordPolicyService {
    @Autowired
    PasswordPolicyRepository passwordPolicyRepository;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    private final String fields = "PasswordPolicyInputBean PasswordPolicy|Created Time|Last Updated Time|Last Updated User";

    public long getDataCount(PasswordPolicyInputBean passwordPolicyInputBean) throws Exception {
        long count = 0;
        try {
            count = passwordPolicyRepository.getDataCount(passwordPolicyInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public long getDataCountDual(PasswordPolicyInputBean policyInputBean) throws Exception {
        long count = 0;
        try {
            count = passwordPolicyRepository.getDataCountDual(policyInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public List<PasswordPolicyInputBean> getPasswordPolicySearchResults(PasswordPolicyInputBean passwordPolicyInputBean) throws Exception {
        List<PasswordPolicyInputBean> passwordPolicyList;
        try {
            passwordPolicyList = passwordPolicyRepository.getPasswordPolicySearchResults(passwordPolicyInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordPolicyList;
    }

    public List<TempAuthRecBean> getPasswordPolicySearchResultsDual(PasswordPolicyInputBean policyInputBean) throws Exception {
        List<TempAuthRecBean> passwordPolicyDualList;
        try {
            passwordPolicyDualList = passwordPolicyRepository.getPasswordPolicySearchResultsDual(policyInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordPolicyDualList;
    }

    public PasswordPolicy getWebPasswordPolicy(int passwordPolicyCode) {
        PasswordPolicy passwordPolicy = null;
        try {
            passwordPolicy = passwordPolicyRepository.getWebPasswordPolicy(passwordPolicyCode);
            //set password policy to session bean
            sessionBean.setPasswordPolicy(passwordPolicy);
        } catch (Exception e) {
            throw e;
        }
        return passwordPolicy;
    }

    public String updatePasswordPolicy(PasswordPolicy passwordPolicy) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORDPOLICY_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        try {
            //set passwordParam data
            passwordPolicy.setCreatedTime(commonRepository.getCurrentDate());
            passwordPolicy.setLastUpdatedTime(commonRepository.getCurrentDate());
            passwordPolicy.setLastUpdatedUser(sessionBean.getUsername());
            //check record exist and get old values
            PasswordPolicy policyOldBean = this.getPasswordPolicy(String.valueOf(passwordPolicy.getPasswordPolicyId()));
            if (policyOldBean != null) {
                //check changed values
                String oldValueCheck = this.getPasswordPolicyAsString(policyOldBean, true);
                String newValueCheck = this.getPasswordPolicyAsString(passwordPolicy, true);

                if (oldValueCheck.equals(newValueCheck)) {
                    message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
                } else {
                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.PASSWORDPOLICY_MGT_PAGE)) {
                        audit.setDescription("Requested to update password policy (password policy id: " + passwordPolicy.getPasswordPolicyId() + ")");
                        message = this.insertDualAuthRecord(passwordPolicy, TaskVarList.UPDATE_TASK);
                    } else {
                        audit.setDescription("Password Policu (password policy id: " + passwordPolicy.getPasswordPolicyId() + ") updated by " + sessionBean.getUsername());
                        message = passwordPolicyRepository.updatePasswordPolicy(passwordPolicy);
                    }
                    //create audit record
                    audit.setField(fields);
                    audit.setNewvalue(this.getPasswordPolicyAsString(passwordPolicy, false));
                    audit.setOldvalue(this.getPasswordPolicyAsString(policyOldBean, false));
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                }
            } else {
                message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public PasswordPolicy getPasswordPolicy(String passwordPolicy) throws Exception {
        PasswordPolicy password;
        try {
            password = passwordPolicyRepository.getPasswordPolicy(passwordPolicy);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return password;
    }


    public String insertDualAuthRecord(PasswordPolicy passwordPolicy, String task) throws Exception {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();
        String message = "";
        long count = 0;
        try {
            count = commonRepository.getTempAuthRecordCount(String.valueOf(passwordPolicy.getPasswordPolicyId()), PageVarList.PASSWORDPOLICY_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN);
            if (count > 0) {
                message = MessageVarList.TMP_RECORD_ALREADY_EXISTS;
            } else {
                tempAuthRecBean.setPage(PageVarList.PASSWORDPOLICY_MGT_PAGE);
                tempAuthRecBean.setTask(task);
                tempAuthRecBean.setKey1(String.valueOf(passwordPolicy.getPasswordPolicyId()));
                tempAuthRecBean.setKey2(String.valueOf(passwordPolicy.getMinimumLength()));
                tempAuthRecBean.setKey3(String.valueOf(passwordPolicy.getMaximumLength()));
                tempAuthRecBean.setKey4(String.valueOf(passwordPolicy.getMinimumSpecialCharacters()));
                tempAuthRecBean.setKey5(String.valueOf(passwordPolicy.getMinimumUpperCaseCharacters()));
                tempAuthRecBean.setKey6(String.valueOf(passwordPolicy.getMinimumNumericalCharacters()));
                tempAuthRecBean.setKey7(String.valueOf(passwordPolicy.getMinimumLowerCaseCharacters()));
                tempAuthRecBean.setKey8(String.valueOf(passwordPolicy.getNoOfInvalidLoginAttempt()));
                tempAuthRecBean.setKey9(String.valueOf(passwordPolicy.getRepeatCharactersAllow()));
                tempAuthRecBean.setKey10(String.valueOf(passwordPolicy.getInitialPasswordExpiryStatus()));
                tempAuthRecBean.setKey11(String.valueOf(passwordPolicy.getPasswordExpiryPeriod()));
                tempAuthRecBean.setKey12(String.valueOf(passwordPolicy.getNoOfHistoryPassword()));
                tempAuthRecBean.setKey13(String.valueOf(passwordPolicy.getMinimumPasswordChangePeriod()));
                tempAuthRecBean.setKey14(String.valueOf(passwordPolicy.getIdleAccountExpiryPeriod()));
                tempAuthRecBean.setKey15(passwordPolicy.getDescription().trim());
                //insert dual auth record
                message = commonRepository.insertDualAuthRecordSQL(tempAuthRecBean);
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String confirmPasswordPolicy(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORDPOLICY_MGT_PAGE, TaskVarList.DUAL_AUTH_CONFIRM_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;
        try {
            tempAuthRecBean = commonRepository.getTempAuthRecord(id);
            if (tempAuthRecBean != null) {
                PasswordPolicy policy = new PasswordPolicy();
                policy.setPasswordPolicyId(Long.parseLong(tempAuthRecBean.getKey1()));
                policy.setMinimumLength(Long.parseLong(tempAuthRecBean.getKey2()));
                policy.setMaximumLength(Long.parseLong(tempAuthRecBean.getKey3()));
                policy.setMinimumSpecialCharacters(Long.parseLong(tempAuthRecBean.getKey4()));
                policy.setMinimumUpperCaseCharacters(Long.parseLong(tempAuthRecBean.getKey5()));
                policy.setMinimumNumericalCharacters(Long.parseLong(tempAuthRecBean.getKey6()));
                policy.setMinimumLowerCaseCharacters(Long.parseLong(tempAuthRecBean.getKey7()));
                policy.setNoOfInvalidLoginAttempt(Long.parseLong(tempAuthRecBean.getKey8()));
                policy.setRepeatCharactersAllow(Long.parseLong(tempAuthRecBean.getKey9()));
                policy.setInitialPasswordExpiryStatus(Long.parseLong(tempAuthRecBean.getKey10()));
                policy.setPasswordExpiryPeriod(Long.parseLong(tempAuthRecBean.getKey11()));
                policy.setNoOfHistoryPassword(Long.parseLong(tempAuthRecBean.getKey12()));
                policy.setMinimumPasswordChangePeriod(Long.parseLong(tempAuthRecBean.getKey13()));
                policy.setIdleAccountExpiryPeriod(Long.parseLong(tempAuthRecBean.getKey14()));
                policy.setDescription(tempAuthRecBean.getKey15());
                policy.setCreatedTime(commonRepository.getCurrentDate());
                policy.setLastUpdatedTime(commonRepository.getCurrentDate());
                policy.setLastUpdatedUser(sessionBean.getUsername());

                //check passwordparam is already exist or not
                PasswordPolicy existingPasswordPolicy = null;
                try {
                    existingPasswordPolicy = passwordPolicyRepository.getPasswordPolicy(String.valueOf(policy.getPasswordPolicyId()).trim());
                } catch (EmptyResultDataAccessException ex) {
                    existingPasswordPolicy = null;
                }

                if (TaskVarList.UPDATE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingPasswordPolicy != null) {
                        message = passwordPolicyRepository.updatePasswordPolicy(policy);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                }
                //if password param db operation success, update temp auth record
                if (message.isEmpty()) {
                    message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_CON);

                    //if tempauth db operation success,insert the audit
                    if (message.isEmpty()) {
                        //create audit record
                        audit.setField(fields);
                        audit.setNewvalue(this.getPasswordPolicyAsString(policy, false));
                        audit.setOldvalue(this.getPasswordPolicyAsString(existingPasswordPolicy, false));
                        //create audit description
                        StringBuilder auditDesBuilder = new StringBuilder();
                        auditDesBuilder.append("Approved performing  '").append(tempAuthRecBean.getTask())
                                .append("' operation on password policy (password policy id: ").append(policy.getPasswordPolicyId())
                                .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" approved by ")
                                .append(sessionBean.getUsername());
                        audit.setDescription(auditDesBuilder.toString());
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    } else {
                        message = MessageVarList.COMMON_ERROR_PROCESS;
                    }
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String rejectPasswordPolicy(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORDPOLICY_MGT_PAGE, TaskVarList.DUAL_AUTH_REJECT_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;
        try {
            tempAuthRecBean = commonRepository.getTempAuthRecord(id);
            if (tempAuthRecBean != null) {
                message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_REJ);

                //if tempauth db operation success,insert the audit
                if (message.isEmpty()) {
                    //create audit description
                    StringBuilder auditDesBuilder = new StringBuilder();
                    auditDesBuilder.append("Rejected performing  '").append(tempAuthRecBean.getTask())
                            .append("' operation on password policy (password policy id: ").append(tempAuthRecBean.getKey1())
                            .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" rejected by ")
                            .append(sessionBean.getUsername());
                    audit.setDescription(auditDesBuilder.toString());
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    private String getPasswordPolicyAsString(PasswordPolicy passwordPolicy, boolean checkChanges) {
        StringBuilder taskStringBuilder = new StringBuilder();

        if (passwordPolicy != null) {
            if (passwordPolicy.getPasswordPolicyId() != 0) {
                taskStringBuilder.append(passwordPolicy.getPasswordPolicyId());
            } else {
                taskStringBuilder.append("error");
            }

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumLength());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMaximumLength());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumSpecialCharacters());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumUpperCaseCharacters());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumUpperCaseCharacters());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumLowerCaseCharacters());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getNoOfInvalidLoginAttempt());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getRepeatCharactersAllow());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getInitialPasswordExpiryStatus());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getPasswordExpiryPeriod());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getNoOfHistoryPassword());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getMinimumPasswordChangePeriod());

            taskStringBuilder.append("|");
            taskStringBuilder.append(passwordPolicy.getIdleAccountExpiryPeriod());

            taskStringBuilder.append("|");
            if (passwordPolicy.getDescription() != null) {
                taskStringBuilder.append(passwordPolicy.getDescription());
            } else {
                taskStringBuilder.append("--");
            }

            if (!checkChanges) {
                taskStringBuilder.append("|");
                if (Objects.isNull(passwordPolicy.getCreatedTime())) {
                    taskStringBuilder.append(common.formatDateToString(passwordPolicy.getCreatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (Objects.isNull(passwordPolicy.getLastUpdatedTime())) {
                    taskStringBuilder.append(common.formatDateToString(passwordPolicy.getLastUpdatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (Objects.isNull(passwordPolicy.getLastUpdatedUser())) {
                    taskStringBuilder.append(passwordPolicy.getLastUpdatedUser());
                } else {
                    taskStringBuilder.append("--");
                }
            }
        }
        return taskStringBuilder.toString();
    }

}

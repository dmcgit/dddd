package com.epic.pb.service.sectionmgt.passwordparam;

import com.epic.pb.bean.common.TempAuthRecBean;
import com.epic.pb.bean.sectionmanagement.passwordparam.PasswordParamInputBean;
import com.epic.pb.bean.session.SessionBean;
import com.epic.pb.mapping.audittrace.Audittrace;
import com.epic.pb.mapping.sectionmgt.PasswordParam;
import com.epic.pb.repository.common.CommonRepository;
import com.epic.pb.repository.sectionmgt.passwordparam.PasswordParamRepository;
import com.epic.pb.util.common.Common;
import com.epic.pb.util.varlist.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Repository
public class PasswordParamService {
    @Autowired
    PasswordParamRepository passwordParamRepository;

    @Autowired
    SessionBean sessionBean;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    Common common;

    private final String fields = "PasswordParamInputBean PasswordParam|UserRoleType|Value|Created Time|Last Updated Time|Last Updated User";

    public long getDataCount(PasswordParamInputBean paramBean) throws Exception {
        long count = 0;
        try {
            count = passwordParamRepository.getDataCount(paramBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return count;
    }

    public long getDataCountDual(PasswordParamInputBean paramBean) throws Exception {
        long count = 0;
        try {
            count = passwordParamRepository.getDataCountDual(paramBean);
        } catch (DataAccessException ex) {
            throw ex;
        }

        return count;
    }

    public List<PasswordParamInputBean> getPasswordParamSearchResults(PasswordParamInputBean paramBean) throws Exception {
        List<PasswordParamInputBean> paramList;
        try {
            paramList = passwordParamRepository.getPasswordParamSearchResults(paramBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return paramList;
    }

    public List<TempAuthRecBean> getPasswordParamSearchResultsDual(PasswordParamInputBean paramInputBean) throws Exception {
        List<TempAuthRecBean> passwordParamDualList;
        try {
            passwordParamDualList = passwordParamRepository.getPasswordParamSearchResultsDual(paramInputBean);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return passwordParamDualList;
    }

    public String updatePasswordParam(PasswordParam passwordParam) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORD_PARAMETER_MGT_PAGE, TaskVarList.UPDATE_TASK);
        String message = "";
        try {
            //set passwordParam data
            passwordParam.setCreatedTime(commonRepository.getCurrentDate());
            passwordParam.setLastUpdatedTime(commonRepository.getCurrentDate());
            passwordParam.setLastUpdatedUser(sessionBean.getUsername());
            //check record exist and get old values
            PasswordParam paramOldBean = this.getPasswordParam(passwordParam.getPasswordparam());
            if (paramOldBean != null) {
                //check changed values
                String oldValueCheck = this.getPasswordParamAsString(paramOldBean, true);
                String newValueCheck = this.getPasswordParamAsString(passwordParam, true);

                if (oldValueCheck.equals(newValueCheck)) {
                    message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
                } else {
                    if (commonRepository.checkPageIsDualAuthenticate(PageVarList.PASSWORD_PARAMETER_MGT_PAGE)) {
                        audit.setDescription("Requested to update password param (password param: " + passwordParam.getPasswordparam().trim().toUpperCase() + ")");
                        message = this.insertDualAuthRecord(passwordParam, TaskVarList.UPDATE_TASK);
                    } else {
                        audit.setDescription("Password Param (password param: " + passwordParam.getPasswordparam().trim().toUpperCase() + ") updated by " + sessionBean.getUsername());
                        message = passwordParamRepository.updatePasswordParam(passwordParam);
                    }
                    //create audit record
                    audit.setField(fields);
                    audit.setNewvalue(this.getPasswordParamAsString(passwordParam, false));
                    audit.setOldvalue(this.getPasswordParamAsString(paramOldBean, false));
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                }
            } else {
                message = MessageVarList.COMMON_ERROR_NO_VALUE_CHANGE;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public PasswordParam getPasswordParam(String passwordParam) throws Exception {
        PasswordParam password;
        try {
            password = passwordParamRepository.getPasswordParam(passwordParam);
        } catch (DataAccessException ex) {
            throw ex;
        }
        return password;
    }

    public String insertDualAuthRecord(PasswordParam passwordParam, String task) throws Exception {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();
        String message = "";
        long count = 0;
        try {
            count = commonRepository.getTempAuthRecordCount(passwordParam.getPasswordparam().trim(), PageVarList.PASSWORD_PARAMETER_MGT_PAGE, StatusVarList.STATUS_AUTH_PEN);
            if (count > 0) {
                message = MessageVarList.TMP_RECORD_ALREADY_EXISTS;
            } else {
                tempAuthRecBean.setPage(PageVarList.PASSWORD_PARAMETER_MGT_PAGE);
                tempAuthRecBean.setTask(task);
                tempAuthRecBean.setKey1(passwordParam.getPasswordparam().trim());
                tempAuthRecBean.setKey2(passwordParam.getUserroletype().trim());
                tempAuthRecBean.setKey3(passwordParam.getValue().trim());
                //insert dual auth record
                message = commonRepository.insertDualAuthRecordSQL(tempAuthRecBean);
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    @Transactional
    public String confirmPasswordParam(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORD_PARAMETER_MGT_PAGE, TaskVarList.DUAL_AUTH_CONFIRM_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;
        try {
            tempAuthRecBean = commonRepository.getTempAuthRecord(id);
            if (tempAuthRecBean != null) {
                PasswordParam param = new PasswordParam();
                param.setPasswordparam(tempAuthRecBean.getKey1());
                param.setUserroletype(tempAuthRecBean.getKey2());
                param.setValue(tempAuthRecBean.getKey3());
                param.setCreatedTime(commonRepository.getCurrentDate());
                param.setLastUpdatedTime(commonRepository.getCurrentDate());
                param.setLastUpdatedUser(sessionBean.getUsername());

                //check passwordparam is already exist or not
                PasswordParam existingPasswordParam = null;
                try {
                    existingPasswordParam = passwordParamRepository.getPasswordParam(param.getPasswordparam().trim());
                } catch (EmptyResultDataAccessException ex) {
                    existingPasswordParam = null;
                }

                if (TaskVarList.UPDATE_TASK.equals(tempAuthRecBean.getTask())) {
                    if (existingPasswordParam != null) {
                        message = passwordParamRepository.updatePasswordParam(param);
                    } else {
                        message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
                    }
                }
                //if password param db operation success, update temp auth record
                if (message.isEmpty()) {
                    message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_CON);

                    //if tempauth db operation success,insert the audit
                    if (message.isEmpty()) {
                        //create audit record
                        audit.setField(fields);
                        audit.setNewvalue(this.getPasswordParamAsString(param, false));
                        audit.setOldvalue(this.getPasswordParamAsString(existingPasswordParam, false));
                        //create audit description
                        StringBuilder auditDesBuilder = new StringBuilder();
                        auditDesBuilder.append("Approved performing  '").append(tempAuthRecBean.getTask())
                                .append("' operation on password param (password param code: ").append(param.getPasswordparam())
                                .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" approved by ")
                                .append(sessionBean.getUsername());
                        audit.setDescription(auditDesBuilder.toString());
                        //set audit to session bean
                        sessionBean.setAudittrace(audit);
                    } else {
                        message = MessageVarList.COMMON_ERROR_PROCESS;
                    }
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    public String rejectPasswordParam(String id) throws Exception {
        Audittrace audit = new Audittrace(SectionVarList.SECTION_SYS_CONFIGURATION_MGT, PageVarList.PASSWORD_PARAMETER_MGT_PAGE, TaskVarList.DUAL_AUTH_REJECT_TASK);
        String message = "";
        TempAuthRecBean tempAuthRecBean;
        try {
            tempAuthRecBean = commonRepository.getTempAuthRecord(id);
            if (tempAuthRecBean != null) {
                message = commonRepository.updateTempAuthRecord(id, StatusVarList.STATUS_AUTH_REJ);

                //if tempauth db operation success,insert the audit
                if (message.isEmpty()) {
                    //create audit description
                    StringBuilder auditDesBuilder = new StringBuilder();
                    auditDesBuilder.append("Rejected performing  '").append(tempAuthRecBean.getTask())
                            .append("' operation on password param (password param code: ").append(tempAuthRecBean.getKey1())
                            .append(") inputted by ").append(tempAuthRecBean.getLastUpdatedUser()).append(" rejected by ")
                            .append(sessionBean.getUsername());
                    audit.setDescription(auditDesBuilder.toString());
                    //set audit to session bean
                    sessionBean.setAudittrace(audit);
                } else {
                    message = MessageVarList.COMMON_ERROR_PROCESS;
                }
            } else {
                message = MessageVarList.COMMON_ERROR_RECORD_DOESNOT_EXISTS;
            }
        } catch (Exception ex) {
            throw ex;
        }
        return message;
    }

    private String getPasswordParamAsString(PasswordParam passwordParam, boolean checkChanges) {
        StringBuilder taskStringBuilder = new StringBuilder();

        if (passwordParam != null) {
            if (passwordParam.getPasswordparam() != null) {
                taskStringBuilder.append(passwordParam.getPasswordparam());
            } else {
                taskStringBuilder.append("error");
            }

            taskStringBuilder.append("|");
            if (passwordParam.getUserroletype() != null) {
                taskStringBuilder.append(passwordParam.getUserroletype());
            } else {
                taskStringBuilder.append("--");
            }

            taskStringBuilder.append("|");
            if (passwordParam.getValue() != null) {
                taskStringBuilder.append(passwordParam.getValue());
            } else {
                taskStringBuilder.append("--");
            }

            if (!checkChanges) {
                taskStringBuilder.append("|");
                if (passwordParam.getCreatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(passwordParam.getCreatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (passwordParam.getLastUpdatedTime() != null) {
                    taskStringBuilder.append(common.formatDateToString(passwordParam.getLastUpdatedTime()));
                } else {
                    taskStringBuilder.append("--");
                }

                taskStringBuilder.append("|");
                if (passwordParam.getLastUpdatedUser() != null) {
                    taskStringBuilder.append(passwordParam.getLastUpdatedUser());
                } else {
                    taskStringBuilder.append("--");
                }
            }
        }
        return taskStringBuilder.toString();
    }
}

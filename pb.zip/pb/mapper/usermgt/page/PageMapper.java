package com.epic.pb.mapper.usermgt.page;

import com.epic.pb.mapping.usermgt.Page;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PageMapper implements RowMapper<Page> {

    @Override
    public Page mapRow(ResultSet rs, int rowNum) throws SQLException {
        Page page = new Page();

        try {
            page.setPageCode(rs.getString("PAGECODE"));
        } catch (SQLException e) {
            page.setPageCode(null);
        }

        try {
            page.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            page.setDescription(null);
        }

        try {
            page.setUrl(rs.getString("URL"));
        } catch (SQLException e) {
            page.setUrl(null);
        }

        try {
            page.setSortKey(rs.getInt("SORTKEY"));
        } catch (SQLException e) {
            page.setSortKey(0);
        }

        try {
            page.setActualFalg(rs.getBoolean("AFLAG"));
        } catch (SQLException e) {
            page.setActualFalg(false);
        }

        try {
            page.setCurrentFlag(rs.getBoolean("CFLAG"));
        } catch (SQLException e) {
            page.setCurrentFlag(false);
        }

        try {
            page.setStatusCode(rs.getString("STATUS"));
        } catch (SQLException e) {
            page.setStatusCode(null);
        }

        try {
            page.setCreatedTime(rs.getDate("CREATEDTIME"));
        } catch (SQLException e) {
            page.setCreatedTime(null);
        }

        try {
            page.setLastUpdatedTime(rs.getDate("CREATEDTIME"));
        } catch (SQLException e) {
            page.setLastUpdatedTime(null);
        }

        try {
            page.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
        } catch (SQLException e) {
            page.setLastUpdatedUser(null);
        }

        return page;
    }
}

package com.epic.pb.mapper.usermgt.page;

import com.epic.pb.bean.usermgt.page.PageInputBean;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PageDataMapper implements RowMapper<PageInputBean> {

    @Override
    public PageInputBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        PageInputBean page = new PageInputBean();

        try {
            page.setPageCode(rs.getString("PAGECODE"));
        } catch (SQLException e) {
            page.setPageCode(null);
        }

        try {
            page.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            page.setDescription(null);
        }

        try {
            page.setUrl(rs.getString("URL"));
        } catch (SQLException e) {
            page.setUrl(null);
        }

        try {
            page.setSortKey(rs.getInt("SORTKEY"));
        } catch (SQLException e) {
            page.setSortKey(0);
        }

        try {
            page.setActualFalg(rs.getBoolean("AFLAG"));
        } catch (SQLException e) {
            page.setActualFalg(false);
        }

        try {
            page.setCurrentFlag(rs.getBoolean("CFLAG"));
        } catch (SQLException e) {
            page.setCurrentFlag(false);
        }

        try {
            page.setStatus(rs.getString("STATUSDES"));
        } catch (SQLException e) {
            page.setStatus(null);
        }

        try {
            page.setCreatedTime(rs.getString("CREATEDTIME").substring(0, 19));
        } catch (SQLException e) {
            page.setCreatedTime(null);
        }

        return page;
    }
}

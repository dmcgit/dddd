package com.epic.pb.mapper.usermgt.page;

import com.epic.pb.bean.common.TempAuthRecBean;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PageDualMapper implements RowMapper<TempAuthRecBean>  {

    @Override
    public TempAuthRecBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        TempAuthRecBean tempAuthRecBean = new TempAuthRecBean();

        try {
            tempAuthRecBean.setId(rs.getString("ID"));
        } catch (SQLException e) {
            tempAuthRecBean.setId(null);
        }

        try {
            tempAuthRecBean.setTask(rs.getString("TASK"));
        } catch (SQLException e) {
            tempAuthRecBean.setTask(null);
        }

        try {
            //page code
            tempAuthRecBean.setKey1(rs.getString("KEY1"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey1(null);
        }

        try {
            //description
            tempAuthRecBean.setKey2(rs.getString("KEY2"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey2(null);
        }

        try {
            //url
            tempAuthRecBean.setKey3(rs.getString("KEY3"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey3(null);
        }

        try {
            //sort key
            tempAuthRecBean.setKey4(rs.getString("KEY4"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey4(null);
        }

        try {
            //actual dual auth flag
            tempAuthRecBean.setKey5(rs.getString("KEY5"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey5(null);
        }

        try {
            //current dual auth flag
            tempAuthRecBean.setKey6(rs.getString("KEY6"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey6(null);
        }

        try {
            //status
            tempAuthRecBean.setKey7(rs.getString("KEY7"));
        } catch (SQLException e) {
            tempAuthRecBean.setKey7(null);
        }

        try {
            tempAuthRecBean.setLastUpdatedTime(rs.getString("LASTUPDATEDTIME"));
        } catch (SQLException e) {
            tempAuthRecBean.setLastUpdatedTime(null);
        }

        try {
            tempAuthRecBean.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
        } catch (SQLException e) {
            tempAuthRecBean.setLastUpdatedUser(null);
        }

        try {
            tempAuthRecBean.setCreatedTime(rs.getString("CREATEDTIME"));
        } catch (SQLException e) {
            tempAuthRecBean.setCreatedTime(null);
        }

        return tempAuthRecBean;
    }
}

package com.epic.pb.mapper.usermgt.section;

import com.epic.pb.bean.usermgt.section.SectionInputBean;
import com.epic.pb.bean.usermgt.task.TaskInputBean;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SectionDataMapper implements RowMapper<SectionInputBean> {

    @Override
    public SectionInputBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        SectionInputBean section = new SectionInputBean();

        try {
            section.setSectionCode(rs.getString("SECTIONCODE"));
        } catch (SQLException e) {
            section.setSectionCode(null);
        }
        try {
            section.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            section.setDescription(null);
        }

        try {
            section.setStatus(rs.getString("STATUSDES"));
        } catch (SQLException e) {
            section.setStatus(null);
        }

        try {
            section.setCreatedTime(rs.getString("CREATEDTIME").substring(0, 19));
        } catch (SQLException e) {
            section.setCreatedTime(null);
        }

        return section;
    }

}



package com.epic.pb.mapper.usermgt.task;

import com.epic.pb.mapping.usermgt.Task;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TaskMapper implements RowMapper<Task> {

    @Override
    public Task mapRow(ResultSet rs, int rowNum) throws SQLException {
        Task task = new Task();

        try {
            task.setTaskCode(rs.getString("TASKCODE"));
        } catch (SQLException e) {
            task.setTaskCode(null);
        }

        try {
            task.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            task.setDescription(null);
        }

        try {
            task.setStatus(rs.getString("STATUS"));
        } catch (SQLException e) {
            task.setStatus(null);
        }

        try {
            task.setCreateTime(rs.getDate("CREATEDTIME"));
        } catch (SQLException e) {
            task.setCreateTime(null);
        }

        try {
            task.setLastUpdatedTime(rs.getDate("LASTUPDATEDTIME"));
        } catch (SQLException e) {
            task.setLastUpdatedTime(null);
        }

        try {
            task.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
        } catch (SQLException e) {
            task.setLastUpdatedUser(null);
        }
        return task;
    }
}


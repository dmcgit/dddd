package com.epic.pb.mapper.usermgt.task;

import com.epic.pb.bean.usermgt.task.TaskInputBean;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TaskDataMapper implements RowMapper<TaskInputBean> {

    @Override
    public TaskInputBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        TaskInputBean task = new TaskInputBean();

        try {
            task.setTaskCode(rs.getString("TASKCODE"));
        } catch (SQLException e) {
            task.setTaskCode(null);
        }
        try {
            task.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            task.setDescription(null);
        }

        try {
            task.setStatus(rs.getString("STATUSDES"));
        } catch (SQLException e) {
            task.setStatus(null);
        }

        try {
            task.setCreatedTime(rs.getString("CREATEDTIME").substring(0, 19));
        } catch (SQLException e) {
            task.setCreatedTime(null);
        }

        return task;
    }

}



package com.epic.pb.mapper.usermgt.userrole;

import com.epic.pb.mapping.usermgt.UserRole;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRoleMapper implements RowMapper<UserRole> {

    @Override
    public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
        UserRole userRole = new UserRole();

        try {
            userRole.setUserroleCode(rs.getString("USERROLECODE"));
        } catch (SQLException e) {
            userRole.setUserroleCode(null);
        }

        try {
            userRole.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            userRole.setDescription(null);
        }

        try {
            userRole.setUserroleType(rs.getString("USERROLETYPE"));
        } catch (SQLException e) {
            userRole.setUserroleType(null);
        }

        try {
            userRole.setStatus(rs.getString("STATUS"));
        } catch (SQLException e) {
            userRole.setStatus(null);
        }

        try {
            userRole.setCreatedTime(rs.getDate("CREATEDTIME"));
        } catch (SQLException e) {
            userRole.setCreatedTime(null);
        }

        try {
            userRole.setLastUpdatedTime(rs.getDate("CREATEDTIME"));
        } catch (SQLException e) {
            userRole.setLastUpdatedTime(null);
        }

        try {
            userRole.setLastUpdatedUser(rs.getString("LASTUPDATEDUSER"));
        } catch (SQLException e) {
            userRole.setLastUpdatedUser(null);
        }

        return userRole;
    }
}

package com.epic.pb.mapper.usermgt.userrole;

import com.epic.pb.bean.usermgt.userrole.UserRoleInputBean;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRoleDataMapper implements RowMapper<UserRoleInputBean> {

    @Override
    public UserRoleInputBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        UserRoleInputBean inputBean = new UserRoleInputBean();

        try {
            inputBean.setUserroleCode(rs.getString("USERROLECODE"));
        } catch (SQLException e) {
            inputBean.setUserroleCode(null);
        }

        try {
            inputBean.setDescription(rs.getString("DESCRIPTION"));
        } catch (SQLException e) {
            inputBean.setDescription(null);
        }

        try {
            inputBean.setUserroleType(rs.getString("USERROLETYPEDESC"));
        } catch (SQLException e) {
            inputBean.setUserroleType(null);
        }

        try {
            inputBean.setStatusCode(rs.getString("STATUS"));
        } catch (SQLException e) {
            inputBean.setStatusCode(null);
        }

        try {
            inputBean.setStatus(rs.getString("STATUSDES"));
        } catch (SQLException e) {
            inputBean.setStatus(null);
        }

        try {
            inputBean.setCreatedTime(rs.getString("CREATEDTIME").substring(0, 19));
        } catch (SQLException e) {
            inputBean.setCreatedTime(null);
        }

        return inputBean;
    }
}

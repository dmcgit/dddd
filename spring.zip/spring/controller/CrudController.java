package net.spring.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import net.spring.dao.UserDao;
import net.spring.model.RegisterUser;

@Controller
public class CrudController {

	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value="/fetch")
	public ModelAndView listRegisterStudents(ModelAndView model) throws IOException{
		List<RegisterUser> listusers = userDao.studentList();
		model.addObject("listUser",listusers);
		model.setViewName("admindashboard");
		
		return model;
	}
	
	@RequestMapping(value="/fetch2")
	public ModelAndView listRegisterLecturers(ModelAndView model) throws IOException{
		List<RegisterUser> listusers = userDao.lecturerList();
		model.addObject("listUser",listusers);
		model.setViewName("admindashboard");
		
		return model;
	}
}
